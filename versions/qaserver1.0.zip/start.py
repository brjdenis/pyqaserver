# This software was put together from various sources that come with respective licenses.
# Please read the license files of that software. I tried wholeheartedly to document the license conditions of all
# the software that I used to construct QAserver.  If I failed at some point, I can only ask for forgiveness.

# For the rest the MIT license applies.

# Copyright 2019 Denis Brojan
#
# Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
# documentation files (the "Software"), to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in all copies or substantial portions
# of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

QASERVER_VERSION = "1.0"

"""
This module is the main module. Run it with the following command: python run.py
"""
import sys
import os
import copy

from bottle import Bottle, request, redirect, TEMPLATE_PATH, static_file, template
from bottle import run as bottle_run

import json
import sqlite3 as sql
import tempfile
import zipfile
import gc
import random

import base64
from multiprocessing import Pool

from time import gmtime, strftime
import datetime

import numpy as np
from scipy.signal import savgol_filter
from scipy import ndimage
import warnings
import shutil
import configparser

import RestToolbox_modified as RestToolbox
import VarianDynalog as VarianDynalog

import matplotlib
matplotlib.use('Agg')
from matplotlib.figure import Figure
from matplotlib import patches
from mpl_toolkits.axes_grid1 import make_axes_locatable

# Path to Bottle templates
TEMPLATE_PATH.insert(0, 'views')

# Load configuration  from config.ini
CONFIG = configparser.ConfigParser()
CONFIG.read('config.ini')

# pylinac v2.2.7
from pylinac import WinstonLutz as WinstonLutz
from pylinac import Starshot as Starshot
from pylinac.core import image as pylinacimage
from pylinac.core import image as pylinac_image
from pylinac.core.roi import bbox_center
from pylinac.core.profile import SingleProfile as PylinacSingleProfile
from pylinac import planar_imaging as planar_imaging
from pylinac import ct as pylinac_ct
from pylinac import FlatSym as FlatSym
from pylinac import DRGS, DRMLC

import MLC_fieldsize as MLC_fieldsize

if CONFIG['PicketFence']['USE_ORIGINAL_PYLINAC'] == "True":
    from pylinac import PicketFence as PicketFence  # Original pylinac analysis
    #from pylinac.PicketFence import Overlay as Overlay
else:
    from picketfence_modified import PicketFence as PicketFence
    #from picketfence_modified import Overlay as Overlay

from bokeh.plotting import figure
from bokeh.embed import components
from bokeh.layouts import gridplot, widgetbox, row, layout
from bokeh.models import CustomJS, ColumnDataSource, HoverTool, Slider, Legend, NumberFormatter, BoxSelectTool, DataTable, TableColumn, LinearColorMapper
from bokeh.core.properties import value as bokeh_value
from bokeh.models.widgets import RangeSlider

sys.path.append(os.path.abspath(os.path.realpath("python_packages")))  # To import mpld3
from python_packages import mpld3

# To revert back to matplotlib 1.0 style
matplotlib.style.use('classic')

# Set string for the header of HTML pages:
INSTITUTION = CONFIG['general']['INSTITUTION']

# IP address and port where the web interface will be available:
IP_ADDRESS = CONFIG['general']['PLWEB_IP']
PORT = CONFIG['general']['PLWEB_PORT']

# IP adress and port where the http dicom server will be available:
ORTHANC_IP = CONFIG['general']['ORTHANC_IP']
ORTHANC_PORT = CONFIG['general']['ORTHANC_PORT']

# Credentials for accessing web interface:
USERNAME = CONFIG['general']['PLWEB_USERNAME']
PASSWORD = CONFIG['general']['PLWEB_PASSWORD']

# Credentials for accessing orthanc server:
USERNAME_ORTHANC = CONFIG['general']['ORTHANC_USERNAME']
PASSWORD_ORTHANC = CONFIG['general']['ORTHANC_PASSWORD']

# Url to some mpld3 library
D3_URL = "/js/d3.v3.min.js"
MPLD3_URL = "/js/mpld3.v0.3.min.js"

#  Global filepaths for bokeh import
BOKEH_FILE_CSS = "/bokeh/css/bokeh-1.3.4.min.css"
BOKEH_FILE_JS = "/bokeh/js/bokeh-1.3.4.min.js"
BOKEH_WIDGETS_CSS = "/bokeh/css/bokeh-widgets-1.3.4.min.css"
BOKEH_WIDGETS_JS = "/bokeh/js/bokeh-widgets-1.3.4.min.js"
BOKEH_TABLES_CSS = "/bokeh/css/bokeh-tables-1.3.4.min.css"
BOKEH_TABLES_JS = "/bokeh/js/bokeh-tables-1.3.4.min.js"

ORTHANC_URL = "http://"+str(ORTHANC_IP) + ":" + str(ORTHANC_PORT)
RestToolbox.SetCredentials(USERNAME_ORTHANC, PASSWORD_ORTHANC)

# Working directory
PLWEB_FOLDER = "/" + os.getcwd().split(os.sep)[-1]

# PDF report folder
PDF_REPORT_FOLDER = "temp_pdf_reports"

# Folder for nondicom files (tiff):
TEMP_NONDCM_FOLDER = "temp_nondicom_archive"

# Folder for temp dynalog files
TEMP_DYNALOG_FOLDER = "temp_dynalog_folder"

# Folders for dynalog database
DYNALOG_DATABASE_FOLDER = "dynalog_database"
DYNALOG_DATABASE_ARCHIVE = os.path.join(DYNALOG_DATABASE_FOLDER, "ARCHIVE")

# Folder with reference images:
REF_IMAGES_FOLDER = "reference_images"

# Folder for PlanarImaging reference images:
PLANARIMAGING_REF = os.path.join(REF_IMAGES_FOLDER, "planar_imaging")

# Folder for ct reference images:
CT_REF = os.path.join(REF_IMAGES_FOLDER, "ct")

# MLC type for PicketFence analysis:
LEAF_TYPE = ["Varian_120", "Varian_120HD", "Varian_80", "Elekta_80", "Elekta_160"]

# Dynalog sqlite3 database:
DYNALOG_DATABASE = os.path.join("dynalog_database", "dynalog_database.db")

# Leaf borders for Dynalog files (in mm):
MLC_DYNALOG = {"Varian_120": [-200.0, -190.0, -180.0, -170.0, -160.0, -150.0, -140.0, -130.0, -120.0, -110.0, -100.0, -95.0, -90.0, -85.0, -80.0, -75.0, -70.0, -65.0, -60.0, -55.0, -50.0, -45.0, -40.0, -35.0, -30.0, -25.0, -20.0, -15.0, -10.0, -5.0, 0.0, 5.0, 10.0, 15.0, 20.0, 25.0, 30.0, 35.0, 40.0, 45.0, 50.0, 55.0, 60.0, 65.0, 70.0, 75.0, 80.0, 85.0, 90.0, 95.0, 100.0, 110.0, 120.0, 130.0, 140.0, 150.0, 160.0, 170.0, 180.0, 190.0, 200.0],
              "Varian_120HD": [-110, -105, -100, -95, -90, -85, -80, -75, -70, -65, -60, -55, -50, -45, -40, -37.5, -35, -32.5, -30, -27.5, -25, -22.5, -20, -17.5, -15, -12.5, -10, -7.5, -5, -2.5, 0.0, 2.5, 5, 7.5, 10, 12.5, 15, 17.5, 20, 22.5, 25, 27.5, 30, 32.5, 35, 37.5, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100, 105, 110],
              "Varian_80": [-200.0, -190.0, -180.0, -170.0, -160.0, -150.0, -140.0, -130.0, -120.0, -110.0, -100.0, -90.0, -80.0, -70.0, -60.0, -50.0, -40.0, -30.0, -20.0, -10.0, 0.0, 10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0, 80.0, 90.0, 100.0, 110.0, 120.0, 130.0, 140.0, 150.0, 160.0, 170.0, 180.0, 190.0, 200.0],
              }

PI = np.pi

def delete_files_in_subfolders(file_paths):
    # Function for deleting images after transfer - subfolders
    for ff in file_paths:
        try:
            shutil.rmtree(ff)
        except:
            warnings.warn(ff + " could not be deleted")
            continue

def Read_from_dcm_database():
    # Function that reads from the orthanc database and gives a list of patients.
    try:
        p = RestToolbox.GetPatientIds(ORTHANC_URL)
        data = RestToolbox.GetPatientData(ORTHANC_URL, p)
    except:
        print("Orthanc is refusing connection.")
        raise

    names = []
    IDs = []
    if len(data) != 0:
        for d in data:
            try:
                names.append(d["MainDicomTags"]["PatientName"].replace("^", " "))
            except:
                names.append("UnknownPatient")
            try:
                IDs.append(d["MainDicomTags"]["PatientID"])
            except:
                IDs.append("UnknownPatientID")
    
        order = np.array(sorted(range(len(names)), key=names.__getitem__))
    
        variables = {"orthanc_id": list(np.array(p)[order]),
                     "names": list(np.array(names)[order]),
                     "IDs": list(np.array(IDs)[order]),
                     "orthanc_url": ORTHANC_URL,
                     "institution": INSTITUTION,
                     "plweb_folder": PLWEB_FOLDER
                     }
    else:
        variables = {"orthanc_id": [],
                 "names": [],
                 "IDs": [],
                 "orthanc_url": ORTHANC_URL,
                 "institution": INSTITUTION,
                 "plweb_folder": PLWEB_FOLDER
                 }
    return variables

def get_contenttime_seccheck_wl(dicomfile):
    # This function is used for consistency check. It returns content date/time
    # and instance number or image label for a specified dicom file
    metadata = dicomfile.metadata
    date_var = ""
    time_var = ""
    label = ""
    try:
        date_var = metadata.ContentDate
        time_var = metadata.ContentTime
    except:
        date_var = "Unknown ContentDate"
        time_var = "Unknown ContentTime"
    try:
        manufact = metadata.Manufacturer
    except:
        manufact = "Undefined"
    if manufact in ["Varian Medical Systems"]:
        label = metadata.RTImageLabel
    else:
        label = metadata.InstanceNumber
    return date_var, time_var, label


def delete_figure(fig_list):
    # Function for deleting matplotlib figures
    for f in fig_list:
        f.clf()

def clip_around_image(img, clip_box):
    # Function that forces edges of the images to have background values
    img_size = img.shape
    phy_size = img.physical_shape
    background = img.array.min()
    if clip_box != 0:
        if (clip_box > phy_size[0]) or (clip_box > phy_size[1]):
            raise ValueError("Clipbox larger than the image itself")
        n_tb = int((img_size[0] - clip_box*img.dpmm)/2)  # Top bottom edge
        n_lr = int((img_size[1] - clip_box*img.dpmm)/2)  # Left right edge
        img.array[:, 0:n_lr] = background
        img.array[:, -n_lr:] = background
        img.array[0:n_tb, :] = background
        img.array[-n_tb:, :] = background

def MLCpositions_to_points(posA, posB, widths):
    # Converting MLC positions from dynalog files to cartesian points.
    # posA and posB are arrays of leaf positions
    # widths is an array of leaf horizontal edge positions, ranging from
    # bottom (y1) to top (y2)
    # Returns edge points for Bank A and Bank B seperately.
    if posA.shape[0] != widths.shape[0]-1:
        raise ValueError("Number of leaves does not match the MLC model")
    widths = np.vstack((np.vstack((widths[0], np.repeat(widths[1:-1], 2, axis=0))), widths[-1]))
    posA = np.repeat(posA, 2, axis=0)
    posB = np.repeat(posB, 2, axis=0)
    return [np.column_stack((posA, widths)), np.column_stack((posB, widths))]


# Here starts the bottle server
app = Bottle()

@app.get('/<filename:re:.*\.(css)>')
def stylesheets(filename):
    # Serve css files
    return static_file(filename, root='static')

@app.get('/<filename:re:.*\.(map)>')
def stylesheets_map(filename):
    # Serve css files
    return static_file(filename, root='static')

@app.get('/<filename:re:.*\.(ttf)>')
def font_bootstrap(filename):
    # Serve font files
    return static_file(filename, root='static')

@app.get('/<filename:re:.*\.(woff)>')
def font_bootstrap_woff(filename):
    # Serve font files
    return static_file(filename, root='static')

@app.get('/<filename:re:.*\.(woff2)>')
def font_bootstrap_woff2(filename):
    # Serve font files
    return static_file(filename, root='static')

@app.get('/<filename:re:.*\.(js)>')
def javascript(filename):
    # Serve js files
    return static_file(filename, root='static')

@app.get('/<filename:re:.*\.(html)>')
def html(filename):
    # Serve html files
    return static_file(filename, root='static')

@app.get('/docs/<filepath:path>')
def server_sphinx(filepath):
    # Serve sphinx
    return static_file(filepath, root='static/docs')

@app.get('/<filename:re:.*\.(png)>')
def png(filename):
    # Serve png files
    return static_file(filename, root='static')

@app.error(500)
def custom500(error):
    return template("error_template", {"error_message": "Cause unknown.",
                                      "plweb_folder": PLWEB_FOLDER })

@app.route('/')
def redirect_to_login():
    redirect(PLWEB_FOLDER + "/login")

@app.route(PLWEB_FOLDER)
def redirect_to_login2():
    redirect(PLWEB_FOLDER + "/login")

@app.route(PLWEB_FOLDER + "/login")
def login_form():
    # Serve login page with form request
    images = ["/images/logo1.png", "/images/logo2.png", "/images/logo3.png",
              "/images/logo4.png", "/images/logo5.png", "/images/logo6.png",
              "/images/logo7.png", "/images/logo8.png", "/images/logo9.png",
              "/images/logo10.png", "/images/logo11.png"]
    images = [os.path.join("images", f) for f in os.listdir(os.path.join("static", "images")) if f.endswith('.png')]

    if len(images) != 0:
        image = random.choice(images)
    else:
        image="blank"
    return template("login", {"plweb_folder": PLWEB_FOLDER,
                              "institution": INSTITUTION,
                              "image": image})

@app.route(PLWEB_FOLDER + "/login", method='POST')
def login_submit():
    # Get form data from login page
    username = request.forms.get('username')
    password = request.forms.get('password')
    if username == USERNAME and password == PASSWORD:
        return template("menu_page", {"institution": INSTITUTION, "orthanc_url": ORTHANC_URL,
                            "plweb_folder": PLWEB_FOLDER, "qaserver_version": QASERVER_VERSION})
    else:
        return template("error_template", {"error_message": "User not recognized.",
                                           "plweb_folder": PLWEB_FOLDER,})

@app.route(PLWEB_FOLDER + '/searchStudies/<s>', method="POST")
def livesearch_study(s):
    # Function to get studies and return them to the interface
    data = RestToolbox.GetPatientData(ORTHANC_URL, [s])
    studies = data[0]["Studies"]
    data_s = RestToolbox.GetStudies(ORTHANC_URL, studies)
    study_names = []

    for p in data_s:
        try:
            name_id = p["MainDicomTags"]["StudyID"]
        except:
            name_id = ""
        try:
            name_desc = " (" + p["MainDicomTags"]["StudyDescription"] + ")"
        except:
            name_desc = ""
        if name_desc == "" and name_id == "":
            name_id = "Undefined"
        try:
            study_date = " - " + datetime.datetime.strptime(p["MainDicomTags"]["StudyDate"], "%Y%m%d").strftime("%d/%m/%Y")
        except:
            study_date = ""
        study_names.append(name_id + name_desc+study_date)
    return json.dumps((studies, study_names))


@app.route(PLWEB_FOLDER + '/searchSeries/<s>', method="POST")
def livesearch_series(s):
    # Function to get series and return to the interface
    data = RestToolbox.GetStudies(ORTHANC_URL, [s])
    series = data[0]["Series"]
    data_s = RestToolbox.GetSeries(ORTHANC_URL, series)
    series_names = []
 
    for p in data_s:
        try:
            ser_num = " (" + p["MainDicomTags"]["SeriesNumber"] + ")"
        except:
            ser_num = ""
        try:
            ser_desc = p["MainDicomTags"]["SeriesDescription"]
        except:
            ser_desc = ""
        if ser_num == "" and ser_desc == "":
            ser_num = "Undefined"

        ser_datetime = RestToolbox.GetInstances(ORTHANC_URL, [p["Instances"][0]])

        date_var = RestToolbox.get_datetime(ser_datetime[0])

        if date_var[0] == "Unknown":
            date_str = "Unknown date"
        else:
            date_str = datetime.datetime.strptime(date_var[0], "%Y%m%d").strftime("%d/%m/%Y")  # To string
        series_names.append(ser_desc + ser_num + " - " + date_str)
    return json.dumps((series, series_names))

@app.route(PLWEB_FOLDER + '/searchInstances/<s:re:.+>', method="POST")
def livesearch_instances(s):
    # Function to get single dicom files in order of time stamp
    series = s.split("/")
    instances_final_num = []
    num_instances_final = []
    instance_datetime_final = []
    instances_final = []

    for ss in series:
        p = RestToolbox.GetSeries(ORTHANC_URL, [ss])[0]
        num_instances = []
        instances = p["Instances"]
        num_instances = len(instances)
        inst_temp = RestToolbox.GetInstances(ORTHANC_URL, instances)
        instance_datetime, instance_datetime_order, instance_num = RestToolbox.order_instance_datetime(inst_temp)
        order = np.argsort(instance_datetime_order)
        
        instances_final_num += (np.asarray(instance_num)[order]).tolist()
        num_instances_final += [num_instances]
        instance_datetime_final += (np.asarray(instance_datetime)[order]).tolist()
        instances_final += (np.asarray(instances)[order]).tolist()
    # Take stationname from last element of series
    try:
        station_name = p["MainDicomTags"]["StationName"]
    except:
        station_name = "Unknown"

    return json.dumps({"1": list(np.asarray(instances_final_num)), "2": num_instances_final,
                       "3": list(np.asarray(instance_datetime_final)), "4": list(np.asarray(instances_final)),
                       "5": station_name})

@app.route(PLWEB_FOLDER + '/searchSeriesTags/<s>', method="POST")
def livesearch_series_tags(s):
    '''Used to find some data for a large series with multiple instances'''
    p = RestToolbox.GetSeries(ORTHANC_URL, [s])[0]
    instances = p["Instances"]
    num_instances = len(instances)
    tags = p["MainDicomTags"]

    try:
        ser_datetime = RestToolbox.GetInstances(ORTHANC_URL, [p["Instances"][0]])
        datetime_var = RestToolbox.get_datetime(ser_datetime[0])
        tt = datetime_var[0]+datetime_var[1]
        try:
            milisec = "."+tt[15:17]
        except:
            milisec = ".00"
        series_datetime = datetime.datetime.strptime(tt[0:14], "%Y%m%d%H%M%S").strftime("%d/%m/%Y | %H:%M:%S")+milisec
    except:
        series_datetime = "Unknown"

    try:
        manufact = tags["Manufacturer"]
    except:
        manufact = "Unknown"
    try:
        modality = tags["Modality"]
    except:
        modality = "Unknown"
    try:
        protocol = tags["ProtocolName"]
    except:
        protocol = "Unknown"
    try:
        station = tags["StationName"]
    except:
        station = "Unknown"

    return json.dumps({"1": series_datetime, "2": num_instances, "3": manufact, "4": modality, "5": protocol,
                       "6": station})


@app.route(PLWEB_FOLDER + '/getInstanceImage/<s>', method="POST")
def getinstanceimage(s):
    # Function to get png image from the instance and return it to user
    image = RestToolbox.DoGet_image(ORTHANC_URL + "/instances/" + s + "/preview")
    return base64.b64encode(image)

@app.route(PLWEB_FOLDER + '/winston_lutz', method="POST")
def winston_lutz():
    '''Function that reads from the database and gives a list of patients then returns to web.'''
    try:
        variables = Read_from_dcm_database()
        return template("winston_lutz", variables)
    except ConnectionError:
        return template("error_template", {"error_message": "Orthanc is refusing connection.",
                                           "plweb_folder": PLWEB_FOLDER})

@app.route(PLWEB_FOLDER + '/winston_lutz_calculate/<w>/<c>/<p>', method="POST")
def winston_lutz_calculate(w, c, p):
    # Function that analyzes the images and sends results to the interface
    # p is for pylinac's analysis

    pass_rate = float(CONFIG['WinstonLutz']['PASS_RATE'])  # If more than this, the test is "failed"
    success_rate = float(CONFIG['WinstonLutz']['SUCCESS_RATE'])  # If more than this, the test is "borderline", but not "failed"
    clip_box = float(w)*10.0
    s = json.loads(request.forms.get("series_list")) ## list of series to analyze!

    if p == "True": # if pylinac is chosen
        pylinac_angles = json.loads(request.forms.get("pylinacangles"))
        pylinac_angles = [int(x) if x!="" else np.nan for x in pylinac_angles]
        pylinac_angles_array = np.array(pylinac_angles).reshape((-1, 3))
 
        folder_path, file_paths = RestToolbox.GetSeries2Folder(ORTHANC_URL, s)

        # IF user entered values for gantry/couch/coll angles change file names:
        if pylinac_angles.count(np.nan) == 0:
            if pylinac_angles_array.shape[0] != len(file_paths):
                return template("error_template", {"error_message": "The number of angles does not match the number of images.", "plweb_folder": PLWEB_FOLDER})

            for z in range(0, len(file_paths), 1):
                f = file_paths[z]
                os.replace(f, os.path.join(folder_path, "img"+str(z+1)+"_gantry" + str(pylinac_angles_array[z, 0]) + "_coll"+str(pylinac_angles_array[z, 1])+
                          "_couch"+str(pylinac_angles_array[z, 2])))

        if clip_box != 0:
            for filename in file_paths:
                try:
                    orig_img = pylinacimage.DicomImage(filename)
                    orig_img.check_inversion() # Check inversion otherwise this might not work
                    clip_around_image(orig_img, clip_box)
                    orig_img.save(filename)
                except:
                    return template("error_template", {"error_message": "Unable to apply clipbox.", "plweb_folder": PLWEB_FOLDER})
    else:
        file_paths = RestToolbox.GetSeries2Subfolders(ORTHANC_URL, s)

        if clip_box != 0:
            for subfolder in file_paths:    
                for filename in os.listdir(subfolder):
                    try:
                        orig_img = pylinacimage.DicomImage(os.path.join(subfolder, filename))
                        orig_img.check_inversion() # Check inversion otherwise this might not work
                        clip_around_image(orig_img, clip_box)
                        orig_img.save(os.path.join(subfolder, filename))
                    except:
                        return template("error_template", {"error_message": "Unable to apply clipbox.", "plweb_folder": PLWEB_FOLDER})


    # If the user wants pylinac's analysis:
    if p == "True":
        if pylinac_angles.count(np.nan) == 0:
            use_filenames = True
        else:
            use_filenames = False
        try:
            wl = WinstonLutz(folder_path, use_filenames=use_filenames)
        except Exception as e:
            delete_files_in_subfolders([folder_path])
            return template("error_template", {"error_message": "Module WinstonLutz cannot calculate. "+str(e),
                                               "plweb_folder": PLWEB_FOLDER})

        pdf_file = tempfile.NamedTemporaryFile(delete=False, prefix="pylinac_", suffix=".pdf", dir=PDF_REPORT_FOLDER)
        try:
            stationname = wl.images[0].metadata.StationName
        except:
            stationname = ""
        try:
            date_time = wl.images[0].metadata.ContentDate
            date_var = datetime.datetime.strptime(date_time, "%Y%m%d").strftime("%d/%m/%Y")
        except:
            date_var = ""
        wl.publish_pdf(pdf_file, notes=["Date = "+date_var, "Station = "+stationname])
        pdf_file.close()
        
        def fill_axis_figure(images):
            # Function that fills the figure with axis images. Images is a list of images.
            N = len(images)
            if N % 2 == 0:
                rows =  int(N/2)
            else:
                rows = int(N//2) + 1
            
            fig = Figure(figsize=(8, 4*rows))
            
            for m in range(0, len(images), 1):
                ax = fig.add_subplot(rows, 2, m+1)
                img = images[m]
                array = img.array
                cmap = matplotlib.cm.Greys  
                
                # Plot the array and the contour of the 50 percent isodose line
                ax.imshow(array, cmap=cmap, interpolation="none",  origin='lower')
                level = np.average(np.percentile(array, [5, 99.9]))
                ax.contour(array, levels=[level], colors = ["blue"])  # CAX
        
                # Plot centers: field, BB, EPID
                ax.plot(img.field_cax.x, img.field_cax.y, 'b+', markersize=24, markeredgewidth=3, zorder=2)
                ax.plot(img.bb.x, img.bb.y, 'r+', markersize=24, markeredgewidth=3, zorder=2)
                ax.plot(img.epid.x, img.epid.y, 'yo', ms=10, markeredgewidth=0.0, zorder=1)

                ax.set_title(f"Gantry={img.gantry_angle:.0f}, Coll.={img.collimator_angle:.0f}, Couch={img.couch_angle:.0f}")
                ax.set_ylabel(f"CAX to BB: {img.cax2bb_distance:3.2f}mm")

                # Plot edges of untouched area with a line:
                if clip_box != 0:
                    n_t = int((img.shape[0] + clip_box*img.dpmm)/2)  # Top  edge
                    n_b = int((img.shape[0] - clip_box*img.dpmm)/2)  # bottom edge
                    n_l = int((img.shape[1] - clip_box*img.dpmm)/2)  # Left  edge
                    n_r = int((img.shape[1] + clip_box*img.dpmm)/2)  #  right edge
                    ax.plot([n_l, n_l, n_r, n_r, n_l], [n_b, n_t, n_t, n_b, n_b], "-g")
        
                if c == "True":
                    # If zoom is used:
                    ax.set_ylim(img.rad_field_bounding_box[0], img.rad_field_bounding_box[1])
                    ax.set_xlim(img.rad_field_bounding_box[2], img.rad_field_bounding_box[3])
                    ax.autoscale(False)
                else:
                    ax.autoscale(True)
                fig.set_tight_layout(True)
            return fig

        # Plot images
        axis_images = [None, None, None, None, None]
        if wl._contains_axis_images("Gantry"):
            images = [image for image in wl.images if image.variable_axis in ("Gantry", "Reference")]
            axis_images[0] = mpld3.fig_to_html(fill_axis_figure(images), d3_url=D3_URL, mpld3_url=MPLD3_URL)
        if wl._contains_axis_images("Collimator"):
            images = [image for image in wl.images if image.variable_axis in ("Collimator", "Reference")]
            axis_images[1] = mpld3.fig_to_html(fill_axis_figure(images), d3_url=D3_URL, mpld3_url=MPLD3_URL)
        if wl._contains_axis_images("Couch"):
            images = [image for image in wl.images if image.variable_axis in ("Couch", "Reference")]
            axis_images[2] = mpld3.fig_to_html(fill_axis_figure(images), d3_url=D3_URL, mpld3_url=MPLD3_URL)
        if wl._contains_axis_images("Combo"):
            images = [image for image in wl.images if image.variable_axis in ("Combo", "Reference")]
            axis_images[3] = mpld3.fig_to_html(fill_axis_figure(images), d3_url=D3_URL, mpld3_url=MPLD3_URL)
        
        # If none of the above, just plot all the images
        if all([element==None for element in axis_images[:-1]]):
            images = [image for image in wl.images]
            axis_images[4] = mpld3.fig_to_html(fill_axis_figure(images), d3_url=D3_URL, mpld3_url=MPLD3_URL)

        # Plot wobble images:
        # Take as a reference: CAX for couch images, BB for collimator and gantry images
        fig_wobble = Figure(figsize=(9, 3))
        n = 0
        for axis in ("Gantry", "Collimator", "Couch"):
            if wl._get_images((axis, "Reference"))[0] > 1:
                images = [image for image in wl.images if image.variable_axis in (axis, "Reference")]
                ax_wobble = fig_wobble.add_subplot(1, 3, n+1)
                img = images[0]
                array = img.array
                cmap = matplotlib.cm.Greys  
                ax_wobble.imshow(array, cmap=cmap, interpolation="none",  origin='lower')
                ax_wobble.plot(img.bb.x, img.bb.y, 'r+', markersize=12, markeredgewidth=2, zorder=2)
                ax_wobble.plot(img.field_cax.x, img.field_cax.y, 'b+', markersize=12, markeredgewidth=2, zorder=2)
                ax_wobble.plot(img.epid.x, img.epid.y, 'yo', ms=5, markeredgewidth=0.0, zorder=1)

                if axis != "Couch":
                    # plot EPID
                    ref_x = img.bb.x
                    ref_y = img.bb.y
                    epid_xs = [ref_x + imgg.epid.x - imgg.bb.x for imgg in images[1:]]
                    epid_ys = [ref_y + imgg.epid.y - imgg.bb.y for imgg in images[1:]]
                    ax_wobble.plot(epid_xs, epid_ys, 'yo', ms=5, markeredgewidth=0.0, zorder=1)
                    # get CAX positions
                    xs = [ref_x + imgg.field_cax.x - imgg.bb.x for imgg in images[1:]]
                    ys = [ref_y + imgg.field_cax.y - imgg.bb.y for imgg in images[1:]]
                    ax_wobble.plot(xs, ys, 'b+', markersize=12, markeredgewidth=2, zorder=2)
                    circle = patches.Circle((ref_x, ref_y), 1.0*img.dpmm, color='cyan', zorder=2, fill=False, linestyle='--')
                    ax_wobble.add_patch(circle)
                else:
                    # get BB positions
                    ref_x = img.field_cax.x
                    ref_y = img.field_cax.y
                    xs = [ref_x + imgg.bb.x - imgg.field_cax.x for imgg in images[1:]]
                    ys = [ref_y + imgg.bb.y - imgg.field_cax.y for imgg in images[1:]]
                    ax_wobble.plot(xs, ys, 'r+', markersize=12, markeredgewidth=2, zorder=2)
                    circle_couch = patches.Circle((ref_x, ref_y), 1.0*img.dpmm, color='cyan', zorder=2, fill=False, linestyle='--')
                    ax_wobble.add_patch(circle_couch)

                # Zoom in on BB
                center_x, center_y = int(round(ref_x)), int(round(ref_y))
                extent = int(round(5.0*img.dpmm))
                ax_wobble.set_ylim(center_y-extent, center_y+extent)
                ax_wobble.set_xlim(center_x-extent, center_x+extent)
                ax_wobble.autoscale(False)
                ax_wobble.set_title(axis + ' wobble')
                ax_wobble.set_xlabel(axis + f" iso size: {getattr(wl, axis.lower() + '_iso_size'):3.2f} mm")
                n += 1
        fig_wobble.set_tight_layout(True)

        if n == 0:
            script_wobble = None
        else:
            script_wobble = mpld3.fig_to_html(fig_wobble, d3_url=D3_URL, mpld3_url=MPLD3_URL)
        
        # Plot deviations from pylinac:
        dev_rows = 2
        if wl._get_images(("Collimator", "Reference"))[0] > 1:
            dev_rows += 1
        if wl._get_images(("Couch", "Reference"))[0] > 1:
            dev_rows += 1
        
        fig_gantry_epid_sag = Figure(figsize=(8, 3*dev_rows))
        gantry_sag_ax = fig_gantry_epid_sag.add_subplot(dev_rows,1,1)
        wl._plot_deviation("Gantry", gantry_sag_ax, show=False)
        gantry_sag_ax.legend(numpoints=1, framealpha =0.8)
        epid_sag_ax = fig_gantry_epid_sag.add_subplot(dev_rows,1,2)
        wl._plot_deviation("Epid", epid_sag_ax, show=False)
        epid_sag_ax.legend(numpoints=1, framealpha =0.8)
        
        plot_row = 0
        if wl._get_images(("Collimator", "Reference"))[0] > 1:
            coll_sag_ax = fig_gantry_epid_sag.add_subplot(dev_rows, 1, 3+plot_row)
            wl._plot_deviation("Collimator", coll_sag_ax, show=False)
            coll_sag_ax.legend(numpoints=1, framealpha =0.8)
            plot_row += 1
        if wl._get_images(("Couch", "Reference"))[0] > 1:
            couch_sag_ax = fig_gantry_epid_sag.add_subplot(dev_rows,1, 3+plot_row)
            wl._plot_deviation("Couch", couch_sag_ax, show=False)
            couch_sag_ax.legend(numpoints=1, framealpha =0.8)

        fig_gantry_epid_sag.set_tight_layout(True)
        script_gantry_epid_sag = mpld3.fig_to_html(fig_gantry_epid_sag, d3_url=D3_URL, mpld3_url=MPLD3_URL)
        
        cax_position = []
        bb_position = []
        cax2bb = []
        epid2bb = []
        result = []
        radius = []
        SIDs = []
        image_type = []
        gbp = []
        gantries = []
        collimators = []
        couches = []

        N = len(wl.images)
        for n in range(0, N, 1):
            img = wl.images[n]
            dpmm = img.dpmm
            cax_position.append([-(img.epid.x-img.field_cax.x)/dpmm, -(img.epid.y-img.field_cax.y)/dpmm])
            bb_position.append([-(img.epid.x-img.bb.x)/dpmm, -(img.epid.y-img.bb.y)/dpmm])
            vec = [(img.field_cax.x - img.bb.x)/dpmm, (img.field_cax.y - img.bb.y)/dpmm]  # From BB to CAX (BB in the center)
            cax2bb.append(vec)
            epid2bb.append([(img.epid.x - img.bb.x)/dpmm, (img.epid.y - img.bb.y)/dpmm])
            SIDs.append(img.sid)
            result.append([vec[0], vec[1]])
            radius.append(np.sqrt(vec[0]*vec[0] + vec[1]*vec[1]))
            image_type.append(img.variable_axis)
            gbp.append(f"G={img.gantry_angle:.0f}, B={img.collimator_angle:.0f}, P={img.couch_angle:.0f}")
            gantries.append(f"{img.gantry_angle:.0f}")
            collimators.append(f"{img.collimator_angle:.0f}")
            couches.append(f"{img.couch_angle:.0f}")
                

        # Get other results
        quickresults = [f"Maximum 2D CAX->BB distance: {wl.cax2bb_distance('max'):.2f} mm",
                        f"Median 2D CAX->BB distance: {wl.cax2bb_distance('median'):.2f} mm",
                        f"Shift BB to iso, facing gantry: {wl.bb_shift_instructions()}",
                        f"Gantry 3D isocenter diameter: {wl.gantry_iso_size:.2f} mm",
                        f"Maximum Gantry RMS deviation (mm): {max(wl.axis_rms_deviation('Gantry')):.2f} mm",
                        f"Maximum EPID RMS deviation (mm): {max(wl.axis_rms_deviation('Epid')):.2f} mm",
                        f"Collimator 2D isocenter diameter: {wl.collimator_iso_size:.2f} mm",
                        f"Maximum Collimator RMS deviation (mm): {max(wl.axis_rms_deviation('Collimator')):.2f}",
                        f"Couch 2D isocenter diameter: {wl.couch_iso_size:.2f} mm",
                        f"Maximum Couch RMS deviation (mm): {max(wl.axis_rms_deviation('Couch')):.2f}"
                        ]

        # Add scatter plot for the diagram
        fig_focal = Figure(figsize=(7, 7))
        ax_focal = fig_focal.add_subplot(1,1,1)

        cax2bb = np.asarray(cax2bb)
        epid2bb = np.asarray(epid2bb)

        colors = ["blue"]*N
        colors2 = ["yellow"]*N
        labels = ['G={:d}, B={:d}, P={:d}, x = {:04.2f} mm, y = {:04.2f} mm, R = {:04.2f} mm'.format(int(wl.images[i].gantry_angle), int(wl.images[i].collimator_angle),
                  int(wl.images[i].couch_angle), cax2bb[i, 0], cax2bb[i, 1], np.linalg.norm(cax2bb[i, :])) for i in range(N)]
        labels2 = ['G={:d}, B={:d}, P={:d}, x = {:04.2f} mm, y = {:04.2f} mm, R = {:04.2f} mm'.format(int(wl.images[i].gantry_angle), int(wl.images[i].collimator_angle),
                  int(wl.images[i].couch_angle), epid2bb[i, 0], epid2bb[i, 1], np.linalg.norm(epid2bb[i, :])) for i in range(N)]
        ax_focal.scatter(cax2bb[:,0], cax2bb[:, 1], c=colors, alpha=0.5,  s=80, zorder=1, linewidths=1)
        ax_focal.scatter(epid2bb[:,0], epid2bb[:, 1], c=colors2, alpha=0.5,  s=80, zorder=1, linewidths=1)
        scatter = ax_focal.plot(cax2bb[:,0], cax2bb[:, 1], linestyle="-", color="none", alpha=0.5, marker="o", zorder=2,  markerfacecolor='none', markeredgecolor='none')
        scatter2 = ax_focal.plot(epid2bb[:,0], epid2bb[:, 1], linestyle="-", color="none", alpha=0.5, marker="o", zorder=2,  markerfacecolor='none', markeredgecolor='none')
        tooltip = mpld3.plugins.PointLabelTooltip(scatter[0], labels=labels, location="top left")
        tooltip2 = mpld3.plugins.PointLabelTooltip(scatter2[0], labels=labels2, location="top left")
        mpld3.plugins.connect(fig_focal, tooltip, tooltip2)

        # Legend labels:
        ax_focal.plot([],[], c="blue", linestyle="None", alpha=0.5, marker="o", label="CAX")
        ax_focal.plot([],[], c="yellow", linestyle="None", alpha=0.5, marker="o", label="EPID")

        limits_focal = pass_rate + 0.2 # Define the extent of the diagram
        p = ax_focal.plot([0],[0], "r+", mew=3, ms=10, label="BB")
        tooltip3 = mpld3.plugins.PointLabelTooltip(p[0], labels=["Ballbearing"], location="top left")
        mpld3.plugins.connect(fig_focal, tooltip3)
        ax_focal.add_patch(patches.Circle((0, 0), pass_rate, color='r', linestyle="dashed", fill=False))
        ax_focal.add_patch(patches.Circle((0, 0), success_rate, color='g', linestyle="dashed", fill=False))
        ax_focal.autoscale(False)
        ax_focal.set_xlim([-limits_focal, limits_focal])
        ax_focal.set_ylim([-limits_focal, limits_focal])
        ax_focal.set_title("Scatter diagram")
        ax_focal.set_xlabel("X [mm]")
        ax_focal.set_ylabel("Y [mm]")
        ax_focal.legend(framealpha=0, numpoints=1, ncol=3, loc='lower right', fontsize=8)
        fig_focal.set_tight_layout(True)

        script_focal = mpld3.fig_to_html(fig_focal, d3_url=D3_URL, mpld3_url=MPLD3_URL)
        delete_figure([fig_wobble, fig_focal, fig_gantry_epid_sag])

        delete_files_in_subfolders([folder_path]) # Delete temporary images

        variables = {
                     "institution": INSTITUTION,
                     "datetime": strftime("%d. %m. %Y,  %H:%M:%S", gmtime()),
                     "pdf_report_filename": os.path.basename(pdf_file.name),
                     "plweb_folder": PLWEB_FOLDER,
                     "axis_images": axis_images,
                     "max_deviation": round(np.max(radius), 2),
                     "radius": radius,
                     "pass_rate": pass_rate,
                     "success_rate": success_rate,
                     "SIDs": list(set(SIDs)),
                     "cax_position": cax_position,
                     "bb_position": bb_position,
                     "result": result,
                     "image_type": image_type,
                     "gbp": gbp,
                     "gantries": gantries,
                     "collimators": collimators,
                     "couches": couches,
                     "script_focal": script_focal,
                     "script_wobble": script_wobble,
                     "script_gantry_epid_sag": script_gantry_epid_sag,
                     "quickresults": quickresults
                     }

        return template("winston_lutz_pylinac_results", variables)

    else:
        # This is the non-pylinac analysis
        N = len(file_paths)
        if N % 2 == 0:
            rows = int(N/2)
        else:
            rows = int(N//2) + 1

        cax_position = []
        bb_position = []
        cax2bb = []
        result = []
        radius = []
        SIDs = []
        epid2bb = []

        # Draw matrix of each image
        fig_wl = Figure(figsize=(8, 4*rows))
        cmap = matplotlib.cm.Greys
        for m in range(0, N, 1):
            ax = fig_wl.add_subplot(rows, 2, m+1)
            try:
                wl = WinstonLutz(file_paths[m], use_filenames=False)
            except Exception as e:
                delete_files_in_subfolders(file_paths)
                delete_figure([fig_wl])
                return template("error_template", {"error_message": "Module WinstonLutz cannot calculate. "
                                                   "Check image number "+str(m+1)+". "+str(e),
                                                   "plweb_folder": PLWEB_FOLDER})

            img = wl.images[0]

            array = img.array
            dpmm = img.dpmm

            cax_position.append([-(img.epid.x-img.field_cax.x)/dpmm, -(img.epid.y-img.field_cax.y)/dpmm])
            bb_position.append([-(img.epid.x-img.bb.x)/dpmm, -(img.epid.y-img.bb.y)/dpmm])
            vec = [(img.field_cax.x - img.bb.x)/dpmm, (img.field_cax.y - img.bb.y)/dpmm]  # From BB to CAX (BB in the center)
            cax2bb.append(vec)
            epid2bb.append([(img.epid.x - img.bb.x)/dpmm, (img.epid.y - img.bb.y)/dpmm])
            SIDs.append(img.sid)
            result.append([vec[0], vec[1]])
            radius.append(np.sqrt(vec[0]*vec[0] + vec[1]*vec[1]))

            # Plot the array and the contour of the 50 percent isodose line
            ax.imshow(array, cmap=cmap, interpolation="none",  origin='lower')
            level = np.average(np.percentile(array, [5, 99.9]))
            ax.contour(array, levels=[level], colors = ["blue"])  # CAX
    
            # Plot centers: field, BB, EPID
            ax.plot(img.field_cax.x, img.field_cax.y, 'b+', markersize=24, markeredgewidth=3, zorder=2)
            ax.plot(img.bb.x, img.bb.y, 'r+', markersize=24, markeredgewidth=3, zorder=2)
            ax.plot(img.epid.x, img.epid.y, 'yo', ms=10, markeredgewidth=0.0, zorder=1)
            ax.set_title(str(m+1)+". dx = "+str(round(vec[0], 2))+" mm,  dy = "+str(round(vec[1], 2))+" mm")

            # Plot edges of untouched area with a line:
            if clip_box != 0:
                n_t = int((img.shape[0] + clip_box*img.dpmm)/2)  # Top  edge
                n_b = int((img.shape[0] - clip_box*img.dpmm)/2)  # bottom edge
                n_l = int((img.shape[1] - clip_box*img.dpmm)/2)  # Left  edge
                n_r = int((img.shape[1] + clip_box*img.dpmm)/2)  #  right edge
                ax.plot([n_l, n_l, n_r, n_r, n_l], [n_b, n_t, n_t, n_b, n_b], "-g")
    
            if c == "True":
                # If zoom is used:
                ax.set_ylim(img.rad_field_bounding_box[0], img.rad_field_bounding_box[1])
                ax.set_xlim(img.rad_field_bounding_box[2], img.rad_field_bounding_box[3])
                ax.autoscale(False)
            else:
                ax.autoscale(True)

        fig_wl.set_tight_layout(True)
        script = mpld3.fig_to_html(fig_wl, d3_url=D3_URL, mpld3_url=MPLD3_URL)
        delete_figure([fig_wl])

        # Add scatter plot for the diagram
        fig_focal = Figure(figsize=(7, 7))
        ax_focal = fig_focal.add_subplot(1,1,1)

        cax2bb = np.asarray(cax2bb)
        epid2bb = np.asarray(epid2bb)

        colors = ["blue"]*N
        colors2 = ["yellow"]*N
        labels = ['Img = {:d}, x = {:04.2f} mm, y = {:04.2f} mm, R = {:04.2f} mm'.format(i+1, cax2bb[i, 0], cax2bb[i, 1], 
                  np.linalg.norm(cax2bb[i, :])) for i in range(N)]
        labels2 = ['Img = {:d}, x = {:04.2f} mm, y = {:04.2f} mm, R = {:04.2f} mm'.format(i+1, epid2bb[i, 0], epid2bb[i, 1], 
                  np.linalg.norm(epid2bb[i, :])) for i in range(N)]
        ax_focal.scatter(cax2bb[:,0], cax2bb[:, 1], c=colors, alpha=0.5,  s=60, zorder=1, linewidths=1)
        ax_focal.scatter(epid2bb[:,0], epid2bb[:, 1], c=colors2, alpha=0.5,  s=80, zorder=1, linewidths=1)
        scatter = ax_focal.plot(cax2bb[:,0], cax2bb[:, 1], linestyle="-", color="green", alpha=0.5, marker="o", zorder=2,  markerfacecolor='none', markeredgecolor='none')
        scatter2 = ax_focal.plot(epid2bb[:,0], epid2bb[:, 1], linestyle="-", color="none", alpha=0.5, marker="o", zorder=2,  markerfacecolor='none', markeredgecolor='none')
        tooltip = mpld3.plugins.PointLabelTooltip(scatter[0], labels=labels, location="top left")
        tooltip2 = mpld3.plugins.PointLabelTooltip(scatter2[0], labels=labels2, location="top left")
        mpld3.plugins.connect(fig_focal, tooltip, tooltip2)

        # Legend labels:
        ax_focal.plot([],[], c="blue", linestyle=None, alpha=0.5, marker="o", label="CAX")
        ax_focal.plot([],[], c="yellow", linestyle=None, alpha=0.5, marker="o", label="EPID")

        limits_focal = pass_rate + 0.2 # Define the extent of the diagram
        p = ax_focal.plot([0],[0], "r+", mew=3, ms=10, label="BB")
        tooltip3 = mpld3.plugins.PointLabelTooltip(p[0], labels=["Ballbearing"], location="top left")
        mpld3.plugins.connect(fig_focal, tooltip3)
        ax_focal.add_patch(patches.Circle((0, 0), pass_rate, color='r', linestyle="dashed", fill=False))
        ax_focal.add_patch(patches.Circle((0, 0), success_rate, color='g', linestyle="dashed", fill=False))
        ax_focal.autoscale(False)
        ax_focal.set_xlim([-limits_focal, limits_focal])
        ax_focal.set_ylim([-limits_focal, limits_focal])
        ax_focal.set_title("Scatter diagram")
        ax_focal.set_xlabel("X [mm]")
        ax_focal.set_ylabel("Y [mm]")
        ax_focal.legend(framealpha=0, numpoints=1, ncol=3, loc='lower right', fontsize=8)
        fig_focal.set_tight_layout(True)

        script_focal = mpld3.fig_to_html(fig_focal, d3_url=D3_URL, mpld3_url=MPLD3_URL)
        delete_figure([fig_focal])
    
        # Calculate radius from center of CAX cloud to CAX:
        average_x = np.average(cax2bb[:, 0])
        average_y = np.average(cax2bb[:, 1])
        cax_wobble = np.linalg.norm(np.column_stack((cax2bb[:, 0]-average_x, cax2bb[:, 1]-average_y)), axis=1)

        # Calculate max EPID center to BB:
        epid2bb_max = np.max(np.linalg.norm(bb_position, axis=1))
    
        delete_files_in_subfolders(file_paths) # Delete temporary images (all subfolders)
        variables = {
                     "institution": INSTITUTION,
                     "datetime": strftime("%d. %m. %Y,  %H:%M:%S", gmtime()),
                     "script": script,
                     "script_focal": script_focal,
                     "cax_position": cax_position,
                     "bb_position": bb_position,
                     "result": result,
                     "max_deviation": round(np.max(radius), 2),
                     "cax_wobble_avg": np.average(cax_wobble),
                     "cax_wobble_max": np.max(cax_wobble),
                     "epid2bb_max": epid2bb_max,
                     "radius": radius,
                     "pass_rate": pass_rate,
                     "success_rate": success_rate,
                     "SIDs": list(set(SIDs)),
                     "apply_tolerance_to_coll_asym": CONFIG['WinstonLutz']['APPLY_TOLERANCE_TO_COLL_ASYM']
                     }
        #gc.collect() # Collect and delete mpl plots

        return template("winston_lutz_results", variables)

@app.route(PLWEB_FOLDER + '/winstonlutz_pdf_export', method="post")
def winstonlutz_pdf_export():
    # Send the pdf file to the user
    pdf_file = str(request.forms.get("hidden_wl_pdf_report"))
    return static_file(pdf_file, root=PDF_REPORT_FOLDER, download=pdf_file)

@app.route(PLWEB_FOLDER + '/starshot', method="POST")
def starshot_module():
    """Read from database and return list of patients"""
    """Send the main page of the starshot module"""
    try:
        variables = Read_from_dcm_database()
    except ConnectionError:
        return template("error_template", {"error_message": "Orthanc is refusing connection.",
                                           "plweb_folder": PLWEB_FOLDER})
    return template("starshot", variables)

def starshot_helperf(args):
    '''This function is used to calculated results for the starshot module'''
    '''It is used with the multiprocessing module in order to clear memory
        after execution'''

    imgtype = args["imgtype"]
    w = args["w"]
    clip_box = args["clip_box"]
    radius = args["radius"]
    min_peak_height = args["min_peak_height"]
    start_x = args["start_x"]
    start_y = args["start_y"]
    dpi = args["dpi"]
    sid = args["sid"]
    fwhm = args["fwhm"]
    recursive = args["recursive"]
    invert = args["invert"]
    temp_folder = args["temp_folder"]
    file_path = args["file_path"]
    tolerance = float(CONFIG["Starshot"]["TOLERANCE"])

    if start_x==0 or start_y==0:
        start_point=None
    else:
        start_point=(start_x, start_y)

    if sid==0.0 and dpi==0:
        try:
            star = Starshot(file_path)
        except Exception as e:
            return template("error_template", {"error_message": "The Starshot module cannot calculate. "+str(e),
                                               "plweb_folder": PLWEB_FOLDER})
    elif sid==0.0 and dpi!=0:
        try:
            star = Starshot(file_path, dpi=dpi)
        except Exception as e:
            return template("error_template", {"error_message": "The Starshot module cannot calculate. "+str(e),
                                               "plweb_folder": PLWEB_FOLDER})
    elif sid!=0.0 and dpi==0:
        try:
            star = Starshot(file_path, sid=sid)
        except Exception as e:
            return template("error_template", {"error_message": "The Starshot module cannot calculate. "+str(e),
                                               "plweb_folder": PLWEB_FOLDER})
    else:
        try:
            star = Starshot(file_path, dpi=dpi, sid=sid)
        except Exception as e:
            return template("error_template", {"error_message": "The Starshot module cannot calculate. "+str(e),
                                               "plweb_folder": PLWEB_FOLDER})
    
    # Here we force pixels to background outside of box:
    if clip_box != 0:
        try:
            star.image.check_inversion_by_histogram(percentiles=[4, 50, 96]) # Check inversion otherwise this might not work
            clip_around_image(star.image, clip_box)
        except Exception as e:
            return template("error_template", {"error_message": "Unable to apply clipbox. "+str(e), "plweb_folder": PLWEB_FOLDER})
    
    # If inversion is selected:
    if invert:
        star.image.invert()

    # Now we try to analyse
    try:
        star.analyze(radius=radius, min_peak_height=min_peak_height, tolerance=tolerance,
                     start_point=start_point, fwhm=fwhm, recursive=recursive)
    except Exception as e:
        return template("error_template", {"error_message": "Module Starshot cannot calculate. "+str(e),
                                           "plweb_folder": PLWEB_FOLDER})

    fig_ss = Figure(figsize=(10, 6), tight_layout={"w_pad":4})
    img_ax = fig_ss.add_subplot(1,2,1)
    wobble_ax = fig_ss.add_subplot(1,2,2)

    img_ax.imshow(star.image.array, cmap=matplotlib.cm.gray, interpolation="none", aspect="equal", origin='upper')

    star.lines.plot(img_ax)
    star.wobble.plot2axes(img_ax, edgecolor='green')
    star.circle_profile.plot2axes(img_ax, edgecolor='green')
    img_ax.axis('off')
    img_ax.autoscale(tight=True)
    img_ax.set_aspect(1)
    img_ax.set_xticks([])
    img_ax.set_yticks([])

    star.lines.plot(wobble_ax)
    star.wobble.plot2axes(wobble_ax, edgecolor='green')
    star.circle_profile.plot2axes(wobble_ax, edgecolor='green')
    wobble_ax.axis('off')
    xlims = [star.wobble.center.x + star.wobble.diameter, star.wobble.center.x - star.wobble.diameter]
    ylims = [star.wobble.center.y + star.wobble.diameter, star.wobble.center.y - star.wobble.diameter]
    wobble_ax.set_xlim(xlims)
    wobble_ax.set_ylim(ylims)
    wobble_ax.axis('on')
    wobble_ax.set_aspect(1)

    script = mpld3.fig_to_html(fig_ss, d3_url=D3_URL, mpld3_url=MPLD3_URL)

    variables = {
                 "script": script,
                 "passed": star.passed,
                 "radius": star.wobble.radius_mm,
                 "tolerance": star.tolerance,
                 "circle_center": star.wobble.center,
                 "plweb_folder": PLWEB_FOLDER,
                 "pdf_report_enable": CONFIG['Starshot']['GENERATE_PDF_REPORT']
                 }
 
    # Generate pylinac report:
    if CONFIG['Starshot']['GENERATE_PDF_REPORT'] == "True":
        pdf_file = tempfile.NamedTemporaryFile(delete=False, prefix="Starshot_", suffix=".pdf", dir=PDF_REPORT_FOLDER)
        if imgtype == "dicom":
            metadata = RestToolbox.GetInstances(ORTHANC_URL, [w])
            try:
                patient = metadata[0]["PatientName"]
            except:
                patient = ""
            try:
                stationname = metadata[0]["StationName"]
            except:
                stationname = ""
            try:
                date_time = RestToolbox.get_datetime(metadata[0])
                date_var = datetime.datetime.strptime(date_time[0], "%Y%m%d").strftime("%d/%m/%Y")
            except:
                date_var = ""

            star.publish_pdf(pdf_file, notes=["Date = "+date_var, "Patient = "+patient, "Station = "+stationname])
        else:
            star.publish_pdf(pdf_file)
        variables["pdf_report_filename"] = os.path.basename(pdf_file.name)

    delete_figure([fig_ss])
    delete_files_in_subfolders([temp_folder]) # Delete image
    return template("starshot_results", variables)

@app.route(PLWEB_FOLDER + '/starshot_calculate/<imgtype>/<w>', method="POST")
def starshot_calculate(imgtype, w):
    '''Function that analyzes the starshot image'''
    '''It uses starshot_helperf to calculate stuff'''
    # w is the image
    clip_box = float(request.forms.get('hidden_clipbox'))*10.0
    radius = float(request.forms.get('hidden_radius'))
    min_peak_height = float(request.forms.get('hidden_mph'))
    start_x = int(request.forms.get('hidden_px'))
    start_y = int(request.forms.get('hidden_py'))
    dpi = int(request.forms.get('hidden_dpi'))
    sid = float(request.forms.get('hidden_sid'))

    fwhm = True if request.forms.get('hidden_fwhm')=="true" else False
    recursive = True if request.forms.get('hidden_recursive')=="true" else False
    invert = True if request.forms.get('hidden_invert')=="true" else False
    # Get either dicom or non-dicom file
    if imgtype == "dicom":
        temp_folder, file_path = RestToolbox.GetSingleDcm(ORTHANC_URL, w)
    else:
        if request.files.get("input_nondicom_file") is not None:
            upload = request.files.get("input_nondicom_file")
            if os.path.splitext(upload.filename)[1] == ".tif":
                temp_folder = tempfile.mkdtemp(prefix=os.path.splitext(upload.filename)[0]+"_", dir=TEMP_NONDCM_FOLDER)
                file_path = os.path.join(temp_folder, upload.filename)
                with open(file_path, "wb") as dst:
                    upload.save(dst, overwrite=False)
                dst.close()
            else:
                return template("error_template", {"error_message": "Please load a valid image file.",
                                                   "plweb_folder": PLWEB_FOLDER})
        else:
            return template("error_template", {"error_message": "Please load a valid image file.",
                                               "plweb_folder": PLWEB_FOLDER})

    args = {"imgtype": imgtype, "w": w, "clip_box": clip_box, "radius":radius, "min_peak_height":min_peak_height,
            "start_x": start_x, "start_y":start_y, "dpi":dpi, "sid":sid, "fwhm":fwhm,"recursive":recursive,  "invert":invert, 
            "temp_folder": temp_folder, "file_path":file_path}
    p = Pool(1)
    data = p.map(starshot_helperf, [args])
    p.close()
    p.join()
    return data

@app.route(PLWEB_FOLDER + '/picket_fence', method="POST")
def picket_fence():
    """Read from database and return list of patients"""
    try:
        variables = Read_from_dcm_database()
    except ConnectionError:
        return template("error_template", {"error_message": "Orthanc is refusing connection.",
                                           "plweb_folder": PLWEB_FOLDER})
    variables["LEAF_TYPE"] = LEAF_TYPE
    return template("picket_fence", variables)

def picket_fence_helperf(args):
    '''This function is used in order to prevent memory problems'''
    temp_folder = args["temp_folder"]
    file_path = args["file_path"]
    clip_box = args["clip_box"]
    py_filter = args["py_filter"]
    num_pickets = args["num_pickets"]
    sag = args["sag"]
    mlc = args["mlc"]
    invert = args["invert"]
    orientation = args["orientation"]
    w = args["w"]

    tolerance = float(CONFIG['PicketFence']['TOLERANCE'])
    action_tol = float(CONFIG['PicketFence']['ACTION_TOLERANCE'])

    try:
        pf = PicketFence(file_path, filter=py_filter)
    except Exception as e:
        return template("error_template", {"error_message": "Module PicketFence cannot calculate. "+str(e),
                                           "plweb_folder": PLWEB_FOLDER})

    # Here we force pixels to background outside of box:
    if clip_box != 0:
        try:
            pf.image.check_inversion_by_histogram(percentiles=[4, 50, 96]) # Check inversion otherwise this might not work
            clip_around_image(pf.image, clip_box)
        except Exception as e:
            return template("error_template", {"error_message": "Unable to apply clipbox. "+str(e), "plweb_folder": PLWEB_FOLDER})

    # Now invert if needed
    if invert:
        try:
            pf.image.invert()
        except Exception as e:
            return template("error_template", {"error_message": "Unable to invert the image. "+str(e), "plweb_folder": PLWEB_FOLDER})
    
    # Now analyze
    if CONFIG['PicketFence']['USE_ORIGINAL_PYLINAC'] == "True":
        if mlc not in ["Varian_120", "Varian_120HD"]:
            return template("error_template", {"error_message": "The current configuration (CONFIG.INI) "\
                                               "is set to original pylinac analysis. \n Hence only Varian_120 "\
                                               "and Varian_120HD can be chosen for mlc type.", "plweb_folder": PLWEB_FOLDER})
        hdmlc = True if mlc=="Varian_120HD" else False
        pf.analyze(tolerance=tolerance, action_tolerance=action_tol, hdmlc=hdmlc, sag_adjustment=float(sag), num_pickets=num_pickets,
                   orientation=orientation)
    else:
        pf.analyze(tolerance=tolerance, action_tolerance=action_tol, mlc_type=mlc, sag_adjustment=float(sag),num_pickets=num_pickets,
                   orientation=orientation)
    

    # Added an if clause to tell if num of mlc's are not the same on all pickets:

    num_mlcs = len(pf.pickets[0].mlc_meas)
    for p in pf.pickets:
        if len(p.mlc_meas) != num_mlcs:
            return template("error_template", {"error_message": "Not all pickets have the same number of leaves. "+
                                               "Probably your image si too skewed. Rotate your collimator a bit "+
                                               "and try again. Use the jaws perpendicular to MLCs to set the right "+
                                               "collimator angle.",
                                               "plweb_folder": PLWEB_FOLDER})
    error_array = np.array([])
    max_error = []
    max_error_leaf = []
    passed_tol = []
    picket_offsets = []
    picket_nr = pf.num_pickets
    for k in pf.pickets.pickets:
        error_array = np.concatenate((error_array, k.error_array))
        max_error.append(k.max_error)
        max_err_leaf_ind = np.argmax(k.error_array)

        max_error_leaf.append(max_err_leaf_ind)
        passed_tol.append("Passed" if k.passed else "Failed")
        picket_offsets.append(k.dist2cax)

    # Plot images
    if pf.settings.orientation == "Left-Right":
        fig_pf = Figure(figsize=(9, 10), tight_layout={"w_pad":0})
    else:
        fig_pf = Figure(figsize=(9.5, 7), tight_layout={"w_pad":0})

    img_ax = fig_pf.add_subplot(1,1,1)
    img_ax.imshow(pf.image.array, cmap=matplotlib.cm.gray, interpolation="none", aspect="equal", origin='upper')

    # Taken from pylinac: leaf_error_subplot:
    tol_line_height = [pf.settings.tolerance, pf.settings.tolerance]
    tol_line_width = [0, max(pf.image.shape)]
    # make the new axis
    divider = make_axes_locatable(img_ax)
    if pf.settings.orientation == 'Up-Down':
        axtop = divider.append_axes('right', 1.75, pad=0.2, sharey=img_ax)
    else:
        axtop = divider.append_axes('bottom', 1.75, pad=0.5, sharex=img_ax)

    # get leaf positions, errors, standard deviation, and leaf numbers
    pos, vals, err, leaf_nums = pf.pickets.error_hist()

    # Changed leaf_nums to sequential numbers:
    leaf_nums = list(np.arange(0, len(leaf_nums), 1))

    # plot the leaf errors as a bar plot
    if pf.settings.orientation == 'Up-Down':
        axtop.barh(pos, vals, xerr=err, height=pf.pickets[0].sample_width * 2, alpha=0.4, align='center')
        # plot the tolerance line(s)
        axtop.plot(tol_line_height, tol_line_width, 'r-', linewidth=3)
        if pf.settings.action_tolerance is not None:
            tol_line_height_action = [pf.settings.action_tolerance, pf.settings.action_tolerance]
            tol_line_width_action = [0, max(pf.image.shape)]
            axtop.plot(tol_line_height_action, tol_line_width_action, 'y-', linewidth=3)

        # reset xlims to comfortably include the max error or tolerance value
        axtop.set_xlim([0, max(max(vals), pf.settings.tolerance) + 0.1])
    else:
        axtop.bar(pos, vals, yerr=err, width=pf.pickets[0].sample_width * 2, alpha=0.4, align='center')
        axtop.plot(tol_line_width, tol_line_height, 'r-', linewidth=3)
        if pf.settings.action_tolerance is not None:
            tol_line_height_action = [pf.settings.action_tolerance, pf.settings.action_tolerance]
            tol_line_width_action = [0, max(pf.image.shape)]
            axtop.plot(tol_line_width_action, tol_line_height_action, 'y-', linewidth=3)
        axtop.set_ylim([0, max(max(vals), pf.settings.tolerance) + 0.1])

    # add formatting to axis
    axtop.grid(True)
    axtop.set_title("Average Error (mm)")

    # add tooltips if interactive
    # Copied this from previous version of pylinac
    interactive = True
    if interactive:
        if pf.settings.orientation == 'Up-Down':
            labels = [['Leaf pair: {0} <br> Avg Error: {1:3.3f} mm <br> Stdev: {2:3.3f} mm'.format(leaf_num, err, std)]
                      for leaf_num, err, std in zip(leaf_nums, vals, err)]
            voffset = 0
            hoffset = 20
        else:
            labels = [['Leaf pair: {0}, Avg Error: {1:3.3f} mm, Stdev: {2:3.3f} mm'.format(leaf_num, err, std)]
                      for leaf_num, err, std in zip(leaf_nums, vals, err)]

        if pf.settings.orientation == 'Up-Down':
            for num, patch in enumerate(axtop.axes.patches):
                ttip = mpld3.plugins.PointHTMLTooltip(patch, labels[num], voffset=voffset, hoffset=hoffset)
                mpld3.plugins.connect(fig_pf, ttip)
                mpld3.plugins.connect(fig_pf, mpld3.plugins.MousePosition(fontsize=14))
        else:
            for num, patch in enumerate(axtop.axes.patches):
                ttip = mpld3.plugins.PointLabelTooltip(patch, labels[num], location='top left')
                mpld3.plugins.connect(fig_pf, ttip)
                mpld3.plugins.connect(fig_pf, mpld3.plugins.MousePosition(fontsize=14))

    for p_num, picket in enumerate(pf.pickets):
        picket.add_guards_to_axes(img_ax.axes)
        for idx, mlc_meas in enumerate(picket.mlc_meas):
            mlc_meas.plot2axes(img_ax.axes, width=1.5)

    # plot CAX
    img_ax.plot(pf.image.center.x, pf.image.center.y, 'r+', ms=12, markeredgewidth=3)

    # tighten up the plot view
    img_ax.set_xlim([0, pf.image.shape[1]])
    img_ax.set_ylim([pf.image.shape[0], 0])
    img_ax.axis('off')
    img_ax.set_xticks([])
    img_ax.set_yticks([])
    
    # Histogram of all errors and average profile plot
    upper_bound = pf.settings.tolerance
    upper_outliers = np.sum(error_array.flatten()>=upper_bound)
    fig_pf2 = Figure(figsize=(10, 4), tight_layout={"w_pad":2})
    ax2 = fig_pf2.add_subplot(1,2,1)
    ax3 = fig_pf2.add_subplot(1,2,2)
    n, bins = np.histogram(error_array.flatten(), density=False, bins=10, range=(0, upper_bound))
    ax2.bar(bins[0:-1], n, width=np.diff(bins)[0], facecolor='green', alpha=0.75)
    ax2.bar([upper_bound,upper_bound*1.1], upper_outliers, width=0.1*upper_bound, facecolor='red', alpha=0.75)
    ax2.plot([pf.settings.action_tolerance,pf.settings.action_tolerance], [0,max(n)/2] , color="orange")
    ax2.annotate("Action Tol.", (pf.settings.action_tolerance, 1.05*max(n)/2), color='black',
                 fontsize=6, ha='center', va='bottom')
    ax2.plot([pf.settings.tolerance,pf.settings.tolerance], [0,max(n)/2] , color="darkred")
    ax2.annotate("Tol.", (pf.settings.tolerance, 1.05*max(n)/2), color='black',
                 fontsize=6, ha='center', va='bottom')

    # Plot mean inplane profile and calculate FWHM:
    mlc_mean_profile = pf.pickets.image_mlc_inplane_mean_profile
    ax3.plot(mlc_mean_profile.values, "b-")
    picket_fwhm = []
    fwhm_mean = 0
    try:
        peaks = mlc_mean_profile.find_peaks(max_number=picket_nr, min_distance=0.02, threshold=0.5)
        peaks = np.sort(peaks)
        ax3.plot(peaks, mlc_mean_profile[peaks], "ro")

        separation = int(np.mean(np.diff(peaks))/3)
        mmpd = 1/pf.image.dpmm
        # Get valleys
        valleys = []
        for p in np.arange(0, len(peaks)-1, 1):
            prof_partial = mlc_mean_profile[peaks[p]: peaks[p+1]]
            valleys.append(peaks[p]+np.argmin(prof_partial))
        edge_points = [peaks[0]-separation] + valleys + [peaks[-1]+separation]
        ax3.plot(edge_points, mlc_mean_profile[edge_points], "yo")

        for k in np.arange(0, len(edge_points)-1, 1):
            pr = PylinacSingleProfile(mlc_mean_profile[edge_points[k]:edge_points[k+1]])
            left = pr[0]
            right = pr[-1]
            amplitude = mlc_mean_profile[peaks[k]]
            if left < right:
                x = 100*((amplitude-left)*0.5 +left-right)/(amplitude-right)
                a = pr._penumbra_point(x=50, side="left", interpolate=True)
                b = pr._penumbra_point(x=x, side="right", interpolate=True)
            else:
                x = 100*((amplitude-right)*0.5 +right-left)/(amplitude-left)
                a = pr._penumbra_point(x=x, side="left", interpolate=True)
                b = pr._penumbra_point(x=50, side="right", interpolate=True)
            left_point = edge_points[k]+a
            right_point = edge_points[k]+b
            ax3.plot([left_point, right_point], [np.interp(left_point, np.arange(0, len(mlc_mean_profile.values), 1), mlc_mean_profile.values),
                     np.interp(right_point, np.arange(0, len(mlc_mean_profile.values), 1), mlc_mean_profile.values)], "-k", alpha=0.5)
            picket_fwhm.append(np.abs(a-b)*mmpd)
            
        fwhm_mean = np.mean(picket_fwhm)
    except:
        picket_fwhm = [np.nan]*picket_nr
        fwhm_mean = np.nan
    if len(picket_fwhm) != picket_nr:
        fwhm_mean = np.mean(picket_fwhm)
        picket_fwhm = [np.nan]*picket_nr

    ax2.set_xlim([-0.025, pf.settings.tolerance*1.15])
    ax3.set_xlim([0, pf.image.shape[1]])
    ax2.set_title("Leaf error")
    ax3.set_title("MLC mean profile")
    ax2.set_xlabel("Error [mm]")
    ax2.set_ylabel("Counts")
    ax3.set_xlabel("Pixel")
    ax3.set_ylabel("Grey value")

    passed = "Passed" if pf.passed else "Failed"

    script = mpld3.fig_to_html(fig_pf, d3_url=D3_URL, mpld3_url=MPLD3_URL)
    script2 = mpld3.fig_to_html(fig_pf2, d3_url=D3_URL, mpld3_url=MPLD3_URL)
    variables = {
                 "script": script,
                 "script2": script2,
                 "plweb_folder": PLWEB_FOLDER,
                 "passed": passed,
                 "max_error": max_error,
                 "max_error_leaf": max_error_leaf,
                 "passed_tol": passed_tol,
                 "picket_nr": picket_nr,
                 "tolerance": pf.settings.tolerance,
                 "perc_passing": pf.percent_passing,
                 "max_error_all": pf.max_error,
                 "max_error_picket_all": pf.max_error_picket,
                 "max_error_leaf_all": pf.max_error_leaf,
                 "median_error": pf.abs_median_error,
                 "spacing": pf.pickets.mean_spacing,
                 "picket_offsets": picket_offsets,
                 "fwhm_mean": fwhm_mean,
                 "picket_fwhm": picket_fwhm,
                 "pdf_report_enable": CONFIG['PicketFence']['GENERATE_PDF_REPORT']
                 }

    # Generate pylinac report:
    if CONFIG['PicketFence']['GENERATE_PDF_REPORT'] == "True":
        pdf_file = tempfile.NamedTemporaryFile(delete=False, prefix="PicketFence_", suffix=".pdf", dir=PDF_REPORT_FOLDER)
        metadata = RestToolbox.GetInstances(ORTHANC_URL, [w])
        try:
            patient = metadata[0]["PatientName"]
        except:
            patient = ""
        try:
            stationname = metadata[0]["StationName"]
        except:
            stationname = ""
        try:
            date_time = RestToolbox.get_datetime(metadata[0])
            date_var = datetime.datetime.strptime(date_time[0], "%Y%m%d").strftime("%d/%m/%Y")
        except:
            date_var = ""
        pf.publish_pdf(pdf_file, notes=["Date = "+date_var, "Patient = "+patient, "Station = "+stationname])

        variables["pdf_report_filename"] = os.path.basename(pdf_file.name)
    #gc.collect()

    delete_files_in_subfolders([temp_folder]) # Delete image
    return template("picket_fence_results", variables)

@app.route(PLWEB_FOLDER + '/picket_fence_calculate/<w>', method="POST")
def picket_fence_calculate(w):
    '''Function that analyzes the images and sends results'''
    # w is the image, m is the mlc type
    temp_folder, file_path = RestToolbox.GetSingleDcm(ORTHANC_URL, w)
    clip_box = float(request.forms.get('hidden_clipbox'))*10.0
    py_filter = int(request.forms.get('hidden_filter'))
    py_filter = None if py_filter==0 else py_filter
    num_pickets = int(request.forms.get('hidden_peaks'))
    num_pickets = None if num_pickets==0 else num_pickets
    sag = float(request.forms.get('hidden_sag'))
    mlc = request.forms.get('hidden_mlc')
    invert = True if request.forms.get('hidden_invert')=="true" else False
    orientation = request.forms.get('hidden_orientation')
    orientation = None if orientation=="Automatic" else orientation

    tolerance = float(CONFIG['PicketFence']['TOLERANCE'])
    action_tol = float(CONFIG['PicketFence']['ACTION_TOLERANCE'])
    
    args = {"temp_folder": temp_folder, "file_path": file_path, "clip_box": clip_box, "py_filter":py_filter,
            "num_pickets":num_pickets, "sag": sag, "mlc":mlc, "invert":invert, "orientation":orientation,
            "tolerance":tolerance, "action_tol":action_tol, "w":w}
    p = Pool(1)
    data = p.map(picket_fence_helperf, [args])
    p.close()
    p.join()
    return data

@app.route(PLWEB_FOLDER + '/planar_imaging', method="POST")
def planar_imaging_start():
    """Read from database and return list of patients"""
    try:
        variables = Read_from_dcm_database()
    except ConnectionError:
        return template("error_template", {"error_message": "Orthanc is refusing connection.",
                                           "plweb_folder": PLWEB_FOLDER})

    variables["QC3_machines"] = [k.strip() for k in CONFIG['PlanarImaging']['QC3_MACHINES'].split(",")]
    variables["LEEDSTOR_machines"] = [k.strip() for k in CONFIG['PlanarImaging']['LEEDSTOR_MACHINES'].split(",")]
    variables["LASVEGAS_machines"] = [k.strip() for k in CONFIG['PlanarImaging']['LASVEGAS_MACHINES'].split(",")]
    variables["PHANTOMS"] = ["QC3", "LeedsTOR", "Las Vegas"]
    return template("planar_imaging", variables)

def planar_imaging_helperf(args):
    '''This function is used in order to prevent memory problems'''
    clip_box = args["clip_box"]
    phantom = args["phantom"]
    machine = args["machine"]
    leedsrot = args["leedsrot"]
    pyl = args["pyl"]
    inv = args["inv"]
    bbox = args["bbox"]
    w1 = args["w1"]
    use_reference = args["use_reference"]

    lowtresh = float(CONFIG['PlanarImaging']['LOW_THRESHOLD'])
    hightresh = float(CONFIG['PlanarImaging']['HIGH_THRESHOLD'])

    try:
        temp_folder1, file_path1 = RestToolbox.GetSingleDcm(ORTHANC_URL, w1)
    except:
        return template("error_template", {"error_message": "Cannot read image.",
                                           "plweb_folder": PLWEB_FOLDER})

    # Check if reference images are present for this phantom and machine:
    if phantom == "QC3":
        phantom_folder = "QC3"
    elif phantom == "LeedsTOR":
        phantom_folder = "LeedsTOR"
    elif phantom == "Las Vegas":
        phantom_folder = "LasVegas"
    else:
        raise ValueError("Uknown phantom")

    ref_path1 = os.path.join(PLANARIMAGING_REF, phantom_folder, machine, "First.dcm")

    if os.path.exists(ref_path1):
        ref1_exists = True
    else:
        ref1_exists = False
    if not use_reference:
        ref1_exists = False

    if phantom == "QC3":
        # First analyze first image
        try:
            pi1 = planar_imaging.StandardImagingQC3(file_path1)
            if clip_box != 0:
                try:
                    pi1.image.check_inversion_by_histogram()
                    clip_around_image(pi1.image, clip_box)
                except Exception as e:
                    return template("error_template", {"error_message": "Unable to apply clipbox. "+str(e), "plweb_folder": PLWEB_FOLDER})
            pi1.analyze(low_contrast_threshold=lowtresh, hi_contrast_threshold=hightresh, invert=inv)
        except:
             return template("error_template", {"error_message": "Cannot analyze image 1.",
                                               "plweb_folder": PLWEB_FOLDER})

        # Analyze reference images if they exists
        if ref1_exists:
            try:
                ref1 = planar_imaging.StandardImagingQC3(ref_path1)
                if clip_box != 0:
                    try:
                        ref1.image.check_inversion_by_histogram()
                        clip_around_image(ref1.image, clip_box)
                    except Exception as e:
                        return template("error_template", {"error_message": "Unable to apply clipbox. "+str(e), "plweb_folder": PLWEB_FOLDER})
                ref1.analyze(low_contrast_threshold=lowtresh, hi_contrast_threshold=hightresh, invert=inv)
            except:
                 return template("error_template", {"error_message": "Cannot analyze reference image 1."\
                                                    " You can delete the image if you want to continue.",
                                                   "plweb_folder": PLWEB_FOLDER})

        fig = Figure(figsize=(9.5, 5), tight_layout={"w_pad":3, "pad": 4})
        ax_ref = fig.add_subplot(1,2,1)
        ax_pi = fig.add_subplot(1,2,2)

        # Plot reference image and regions
        if ref1_exists:
            ax_ref.imshow(ref1.image.array, cmap=matplotlib.cm.gray, interpolation="none", aspect="equal", origin='upper')
            ax_ref.set_title('QC-3 Reference Image')
            ax_ref.axis('off')
            # plot the low contrast ROIs
            ref1.lc_ref_rois.plot2axes(ax_ref, edgecolor='yellow')
            ax_ref.text(ref1.lc_ref_rois.center.x, ref1.lc_ref_rois.center.y ,"B", horizontalalignment='center', verticalalignment='center')
            for ind, roi in enumerate(ref1.lc_rois):
                roi.plot2axes(ax_ref, edgecolor=roi.plot_color_constant if pyl else "r")
                ax_ref.text(roi.center.x, roi.center.y, str(ind), horizontalalignment='center', verticalalignment='center')
            # plot the high-contrast ROIs
            for ind, roi in enumerate(ref1.hc_rois):
                roi.plot2axes(ax_ref, edgecolor='b')
                ax_ref.text(roi.center.x, roi.center.y ,str(ind), horizontalalignment='center', verticalalignment='center')
        else:
           ax_ref.text(0.5, 0.5 ,"Reference image not available", horizontalalignment='center', verticalalignment='center')

        # Plot current image and regions
        ax_pi.imshow(pi1.image.array, cmap=matplotlib.cm.gray, interpolation="none", aspect="equal", origin='upper')
        ax_pi.axis('off')
        ax_pi.set_title('QC-3 Current Image')
        # plot the low contrast ROIs
        pi1.lc_ref_rois.plot2axes(ax_pi, edgecolor='yellow')
        ax_pi.text(pi1.lc_ref_rois.center.x, pi1.lc_ref_rois.center.y ,"B", horizontalalignment='center', verticalalignment='center')
        for ind, roi in enumerate(pi1.lc_rois):
            roi.plot2axes(ax_pi, edgecolor=roi.plot_color_constant if pyl else "r")
            ax_pi.text(roi.center.x, roi.center.y ,str(ind), horizontalalignment='center', verticalalignment='center')
        # plot the high-contrast ROIs
        for ind, roi in enumerate(pi1.hc_rois):
            roi.plot2axes(ax_pi, edgecolor='b')
            ax_pi.text(roi.center.x, roi.center.y ,str(ind), horizontalalignment='center', verticalalignment='center')

        # Zoom on phantom if requested:
        if bbox:
            pad = 15  # Additional space between cyan bbox and plot
            if ref1_exists:
                bounding_box_ref = ref1.phantom_ski_region.bbox
                bbox_center_ref = ref1.phantom_center

                if abs(bounding_box_ref[1] - bounding_box_ref[3]) >= abs(bounding_box_ref[2] - bounding_box_ref[0]):
                    dist = abs(bounding_box_ref[1] - bounding_box_ref[3])/2
                    ax_ref.set_ylim(bbox_center_ref.y + dist + pad, bbox_center_ref.y - dist - pad)
                    ax_ref.set_xlim(bbox_center_ref.x - dist - pad, bbox_center_ref.x + dist + pad)
                else:
                    dist = abs(bounding_box_ref[2] - bounding_box_ref[0])/2
                    ax_ref.set_ylim(bbox_center_ref.y + dist + pad, bbox_center_ref.y - dist - pad)
                    ax_ref.set_xlim(bbox_center_ref.x - dist - pad, bbox_center_ref.x + dist + pad)

                ax_ref.plot([bounding_box_ref[1], bounding_box_ref[1], bounding_box_ref[3], bounding_box_ref[3], bounding_box_ref[1]],
                            [bounding_box_ref[2], bounding_box_ref[0], bounding_box_ref[0], bounding_box_ref[2], bounding_box_ref[2]], c="cyan")
                ax_ref.autoscale(False)

            bounding_box_pi = pi1.phantom_ski_region.bbox
            bbox_center_pi = pi1.phantom_center
            if abs(bounding_box_pi[1] - bounding_box_pi[3]) >= abs(bounding_box_pi[2] - bounding_box_pi[0]):
                dist = abs(bounding_box_pi[1] - bounding_box_pi[3])/2
                ax_pi.set_ylim(bbox_center_pi.y + dist + pad, bbox_center_pi.y - dist - pad)
                ax_pi.set_xlim(bbox_center_pi.x - dist - pad, bbox_center_pi.x + dist + pad)
            else:
                dist = abs(bounding_box_pi[2] - bounding_box_pi[0])/2
                ax_pi.set_ylim(bbox_center_pi.y + dist + pad, bbox_center_pi.y - dist - pad)
                ax_pi.set_xlim(bbox_center_pi.x - dist - pad, bbox_center_pi.x + dist + pad)

            ax_pi.plot([bounding_box_pi[1], bounding_box_pi[1], bounding_box_pi[3], bounding_box_pi[3], bounding_box_pi[1]],
                        [bounding_box_pi[2], bounding_box_pi[0], bounding_box_pi[0], bounding_box_pi[2], bounding_box_pi[2]], c="cyan")
            ax_pi.autoscale(False)

        if pyl:
            # Plot low frequency contrast, CNR and rMTF
            fig2 = Figure(figsize=(9, 8), tight_layout={"w_pad":1})
            ax_lfc = fig2.add_subplot(2,2,1)
            ax_lfcnr = fig2.add_subplot(2,2,2)
            ax_rmtf = fig2.add_subplot(2,2,3)

            # lfc
            ax_lfc.plot([abs(roi.contrast_constant) for roi in pi1.lc_rois], marker='o', markersize=8, color='r')
            if ref1_exists:
                ax_lfc.plot([abs(roi.contrast_constant) for roi in ref1.lc_rois], marker='o', color='r', markersize=8,
                             markerfacecolor="None", linestyle="--")
            ax_lfc.plot([], [], color='r', linestyle="--", label='Reference')
            ax_lfc.plot([], [], color='r', label='Current')
            ax_lfc.plot([0, 4], [lowtresh, lowtresh], "-g")
            ax_lfc.grid(True)
            ax_lfc.set_title('Low-frequency Contrast')
            ax_lfc.set_xlabel('ROI #')
            ax_lfc.set_ylabel('Contrast constant')
            ax_lfc.set_xticks([0, 1, 2, 3, 4])
            ax_lfc.legend(loc='upper right', ncol=2, columnspacing=0, fontsize=12, handletextpad=0)
            ax_lfc.margins(0.05)

            # CNR
            ax_lfcnr.plot([abs(roi.contrast_to_noise) for roi in pi1.lc_rois], marker='^', markersize=8, color='r')
            if ref1_exists:
                ax_lfcnr.plot([abs(roi.contrast_to_noise) for roi in ref1.lc_rois], marker='^', color='r', markersize=8, markerfacecolor="None", linestyle="--")
            ax_lfcnr.plot([], [], color='r', linestyle="--", label='Reference')
            ax_lfcnr.plot([], [], color='r', label='Current')
            ax_lfcnr.grid(True)
            ax_lfcnr.set_title('Contrast-Noise Ratio')
            ax_lfcnr.set_xlabel('ROI #')
            ax_lfcnr.set_ylabel('CNR')
            ax_lfcnr.set_xticks([0, 1, 2, 3, 4])
            ax_lfcnr.legend(loc='upper right', ncol=2, columnspacing=0, fontsize=12, handletextpad=0)
            ax_lfcnr.margins(0.05)

            # rMTF
            mtfs_pi1 = [roi.mtf for roi in pi1.hc_rois]
            mtfs_pi1_norm = max(mtfs_pi1)
            mtfs_pi1 = [a/mtfs_pi1_norm for a in mtfs_pi1]
            if ref1_exists:
                mtfs_ref1 = [roi.mtf for roi in ref1.hc_rois]
                mtfs_ref1_norm = max(mtfs_ref1)
                mtfs_ref1 = [a/mtfs_ref1_norm for a in mtfs_ref1]
            else:
                mtfs_ref1 = [np.nan]*len(mtfs_pi1)

            lppmm = np.arange(0, len(mtfs_pi1), 1)

            ax_rmtf.plot(lppmm, mtfs_pi1, marker='D', markersize=8, color='b')
            ax_rmtf.plot([0, 4], [hightresh, hightresh], "-g")
            if ref1_exists:
                ax_rmtf.plot(lppmm, mtfs_ref1, marker='D', color='b', markersize=8, markerfacecolor="None", linestyle="--")

            ax_rmtf.plot([], [], color='b', linestyle="--", label='Reference')
            ax_rmtf.plot([], [], color='b', label='Current')
            ax_rmtf.grid(True)
            ax_rmtf.set_title('High-frequency rMTF')
            ax_rmtf.set_xlabel('Line pair region #')
            ax_rmtf.set_ylabel('relative MTF')
            ax_rmtf.set_xticks(np.arange(0, len(mtfs_pi1), 1))
            ax_rmtf.legend(loc='upper right', ncol=2, columnspacing=0, fontsize=12, handletextpad=0)
            ax_rmtf.margins(0.05)

            f30 = [np.interp(0.3, mtfs_ref1[::-1], lppmm[::-1]), np.interp(0.3, mtfs_pi1[::-1], lppmm[::-1])]
            f40 = [np.interp(0.4, mtfs_ref1[::-1], lppmm[::-1]), np.interp(0.4, mtfs_pi1[::-1], lppmm[::-1])]
            f50 = [np.interp(0.5, mtfs_ref1[::-1], lppmm[::-1]), np.interp(0.5, mtfs_pi1[::-1], lppmm[::-1])]
            f80 = [np.interp(0.8, mtfs_ref1[::-1], lppmm[::-1]), np.interp(0.8, mtfs_pi1[::-1], lppmm[::-1])]
            if ref1_exists:
                median_contrast = [np.median([roi.contrast for roi in ref1.lc_rois]), np.median([roi.contrast for roi in pi1.lc_rois])]
                median_CNR = [np.median([roi.contrast_to_noise for roi in ref1.lc_rois]), np.median([roi.contrast_to_noise for roi in pi1.lc_rois])]
            else:
                median_contrast = [np.nan, np.median([roi.contrast for roi in pi1.lc_rois])]
                median_CNR = [np.nan, np.median([roi.contrast_to_noise for roi in pi1.lc_rois])]
            

            script = mpld3.fig_to_html(fig, d3_url=D3_URL, mpld3_url=MPLD3_URL)
            script2 = mpld3.fig_to_html(fig2, d3_url=D3_URL, mpld3_url=MPLD3_URL)

            variables = {"script": script,
                 "script2": script2,
                 "plweb_folder": PLWEB_FOLDER,
                 "f30": f30,
                 "f40": f40,
                 "f50": f50,
                 "f80": f80,
                 "pyl": pyl,
                 "median_contrast": median_contrast,
                 "median_CNR": median_CNR,
                 "pdf_report_enable": CONFIG['PlanarImaging']['GENERATE_PDF_REPORT'],
                 "lppmm": lppmm,
                 "display_lppmm": "0"
                 }
            
            if CONFIG['PlanarImaging']['GENERATE_PDF_REPORT'] == "True":
                pdf_file = tempfile.NamedTemporaryFile(delete=False, prefix="PlanarImaging_", suffix=".pdf", dir=PDF_REPORT_FOLDER)
                metadata = RestToolbox.GetInstances(ORTHANC_URL, [w1])
                try:
                    patient = metadata[0]["PatientName"]
                except:
                    patient = ""
                try:
                    stationname = metadata[0]["StationName"]
                except:
                    stationname = ""
                try:
                    date_time = RestToolbox.get_datetime(metadata[0])
                    date_var = datetime.datetime.strptime(date_time[0], "%Y%m%d").strftime("%d/%m/%Y")
                except:
                    date_var = ""
                pi1.publish_pdf(pdf_file, notes=["Date = "+date_var, "Patient = "+patient, "Station = "+stationname])
        
                variables["pdf_report_filename"] = os.path.basename(pdf_file.name)
        else:
            # Plot low frequency contrast, CNR and rMTF
            fig2 = Figure(figsize=(9, 8), tight_layout={"w_pad":1})
            ax_lfc = fig2.add_subplot(2,2,1)
            ax_lfcnr = fig2.add_subplot(2,2,2)
            ax_rmtf = fig2.add_subplot(2,2,3)

            # lfc
            ax_lfc.plot([abs(100*(roi.pixel_value - pi1.lc_ref_rois.pixel_value))/pi1.lc_ref_rois.pixel_value for roi in pi1.lc_rois], marker='o', markersize=8, color='r')
            if ref1_exists:
                ax_lfc.plot([abs(100*(roi.pixel_value - ref1.lc_ref_rois.pixel_value))/ref1.lc_ref_rois.pixel_value for roi in ref1.lc_rois], marker='o', color='r', markersize=8, markerfacecolor="None", linestyle="--")

            ax_lfc.plot([], [], color='r', linestyle="--", label='Reference')
            ax_lfc.plot([], [], color='r', label='Current')
            ax_lfc.grid(True)
            ax_lfc.set_title('Low-frequency Contrast')
            ax_lfc.set_xlabel('ROI #')
            ax_lfc.set_ylabel('Contrast [%]')
            ax_lfc.set_xticks([0, 1, 2, 3, 4])
            ax_lfc.legend(loc='upper right', ncol=2, columnspacing=0, fontsize=12, handletextpad=0)
            ax_lfc.margins(0.05)

            pi_noise = np.average([pi1.lc_ref_rois.std]+[roi.std for roi in pi1.lc_rois])

            ax_lfcnr.plot([abs(roi.pixel_value - pi1.lc_ref_rois.pixel_value)/pi_noise for roi in pi1.lc_rois], marker='^', markersize=8, color='r')

            if ref1_exists:
                ref_noise = np.average([ref1.lc_ref_rois.std]+[roi.std for roi in ref1.lc_rois])
                ax_lfcnr.plot([abs(roi.pixel_value - ref1.lc_ref_rois.pixel_value)/ref_noise for roi in ref1.lc_rois], marker='^', color='r', markersize=8, markerfacecolor="None", linestyle="--")
                CNR = [abs(ref1.lc_rois[0].pixel_value - ref1.lc_ref_rois.pixel_value)/ref_noise,
                       abs(pi1.lc_rois[0].pixel_value - pi1.lc_ref_rois.pixel_value)/pi_noise]
                noise = [ref_noise, pi_noise]
            else:
                CNR = [np.nan, abs(pi1.lc_rois[0].pixel_value - pi1.lc_ref_rois.pixel_value)/pi_noise]
                noise = [np.nan, pi_noise]

            ax_lfcnr.plot([], [], color='r', linestyle="--", label='Reference')
            ax_lfcnr.plot([], [], color='r', label='Current')
            ax_lfcnr.grid(True)
            ax_lfcnr.set_title('Contrast-Noise Ratio')
            ax_lfcnr.set_xlabel('ROI #')
            ax_lfcnr.set_ylabel('CNR')
            ax_lfcnr.set_xticks([0, 1, 2, 3, 4])
            ax_lfcnr.legend(loc='upper right', ncol=2, columnspacing=0, fontsize=12, handletextpad=0)
            ax_lfcnr.margins(0.05)

            # rMTF
            pi_noise2 = pi1.lc_rois[0].std
            mtfs_pi1 = [np.sqrt((roi.std)**2 - pi_noise2**2) for roi in pi1.hc_rois]
            mtfs_pi1_norm = max(mtfs_pi1)
            mtfs_pi1 = [a/mtfs_pi1_norm for a in mtfs_pi1]
            if ref1_exists:
                ref_noise2 = ref1.lc_rois[0].std
                mtfs_ref1 = [np.sqrt((roi.std)**2 - ref_noise2**2) for roi in ref1.hc_rois]
                mtfs_ref1_norm = max(mtfs_ref1)
                mtfs_ref1 = [a/mtfs_ref1_norm for a in mtfs_ref1]
            else:
                mtfs_ref1 = [np.nan]*len(mtfs_pi1)

            if len(CONFIG['PlanarImaging']['LPPMM_QC3'].split(","))==5:
                lppmm = [float(k.strip()) for k in CONFIG['PlanarImaging']['LPPMM_QC3'].split(",")]
            else:
                return template("error_template", {"error_message": "Check the configuration file. There should be five LPPMM.",
                                "plweb_folder": PLWEB_FOLDER})

            ax_rmtf.plot(lppmm, mtfs_pi1, marker='D', markersize=8, color='b')
            if ref1_exists:
                ax_rmtf.plot(lppmm, mtfs_ref1, marker='D', color='b', markersize=8, markerfacecolor="None", linestyle="--")
            ax_rmtf.plot([], [], color='b', linestyle="--", label='Reference')
            ax_rmtf.plot([], [], color='b', label='Current')
            ax_rmtf.grid(True)
            ax_rmtf.set_title('High-frequency rMTF')
            ax_rmtf.set_xlabel('Line pairs per mm')
            ax_rmtf.set_ylabel('relative MTF')
            ax_rmtf.legend(loc='upper right', ncol=2, columnspacing=0, fontsize=12, handletextpad=0)
            ax_rmtf.margins(0.05)
            f30 = [np.interp(0.3, mtfs_ref1[::-1], lppmm[::-1]), np.interp(0.3, mtfs_pi1[::-1], lppmm[::-1])]
            f40 = [np.interp(0.4, mtfs_ref1[::-1], lppmm[::-1]), np.interp(0.4, mtfs_pi1[::-1], lppmm[::-1])]
            f50 = [np.interp(0.5, mtfs_ref1[::-1], lppmm[::-1]), np.interp(0.5, mtfs_pi1[::-1], lppmm[::-1])]
            f80 = [np.interp(0.8, mtfs_ref1[::-1], lppmm[::-1]), np.interp(0.8, mtfs_pi1[::-1], lppmm[::-1])]

            script = mpld3.fig_to_html(fig, d3_url=D3_URL, mpld3_url=MPLD3_URL)
            script2 = mpld3.fig_to_html(fig2, d3_url=D3_URL, mpld3_url=MPLD3_URL)

            variables = {"script": script,
                 "script2": script2,
                 "plweb_folder": PLWEB_FOLDER,
                 "f30": f30,
                 "f40": f40,
                 "f50": f50,
                 "f80": f80,
                 "pyl": pyl,
                 "CNR": CNR,
                 "noise": noise,
                 "pdf_report_enable": "0",
                 "lppmm": lppmm,
                 "display_lppmm": "1"
                 }
    
    elif phantom == "LeedsTOR":
        # First analyze first image
        try:
            pi1 = planar_imaging.LeedsTOR(file_path1)
            if clip_box != 0:
                try:
                    pi1.image.check_inversion()
                    clip_around_image(pi1.image, clip_box)
                except Exception as e:
                    return template("error_template", {"error_message": "Unable to apply clipbox. "+str(e), "plweb_folder": PLWEB_FOLDER})
            pi1.analyze(low_contrast_threshold=lowtresh, hi_contrast_threshold=hightresh, invert=inv, angle_offset=leedsrot)
        except:
             return template("error_template", {"error_message": "Cannot analyze image 1.",
                                               "plweb_folder": PLWEB_FOLDER})

        # Analyze reference images if they exists
        if ref1_exists:
            try:
                ref1 = planar_imaging.LeedsTOR(ref_path1)
                if clip_box != 0:
                    try:
                        ref1.image.check_inversion()
                        clip_around_image(ref1.image, clip_box)
                    except Exception as e:
                        return template("error_template", {"error_message": "Unable to apply clipbox. "+str(e), "plweb_folder": PLWEB_FOLDER})
                ref1.analyze(low_contrast_threshold=lowtresh, hi_contrast_threshold=hightresh, invert=inv, angle_offset=leedsrot)
            except:
                 return template("error_template", {"error_message": "Cannot analyze reference image 1."\
                                                    " You can delete the image if you want to continue.",
                                                   "plweb_folder": PLWEB_FOLDER})

        fig = Figure(figsize=(9.5, 5), tight_layout={"w_pad":3, "pad": 4})
        ax_ref = fig.add_subplot(1,2,1)
        ax_pi = fig.add_subplot(1,2,2)

        # Plot reference image and regions
        if ref1_exists:
            ax_ref.imshow(ref1.image.array, cmap=matplotlib.cm.gray, interpolation="none", aspect="equal", origin='upper')
            ax_ref.set_title('LeedsTOR Reference Image')
            ax_ref.axis('off')
            # plot the low contrast ROIs
            for roi in ref1.lc_ref_rois:
                roi.plot2axes(ax_ref, edgecolor='yellow')
            for ind, roi in enumerate(ref1.lc_rois):
                roi.plot2axes(ax_ref, edgecolor=roi.plot_color_constant if pyl else "r")
                ax_ref.text(roi.center.x, roi.center.y ,str(ind), horizontalalignment='center', verticalalignment='center')
            # plot the high-contrast ROIs
            for ind, roi in enumerate(ref1.hc_rois):
                roi.plot2axes(ax_ref, edgecolor=roi.plot_color if pyl else 'b')
                ax_ref.text(roi.center.x, roi.center.y, str(ind), horizontalalignment='center', verticalalignment='center')
            for roi in ref1.hc_ref_rois:
                roi.plot2axes(ax_ref, edgecolor="yellow")
        else:
           ax_ref.text(0.5, 0.5 ,"Reference image not available", horizontalalignment='center', verticalalignment='center')

        # Plot current image and regions
        ax_pi.imshow(pi1.image.array, cmap=matplotlib.cm.gray, interpolation="none", aspect="equal", origin='upper')
        ax_pi.axis('off')
        ax_pi.set_title('LeedsTOR Current Image')
        # plot the low contrast ROIs
        for roi in pi1.lc_ref_rois:
            roi.plot2axes(ax_pi, edgecolor="yellow")
        for ind, roi in enumerate(pi1.lc_rois):
            roi.plot2axes(ax_pi, edgecolor=roi.plot_color_constant if pyl else "r")
            ax_pi.text(roi.center.x, roi.center.y ,str(ind), horizontalalignment='center', verticalalignment='center')
        # plot the high-contrast ROIs
        for ind, roi in enumerate(pi1.hc_rois):
            roi.plot2axes(ax_pi, edgecolor=roi.plot_color if pyl else 'b')
            ax_pi.text(roi.center.x, roi.center.y, str(ind), horizontalalignment='center', verticalalignment='center')
        for roi in pi1.hc_ref_rois:
            roi.plot2axes(ax_pi, edgecolor='yellow')

        # Zoom on phantom if requested:
        if bbox:
            pad = 15  # Additional space between cyan bbox and plot
            if ref1_exists:
                big_circle_idx = np.argsort([ref1._regions[roi].major_axis_length for roi in ref1._blobs])[-1]
                circle_roi = ref1._regions[ref1._blobs[big_circle_idx]]
                bounding_box_ref = circle_roi.bbox
                bbox_center_ref = bbox_center(circle_roi)
                max_xy = max([abs(bounding_box_ref[1]-bounding_box_ref[3])/2, abs(bounding_box_ref[0]-bounding_box_ref[2])/2])
                ax_ref.set_ylim(bbox_center_ref.y + max_xy + pad, bbox_center_ref.y - max_xy - pad)
                ax_ref.set_xlim(bbox_center_ref.x - max_xy - pad, bbox_center_ref.x + max_xy + pad)
                ax_ref.plot([bounding_box_ref[1], bounding_box_ref[1], bounding_box_ref[3], bounding_box_ref[3], bounding_box_ref[1]],
                            [bounding_box_ref[2], bounding_box_ref[0], bounding_box_ref[0], bounding_box_ref[2], bounding_box_ref[2]], c="cyan")
                ax_ref.autoscale(False)

            big_circle_idx = np.argsort([pi1._regions[roi].major_axis_length for roi in pi1._blobs])[-1]
            circle_roi = pi1._regions[pi1._blobs[big_circle_idx]]
            bounding_box_pi = circle_roi.bbox
            bbox_center_pi = bbox_center(circle_roi)

            max_xy = max([abs(bounding_box_pi[1]-bounding_box_pi[3])/2, abs(bounding_box_pi[0]-bounding_box_pi[2])/2])

            ax_pi.set_ylim(bbox_center_pi.y + max_xy + pad, bbox_center_pi.y - max_xy - pad)
            ax_pi.set_xlim(bbox_center_pi.x - max_xy - pad, bbox_center_pi.x + max_xy + pad)
            ax_pi.plot([bounding_box_pi[1], bounding_box_pi[1], bounding_box_pi[3], bounding_box_pi[3], bounding_box_pi[1]],
                        [bounding_box_pi[2], bounding_box_pi[0], bounding_box_pi[0], bounding_box_pi[2], bounding_box_pi[2]], c="cyan")
            ax_pi.autoscale(False)

        if pyl:
            # Plot low frequency contrast, CNR and rMTF
            fig2 = Figure(figsize=(9, 8), tight_layout={"w_pad":1})
            ax_lfc = fig2.add_subplot(2,2,1)
            ax_lfcnr = fig2.add_subplot(2,2,2)
            ax_rmtf = fig2.add_subplot(2,2,3)
            # lfc
            ax_lfc.plot([abs(roi.contrast_constant) for roi in pi1.lc_rois], marker='o', markersize=8, color='r')
            if ref1_exists:
                ax_lfc.plot([abs(roi.contrast_constant) for roi in ref1.lc_rois], marker='o', color='r', markersize=8,
                             markerfacecolor="None", linestyle="--")
            
            ax_lfc.plot([], [], color='r', linestyle="--", label='Reference')
            ax_lfc.plot([], [], color='r', label='Current')
            ax_lfc.plot([0, len(pi1.lc_rois)], [lowtresh, lowtresh], "-g")
            ax_lfc.grid(True)
            ax_lfc.set_title('Low-frequency Contrast')
            ax_lfc.set_xlabel('ROI #')
            ax_lfc.set_ylabel('Contrast constant')
            ax_lfc.set_xticks(np.arange(0, len(pi1.lc_rois), 1))
            ax_lfc.legend(loc='upper right', ncol=2, columnspacing=0, fontsize=12, handletextpad=0)
            ax_lfc.margins(0.05)

            # CNR
            ax_lfcnr.plot([abs(roi.contrast_to_noise) for roi in pi1.lc_rois], marker='^', markersize=8, color='r')
            if ref1_exists:
                ax_lfcnr.plot([abs(roi.contrast_to_noise) for roi in ref1.lc_rois], marker='^', color='r', markersize=8,
                               markerfacecolor="None", linestyle="--")
            ax_lfcnr.plot([], [], color='r', linestyle="--", label='Reference')
            ax_lfcnr.plot([], [], color='r', label='Current')
            ax_lfcnr.grid(True)
            ax_lfcnr.set_title('Contrast-Noise Ratio')
            ax_lfcnr.set_xlabel('ROI #')
            ax_lfcnr.set_ylabel('CNR')
            ax_lfcnr.set_xticks(np.arange(0, len(pi1.lc_rois), 1))
            ax_lfcnr.legend(loc='upper right', ncol=2, columnspacing=0, fontsize=12, handletextpad=0)
            ax_lfcnr.margins(0.05)

            # rMTF
            mtfs_pi1 = [roi.mtf for roi in pi1.hc_rois]
            mtfs_pi1.insert(0, 1)  # This was added to be the same as pylinac
            if ref1_exists:
                mtfs_ref1 = [roi.mtf for roi in ref1.hc_rois]
                mtfs_ref1.insert(0, 1)  # This was added to be the same as pylinac
            else:
                mtfs_ref1 = [np.nan]*len(mtfs_pi1)

            lppmm = np.arange(0, len(mtfs_pi1), 1)

            ax_rmtf.plot(lppmm, mtfs_pi1, marker='D', markersize=8, color='b')
            if ref1_exists:
                ax_rmtf.plot(lppmm, mtfs_ref1, marker='D', color='b', markersize=8, markerfacecolor="None", linestyle="--")

            ax_rmtf.plot([], [], color='b', linestyle="--", label='Reference')
            ax_rmtf.plot([], [], color='b', label='Current')
            ax_rmtf.plot([0, len(mtfs_pi1)], [hightresh, hightresh], "-g")
            ax_rmtf.grid(True)
            ax_rmtf.set_title('High-frequency rMTF')
            ax_rmtf.set_xlabel('Line pair region #')
            ax_rmtf.set_ylabel('relative MTF')
            ax_rmtf.set_xticks(np.arange(0, len(mtfs_pi1), 1))
            ax_rmtf.legend(loc='upper right', ncol=2, columnspacing=0, fontsize=12, handletextpad=0)
            ax_rmtf.margins(0.05)
            f30 = [np.interp(0.3, mtfs_ref1[::-1], lppmm[::-1]), np.interp(0.3, mtfs_pi1[::-1], lppmm[::-1])]
            f40 = [np.interp(0.4, mtfs_ref1[::-1], lppmm[::-1]), np.interp(0.4, mtfs_pi1[::-1], lppmm[::-1])]
            f50 = [np.interp(0.5, mtfs_ref1[::-1], lppmm[::-1]), np.interp(0.5, mtfs_pi1[::-1], lppmm[::-1])]
            f80 = [np.interp(0.8, mtfs_ref1[::-1], lppmm[::-1]), np.interp(0.8, mtfs_pi1[::-1], lppmm[::-1])]

            if ref1_exists:
                median_contrast = [np.median([roi.contrast for roi in ref1.lc_rois]), np.median([roi.contrast for roi in pi1.lc_rois])]
                median_CNR = [np.median([roi.contrast_to_noise for roi in ref1.lc_rois]), np.median([roi.contrast_to_noise for roi in pi1.lc_rois])]
            else:
                median_contrast = [np.nan, np.median([roi.contrast for roi in pi1.lc_rois])]
                median_CNR = [np.nan, np.median([roi.contrast_to_noise for roi in pi1.lc_rois])]

            script = mpld3.fig_to_html(fig, d3_url=D3_URL, mpld3_url=MPLD3_URL)
            script2 = mpld3.fig_to_html(fig2, d3_url=D3_URL, mpld3_url=MPLD3_URL)

            variables = {"script": script,
                 "script2": script2,
                 "plweb_folder": PLWEB_FOLDER,
                 "f30": f30,
                 "f40": f40,
                 "f50": f50,
                 "f80": f80,
                 "pyl": pyl,
                 "median_contrast": median_contrast,
                 "median_CNR": median_CNR,
                 "pdf_report_enable": CONFIG['PlanarImaging']['GENERATE_PDF_REPORT'],
                 "lppmm": lppmm,
                 "display_lppmm": "0"
                 }

            if CONFIG['PlanarImaging']['GENERATE_PDF_REPORT'] == "True":
                pdf_file = tempfile.NamedTemporaryFile(delete=False, prefix="PlanarImaging_", suffix=".pdf", dir=PDF_REPORT_FOLDER)
                metadata = RestToolbox.GetInstances(ORTHANC_URL, [w1])
                try:
                    patient = metadata[0]["PatientName"]
                except:
                    patient = ""
                try:
                    stationname = metadata[0]["StationName"]
                except:
                    stationname = ""
                try:
                    date_time = RestToolbox.get_datetime(metadata[0])
                    date_var = datetime.datetime.strptime(date_time[0], "%Y%m%d").strftime("%d/%m/%Y")
                except:
                    date_var = ""
                pi1.publish_pdf(pdf_file, notes=["Date = "+date_var, "Patient = "+patient, "Station = "+stationname])
        
                variables["pdf_report_filename"] = os.path.basename(pdf_file.name)
        else:
            # Plot low frequency contrast, CNR and rMTF
            fig2 = Figure(figsize=(9, 8), tight_layout={"w_pad":1})
            ax_lfc = fig2.add_subplot(2,2,1)
            ax_lfcnr = fig2.add_subplot(2,2,2)
            ax_rmtf = fig2.add_subplot(2,2,3)

            # lfc
            ax_lfc.plot([abs(100*(roi.pixel_value - roi.background))/roi.background for roi in pi1.lc_rois], marker='o', markersize=8, color='r')
            if ref1_exists:
                ax_lfc.plot([abs(100*(roi.pixel_value - roi.background))/roi.background for roi in ref1.lc_rois], marker='o', color='r', markersize=8, markerfacecolor="None", linestyle="--")

            ax_lfc.plot([], [], color='r', linestyle="--", label='Reference')
            ax_lfc.plot([], [], color='r', label='Current')
            ax_lfc.grid(True)
            ax_lfc.set_title('Low-frequency Contrast')
            ax_lfc.set_xlabel('ROI #')
            ax_lfc.set_ylabel('Contrast [%]')
            ax_lfc.set_xticks(np.arange(0, len(pi1.lc_rois), 1))
            ax_lfc.legend(loc='upper right', ncol=2, columnspacing=0, fontsize=12, handletextpad=0)
            ax_lfc.margins(0.05)

            # CNR
            pi_noise = np.average([roi.std for roi in pi1.lc_ref_rois])

            ax_lfcnr.plot([abs(roi.pixel_value - roi.background)/pi_noise for roi in pi1.lc_rois], marker='^', markersize=8, color='r')

            if ref1_exists:
                ref_noise = np.average([roi.std for roi in ref1.lc_ref_rois])
                ax_lfcnr.plot([abs(roi.pixel_value - roi.background)/pi_noise for roi in ref1.lc_rois], marker='^', color='r', markersize=8, markerfacecolor="None", linestyle="--")
                CNR = [abs(ref1.lc_rois[0].pixel_value - ref1.lc_rois[0].background)/ref_noise,
                       abs(pi1.lc_rois[0].pixel_value - pi1.lc_rois[0].background)/pi_noise]
                noise = [ref_noise, pi_noise]
            else:
                CNR = [np.nan, abs(pi1.lc_rois[0].pixel_value - pi1.lc_rois[0].background)/pi_noise]
                noise = [np.nan, pi_noise]

            ax_lfcnr.plot([], [], color='r', linestyle="--", label='Reference')
            ax_lfcnr.plot([], [], color='r', label='Current')
            ax_lfcnr.grid(True)
            ax_lfcnr.set_title('Contrast-Noise Ratio')
            ax_lfcnr.set_xlabel('ROI #')
            ax_lfcnr.set_ylabel('CNR')
            ax_lfcnr.set_xticks(np.arange(0, len(pi1.lc_rois), 1))
            ax_lfcnr.legend(loc='upper right', ncol=2, columnspacing=0, fontsize=12, handletextpad=0)
            ax_lfcnr.margins(0.05)

            # rMTF
            pi_noise2 = pi1.hc_ref_rois[0].std  # The white(background) reference ROI of the HC ROIS
            mtfs_pi1 = [np.sqrt(np.nanvar(roi.circle_mask()) - pi_noise2**2) for roi in pi1.hc_rois]
            mtfs_pi1_norm = max(mtfs_pi1)
            mtfs_pi1 = [a/mtfs_pi1_norm for a in mtfs_pi1]
            if ref1_exists:
                ref_noise2 = ref1.hc_ref_rois[0].std
                mtfs_ref1 = [np.sqrt(np.nanvar(roi.circle_mask()) - ref_noise2**2) for roi in ref1.hc_rois]
                mtfs_ref1_norm = max(mtfs_ref1)
                mtfs_ref1 = [a/mtfs_ref1_norm for a in mtfs_ref1]
            else:
                mtfs_ref1 = [np.nan]*len(mtfs_pi1)

            if len(CONFIG['PlanarImaging']['LPPMM_LEEDSTOR'].split(",")) == 9:
                lppmm = [float(k.strip()) for k in CONFIG['PlanarImaging']['LPPMM_LEEDSTOR'].split(",")]
            else:
                return template("error_template", {"error_message": "Check the configuration file. There should be nine LPPMM.",
                                "plweb_folder": PLWEB_FOLDER})

            ax_rmtf.plot(lppmm, mtfs_pi1, marker='D', markersize=8, color='b')
            if ref1_exists:
                ax_rmtf.plot(lppmm, mtfs_ref1, marker='D', color='b', markersize=8, markerfacecolor="None", linestyle="--")
            ax_rmtf.plot([], [], color='b', linestyle="--", label='Reference')
            ax_rmtf.plot([], [], color='b', label='Current')
            ax_rmtf.grid(True)
            ax_rmtf.set_title('High-frequency rMTF')
            ax_rmtf.set_xlabel('Line pairs per mm')
            ax_rmtf.set_ylabel('relative MTF')
            ax_rmtf.legend(loc='upper right', ncol=2, columnspacing=0, fontsize=12, handletextpad=0)
            ax_rmtf.margins(0.05)
            f30 = [np.interp(0.3, mtfs_ref1[::-1], lppmm[::-1]), np.interp(0.3, mtfs_pi1[::-1], lppmm[::-1])]
            f40 = [np.interp(0.4, mtfs_ref1[::-1], lppmm[::-1]), np.interp(0.4, mtfs_pi1[::-1], lppmm[::-1])]
            f50 = [np.interp(0.5, mtfs_ref1[::-1], lppmm[::-1]), np.interp(0.5, mtfs_pi1[::-1], lppmm[::-1])]
            f80 = [np.interp(0.8, mtfs_ref1[::-1], lppmm[::-1]), np.interp(0.8, mtfs_pi1[::-1], lppmm[::-1])]

            script = mpld3.fig_to_html(fig, d3_url=D3_URL, mpld3_url=MPLD3_URL)
            script2 = mpld3.fig_to_html(fig2, d3_url=D3_URL, mpld3_url=MPLD3_URL)

            variables = {"script": script,
                 "script2": script2,
                 "plweb_folder": PLWEB_FOLDER,
                 "f30": f30,
                 "f40": f40,
                 "f50": f50,
                 "f80": f80,
                 "pyl": pyl,
                 "CNR": CNR,
                 "noise": noise,
                 "pdf_report_enable": "0",
                 "lppmm": lppmm,
                 "display_lppmm": "1"
                 }

    elif phantom == "Las Vegas":

        # First analyze first image
        try:
            pi1 = planar_imaging.LasVegas(file_path1)
            if clip_box != 0:
                try:
                    pi1.image.check_inversion()
                    clip_around_image(pi1.image, clip_box)
                except Exception as e:
                    return template("error_template", {"error_message": "Unable to apply clipbox. "+str(e), "plweb_folder": PLWEB_FOLDER})
            pi1.analyze(low_contrast_threshold=lowtresh, invert=inv)
        except:
             return template("error_template", {"error_message": "Cannot analyze image 1.",
                                               "plweb_folder": PLWEB_FOLDER})

        # Analyze reference images if they exists
        if ref1_exists:
            try:
                ref1 = planar_imaging.LasVegas(ref_path1)
                if clip_box != 0:
                    try:
                        ref1.image.check_inversion()
                        clip_around_image(ref1.image, clip_box)
                    except Exception as e:
                        return template("error_template", {"error_message": "Unable to apply clipbox. "+str(e), "plweb_folder": PLWEB_FOLDER})
                ref1.analyze(low_contrast_threshold=lowtresh, invert=inv)
            except:
                 return template("error_template", {"error_message": "Cannot analyze reference image 1."\
                                                    " You can delete the image if you want to continue.",
                                                   "plweb_folder": PLWEB_FOLDER})

        fig = Figure(figsize=(9.5, 5), tight_layout={"w_pad":3, "pad": 4})
        ax_ref = fig.add_subplot(1,2,1)
        ax_pi = fig.add_subplot(1,2,2)

        # Plot reference image and regions
        if ref1_exists:
            ax_ref.imshow(ref1.image.array, cmap=matplotlib.cm.gray, interpolation="none", aspect="equal", origin='upper')
            ax_ref.set_title('Las Vegas Reference Image')
            ax_ref.axis('off')
            # plot the low contrast ROIs
            for ind, roi in enumerate(ref1.bg_rois):
                roi.plot2axes(ax_ref, edgecolor='yellow')
                ax_ref.text(roi.center.x, roi.center.y ,"B", horizontalalignment='center', verticalalignment='center')
            for ind, roi in enumerate(ref1.lc_rois):
                roi.plot2axes(ax_ref, edgecolor=roi.plot_color_constant if pyl else "r")
                ax_ref.text(roi.center.x, roi.center.y ,str(ind), horizontalalignment='center', verticalalignment='center', fontsize=1)
        else:
           ax_ref.text(0.5, 0.5 ,"Reference image not available", horizontalalignment='center', verticalalignment='center')

        # Plot current image and regions
        ax_pi.imshow(pi1.image.array, cmap=matplotlib.cm.gray, interpolation="none", aspect="equal", origin='upper')
        ax_pi.axis('off')
        ax_pi.set_title('Las Vegas Current Image')
        # plot the low contrast ROIs
        for ind, roi in enumerate(pi1.bg_rois):
                roi.plot2axes(ax_pi, edgecolor='yellow')
                ax_pi.text(roi.center.x, roi.center.y ,"B", horizontalalignment='center', verticalalignment='center')
        for ind, roi in enumerate(pi1.lc_rois):
            roi.plot2axes(ax_pi, edgecolor = roi.plot_color_constant if pyl else "r")
            ax_pi.text(roi.center.x, roi.center.y, str(ind), horizontalalignment='center', verticalalignment='center', fontsize=1)

        # Zoom on phantom if requested:
        if bbox:
            pad = 15  # Additional space between cyan bbox and plot
            if ref1_exists:
                bounding_box_ref = ref1.phantom_ski_region.bbox
                bbox_center_ref = ref1.phantom_center

                if abs(bounding_box_ref[1] - bounding_box_ref[3]) >= abs(bounding_box_ref[2] - bounding_box_ref[0]):
                    dist = abs(bounding_box_ref[1] - bounding_box_ref[3])/2
                    ax_ref.set_ylim(bbox_center_ref.y + dist + pad, bbox_center_ref.y - dist - pad)
                    ax_ref.set_xlim(bbox_center_ref.x - dist - pad, bbox_center_ref.x + dist + pad)
                else:
                    dist = abs(bounding_box_ref[2] - bounding_box_ref[0])/2
                    ax_ref.set_ylim(bbox_center_ref.y + dist + pad, bbox_center_ref.y - dist - pad)
                    ax_ref.set_xlim(bbox_center_ref.x - dist - pad, bbox_center_ref.x + dist + pad)
                    
                ax_ref.plot([bounding_box_ref[1], bounding_box_ref[1], bounding_box_ref[3], bounding_box_ref[3], bounding_box_ref[1]],
                            [bounding_box_ref[2], bounding_box_ref[0], bounding_box_ref[0], bounding_box_ref[2], bounding_box_ref[2]], c="cyan")
                ax_ref.autoscale(False)

            bounding_box_pi = pi1.phantom_ski_region.bbox
            bbox_center_pi = pi1.phantom_center
            if abs(bounding_box_pi[1] - bounding_box_pi[3]) >= abs(bounding_box_pi[2] - bounding_box_pi[0]):
                dist = abs(bounding_box_pi[1] - bounding_box_pi[3])/2
                ax_pi.set_ylim(bbox_center_pi.y + dist + pad, bbox_center_pi.y - dist - pad)
                ax_pi.set_xlim(bbox_center_pi.x - dist - pad, bbox_center_pi.x + dist + pad)
            else:
                dist = abs(bounding_box_pi[2] - bounding_box_pi[0])/2
                ax_pi.set_ylim(bbox_center_pi.y + dist + pad, bbox_center_pi.y - dist - pad)
                ax_pi.set_xlim(bbox_center_pi.x - dist - pad, bbox_center_pi.x + dist + pad)

            ax_pi.plot([bounding_box_pi[1], bounding_box_pi[1], bounding_box_pi[3], bounding_box_pi[3], bounding_box_pi[1]],
                        [bounding_box_pi[2], bounding_box_pi[0], bounding_box_pi[0], bounding_box_pi[2], bounding_box_pi[2]], c="cyan")
            ax_pi.autoscale(False)

        if pyl:
            # Plot low frequency contrast, CNR and rMTF
            fig2 = Figure(figsize=(9, 4), tight_layout={"w_pad":1})
            ax_lfc = fig2.add_subplot(1,2,1)
            ax_lfcnr = fig2.add_subplot(1,2,2)

            # lfc
            ax_lfc.plot([abs(roi.contrast_constant) for roi in pi1.lc_rois], marker='o', markersize=8, color='r')
            if ref1_exists:
                ax_lfc.plot([abs(roi.contrast_constant) for roi in ref1.lc_rois], marker='o', color='r', markersize=8,
                             markerfacecolor="None", linestyle="--")

            ax_lfc.plot([0, len(pi1.lc_rois)], [lowtresh, lowtresh], "-g")
            ax_lfc.plot([], [], color='r', linestyle="--", label='Reference')
            ax_lfc.plot([], [], color='r', label='Current')
            ax_lfc.grid(True)
            ax_lfc.set_title('Low-frequency Contrast')
            ax_lfc.set_xlabel('ROI #')
            ax_lfc.set_ylabel('Contrast constant')
            ax_lfc.set_xticks(np.arange(0, len(pi1.lc_rois)))
            ax_lfc.legend(loc='upper right', ncol=2, columnspacing=0, fontsize=10, handletextpad=0)
            ax_lfc.margins(0.05)
            # CNR
            ax_lfcnr.plot([abs(roi.contrast_to_noise) for roi in pi1.lc_rois], marker='^', markersize=8, color='r')
            if ref1_exists:
                ax_lfcnr.plot([abs(roi.contrast_to_noise) for roi in ref1.lc_rois], marker='^', color='r', markersize=8,
                               markerfacecolor="None", linestyle="--")
            ax_lfcnr.plot([], [], color='r', linestyle="--", label='Reference')
            ax_lfcnr.plot([], [], color='r', label='Current')
            ax_lfcnr.grid(True)
            ax_lfcnr.set_title('Contrast-Noise Ratio')
            ax_lfcnr.set_xlabel('ROI #')
            ax_lfcnr.set_ylabel('CNR')
            ax_lfcnr.set_xticks(np.arange(0, len(pi1.lc_rois)))
            ax_lfcnr.legend(loc='upper right', ncol=2, columnspacing=0, fontsize=10, handletextpad=0)
            ax_lfcnr.margins(0.05)

            if ref1_exists:
                median_contrast = [np.median([roi.contrast for roi in ref1.lc_rois]), np.median([roi.contrast for roi in pi1.lc_rois])]
                median_CNR = [np.median([roi.contrast_to_noise for roi in ref1.lc_rois]), np.median([roi.contrast_to_noise for roi in pi1.lc_rois])]
            else:
                median_contrast = [np.nan, np.median([roi.contrast for roi in pi1.lc_rois])]
                median_CNR = [np.nan, np.median([roi.contrast_to_noise for roi in pi1.lc_rois])]
            

            script = mpld3.fig_to_html(fig, d3_url=D3_URL, mpld3_url=MPLD3_URL)
            script2 = mpld3.fig_to_html(fig2, d3_url=D3_URL, mpld3_url=MPLD3_URL)

            variables = {"script": script,
                 "script2": script2,
                 "plweb_folder": PLWEB_FOLDER,
                 "f30": [np.nan, np.nan],
                 "f40": [np.nan, np.nan],
                 "f50": [np.nan, np.nan],
                 "f80": [np.nan, np.nan],
                 "pyl": pyl,
                 "median_contrast": median_contrast,
                 "median_CNR": median_CNR,
                 "pdf_report_enable": CONFIG['PlanarImaging']['GENERATE_PDF_REPORT'],
                 "lppmm": [np.nan],
                 "display_lppmm": "0"
                 }
            
            if CONFIG['PlanarImaging']['GENERATE_PDF_REPORT'] == "True":
                pdf_file = tempfile.NamedTemporaryFile(delete=False, prefix="PlanarImaging_", suffix=".pdf", dir=PDF_REPORT_FOLDER)
                metadata = RestToolbox.GetInstances(ORTHANC_URL, [w1])
                try:
                    patient = metadata[0]["PatientName"]
                except:
                    patient = ""
                try:
                    stationname = metadata[0]["StationName"]
                except:
                    stationname = ""
                try:
                    date_time = RestToolbox.get_datetime(metadata[0])
                    date_var = datetime.datetime.strptime(date_time[0], "%Y%m%d").strftime("%d/%m/%Y")
                except:
                    date_var = ""
                pi1.publish_pdf(pdf_file, notes=["Date = "+date_var, "Patient = "+patient, "Station = "+stationname])
        
                variables["pdf_report_filename"] = os.path.basename(pdf_file.name)
        else:
            # Plot low frequency contrast, CNR and rMTF
            fig2 = Figure(figsize=(9, 4), tight_layout={"w_pad":1})
            ax_lfc = fig2.add_subplot(1,2,1)
            ax_lfcnr = fig2.add_subplot(1,2,2)

            ax_lfc.plot([abs(100*(roi.pixel_value - roi.background))/roi.background for roi in pi1.lc_rois], marker='o', markersize=8, color='r')
            if ref1_exists:
                ax_lfc.plot([abs(100*(roi.pixel_value - roi.background))/roi.background for roi in ref1.lc_rois], marker='o', color='r', markersize=8, markerfacecolor="None", linestyle="--")

            ax_lfc.plot([], [], color='r', linestyle="--", label='Reference')
            ax_lfc.plot([], [], color='r', label='Current')
            ax_lfc.grid(True)
            ax_lfc.set_title('Low-frequency Contrast')
            ax_lfc.set_xlabel('ROI #')
            ax_lfc.set_ylabel('Contrast [%]')
            ax_lfc.set_xticks(np.arange(0, len(pi1.lc_rois), 1))
            ax_lfc.legend(loc='upper right', ncol=2, columnspacing=0, fontsize=10, handletextpad=0)
            ax_lfc.margins(0.05)

            pi_noise = np.average([roi.std for roi in pi1.bg_rois])

            ax_lfcnr.plot([abs(roi.pixel_value - roi.background)/pi_noise for roi in pi1.lc_rois], marker='^', markersize=8, color='r')

            if ref1_exists:
                ref_noise = np.average([roi.std for roi in ref1.bg_rois])
                ax_lfcnr.plot([abs(roi.pixel_value - roi.background)/ref_noise for roi in ref1.lc_rois], marker='^', color='r', markersize=8, markerfacecolor="None", linestyle="--")
                CNR = [abs(ref1.lc_rois[3].pixel_value - ref1.lc_rois[3].background)/ref_noise,
                       abs(pi1.lc_rois[3].pixel_value - pi1.lc_rois[3].background)/pi_noise]
                noise = [ref_noise, pi_noise]
            else:
                CNR = [np.nan, abs(pi1.lc_rois[3].pixel_value - pi1.lc_rois[3].background)/pi_noise]
                noise = [np.nan, pi_noise]

            ax_lfcnr.plot([], [], color='r', linestyle="--", label='Reference')
            ax_lfcnr.plot([], [], color='r', label='Current')
            ax_lfcnr.grid(True)
            ax_lfcnr.set_title('Contrast-Noise Ratio')
            ax_lfcnr.set_xlabel('ROI #')
            ax_lfcnr.set_ylabel('CNR')
            ax_lfcnr.set_xticks(np.arange(0, len(pi1.lc_rois), 1))
            ax_lfcnr.legend(loc='upper right', ncol=2, columnspacing=0, fontsize=10, handletextpad=0)
            ax_lfcnr.margins(0.05)

            script = mpld3.fig_to_html(fig, d3_url=D3_URL, mpld3_url=MPLD3_URL)
            script2 = mpld3.fig_to_html(fig2, d3_url=D3_URL, mpld3_url=MPLD3_URL)

            variables = {"script": script,
                 "script2": script2,
                 "plweb_folder": PLWEB_FOLDER,
                 "f30": [np.nan, np.nan],
                 "f40": [np.nan, np.nan],
                 "f50": [np.nan, np.nan],
                 "f80": [np.nan, np.nan],
                 "pyl": pyl,
                 "CNR": CNR,
                 "noise": noise,
                 "pdf_report_enable": "0",
                 "lppmm": [np.nan],
                 "display_lppmm": "0"
                 }
    delete_figure([fig, fig2])
    delete_files_in_subfolders([temp_folder1]) # Delete image

    #gc.collect()
    return template("planar_imaging_results", variables)


@app.route(PLWEB_FOLDER + '/planar_imaging_calculate/<w1>', method="POST")
def planar_imaging_calculate(w1):
    '''This function analyses 2D phantom images'''
    clip_box = float(request.forms.get('hidden_clipbox'))*10.0
    phantom = request.forms.get('hidden_phantom')
    machine = request.forms.get('hidden_machine')
    leedsrot = float(request.forms.get('hidden_leedsrot'))
    pyl = request.forms.get('hidden_pyl')
    inv = request.forms.get('hidden_inv')
    bbox = request.forms.get('hidden_bbox')
    use_reference = request.forms.get('hidden_ref')
    use_reference = True if use_reference=="true" else False

    pyl = True if pyl=="true" else False
    inv = True if inv=="true" else False
    bbox = True if bbox=="true" else False  # To show the phantom region and zoom in

    args = {"clip_box": clip_box, "phantom": phantom, "machine": machine, "leedsrot":leedsrot,
            "pyl":pyl, "inv": inv, "bbox": bbox, "use_reference": use_reference, "w1": w1}
    p = Pool(1)
    data = p.map(planar_imaging_helperf, [args])
    p.close()
    p.join()
    return data


@app.route(PLWEB_FOLDER + '/catphan', method="POST")
def catphan_start():
    """Read from database and return list of patients"""
    try:
        variables = Read_from_dcm_database()
    except ConnectionError:
        return template("error_template", {"error_message": "Orthanc is refusing connection.",
                                           "plweb_folder": PLWEB_FOLDER})
    variables["machines_503"] = [k.strip() for k in CONFIG['Catphan']['503_MACHINES'].split(",")]
    variables["machines_504"] = [k.strip() for k in CONFIG['Catphan']['504_MACHINES'].split(",")]
    variables["machines_600"] = [k.strip() for k in CONFIG['Catphan']['600_MACHINES'].split(",")]
    variables["machines_604"] = [k.strip() for k in CONFIG['Catphan']['604_MACHINES'].split(",")]
    variables["PHANTOMS"] = ["Catphan 503", "Catphan 504", "Catphan 600", "Catphan 604"]
    hu_tolerance = float(CONFIG['Catphan']['TOLERANCE_HU'])
    lcv_tolerance = float(CONFIG['Catphan']['TOLERANCE_LCV'])
    scaling_tolerance = float(CONFIG['Catphan']['TOLERANCE_SCALING'])
    thickness_tolerance = float(CONFIG['Catphan']['TOLERANCE_THICKNESS'])
    low_contrast_tolerance = float(CONFIG['Catphan']['TOLERANCE_LOWCONTRAST'])
    cnr_threshold = float(CONFIG['Catphan']['THRESHOLD_CNR'])
    mtf_tolerance = float(CONFIG['Catphan']['TOLERANCE_MTF'])
    uniformity_index = float(CONFIG['Catphan']['TOLERANCE_UNIFORMITYIDX'])
    variables["hu_tolerance"] = hu_tolerance
    variables["lcv_tolerance"] = lcv_tolerance
    variables["scaling_tolerance"] = scaling_tolerance
    variables["thickness_tolerance"] = thickness_tolerance
    variables["low_contrast_tolerance"] = low_contrast_tolerance
    variables["cnr_threshold"] = cnr_threshold
    variables["mtf_tolerance"] = mtf_tolerance
    variables["uniformity_index"] = uniformity_index
    return template("catphan", variables)


def catphan_helperf(args):
    '''This function analyzes the Catphan image'''
    use_reference = args["use_reference"]
    phantom = args["phantom"]
    machine = args["machine"]
    HU_delta = args["HU_delta"]
    s = args["series"]

    hu_tolerance = float(CONFIG['Catphan']['TOLERANCE_HU'])
    lcv_tolerance = float(CONFIG['Catphan']['TOLERANCE_LCV'])
    scaling_tolerance = float(CONFIG['Catphan']['TOLERANCE_SCALING'])
    thickness_tolerance = float(CONFIG['Catphan']['TOLERANCE_THICKNESS'])
    low_contrast_tolerance = float(CONFIG['Catphan']['TOLERANCE_LOWCONTRAST'])
    cnr_threshold = float(CONFIG['Catphan']['THRESHOLD_CNR'])
    mtf_tolerance = float(CONFIG['Catphan']['TOLERANCE_MTF'])
    uniformityidx_tolerance = float(CONFIG['Catphan']['TOLERANCE_UNIFORMITYIDX'])
    
    # Check if reference images are present for this phantom and machine:
    if phantom == "Catphan 503":
        phantom_folder = "Catphan503"
    elif phantom == "Catphan 504":
        phantom_folder = "Catphan504"
    elif phantom == "Catphan 600":
        phantom_folder = "Catphan600"
    elif phantom == "Catphan 604":
        phantom_folder = "Catphan604"
    else:
        raise ValueError("Uknown phantom")

    ref_path = os.path.join(CT_REF, phantom_folder, machine)

    if os.path.exists(ref_path):
        ref_exists = True
    else:
        ref_exists = False

    if machine == "":
        ref_exists = False

    if use_reference and ref_exists:
        try:
            if phantom == "Catphan 503":
                mycbct_ref = pylinac_ct.CatPhan503(ref_path)
            elif phantom == "Catphan 504":
                mycbct_ref = pylinac_ct.CatPhan504(ref_path)
            elif phantom == "Catphan 600":
                mycbct_ref = pylinac_ct.CatPhan600(ref_path)
            elif phantom == "Catphan 604":
                mycbct_ref = pylinac_ct.CatPhan604(ref_path)

            mycbct_ref.analyze(hu_tolerance=hu_tolerance, scaling_tolerance=scaling_tolerance,
                               thickness_tolerance=thickness_tolerance, low_contrast_tolerance=low_contrast_tolerance,
                               cnr_threshold=cnr_threshold)
        except Exception as e:
            return template("error_template", {"error_message": "Unable to anaylze ref. image. "+str(e),
                                               "plweb_folder": PLWEB_FOLDER})
    elif use_reference and not ref_exists:
        return template("error_template", {"error_message": "Reference image does not exist.",
                                               "plweb_folder": PLWEB_FOLDER})
    
    folder_path = RestToolbox.GetSeries2Folder2(ORTHANC_URL, s)

    try:
        if phantom == "Catphan 503":
            mycbct = pylinac_ct.CatPhan503(folder_path)
        elif phantom == "Catphan 504":
            mycbct = pylinac_ct.CatPhan504(folder_path)
        elif phantom == "Catphan 600":
            mycbct = pylinac_ct.CatPhan600(folder_path)
        elif phantom == "Catphan 604":
            mycbct = pylinac_ct.CatPhan604(folder_path)

        mycbct.analyze(hu_tolerance=hu_tolerance, scaling_tolerance=scaling_tolerance,
                       thickness_tolerance=thickness_tolerance, low_contrast_tolerance=low_contrast_tolerance,
                       cnr_threshold=cnr_threshold)
    except Exception as e:
        return template("error_template", {"error_message": "Module CatPhan cannot calculate. "+str(e),
                                           "plweb_folder": PLWEB_FOLDER})


    # ######################### CTP528 - Resolution ###################################
    fig_dcm = Figure(figsize=(10, 5), tight_layout={"w_pad":3, "pad": 2})
    ax1 = fig_dcm.add_subplot(1,2,1)
    ax2 = fig_dcm.add_subplot(1,2,2)

    # Reference image array
    if use_reference and ref_exists:
        ax1.imshow(mycbct_ref.ctp528.image.array, cmap=matplotlib.cm.gray, interpolation="none", aspect="equal", origin='upper')
        ax1.set_title('CTP528 reference image')
        ax1.autoscale(enable=False)
    else:
        ax1.text(0.5, 0.5 ,"Reference image not available", horizontalalignment='center', verticalalignment='center')

    # Analysed current array
    ax2.imshow(mycbct.ctp528.image.array, cmap=matplotlib.cm.gray, interpolation="none", aspect="equal", origin='upper')
    ax2.set_title('CTP528 current image')
    ax2.autoscale(enable=False)

    # Plot rMTF and gather some data
    fig_mtf = Figure(figsize=(5, 5), tight_layout={"w_pad":2, "pad": 1})
    ax_mtf = fig_mtf.add_subplot(1,1,1)

    msize = 8
    if use_reference and ref_exists:
        mtf_vals_ref = list(mycbct_ref.ctp528.mtfs.values())
        ax_mtf.plot(mycbct_ref.ctp528.lp_freq[:len(mtf_vals_ref)], mtf_vals_ref, marker='o', color="blue",
                    markersize=msize, markerfacecolor="None", linestyle="--")

    mtf_vals = list(mycbct.ctp528.mtfs.values())
    ax_mtf.plot(mycbct.ctp528.lp_freq[:len(mtf_vals)], mtf_vals, marker='o', color="blue", markersize=msize)
    ax_mtf.margins(0.05)
    ax_mtf.grid('on')
    ax_mtf.set_xlabel('Line pairs / mm')
    ax_mtf.set_ylabel("Relative MTF")
    ax_mtf.set_title('Modulation transfer function')
    
    script_ctp528 = mpld3.fig_to_html(fig_dcm, d3_url=D3_URL, mpld3_url=MPLD3_URL)
    script_ctp528mtf = mpld3.fig_to_html(fig_mtf, d3_url=D3_URL, mpld3_url=MPLD3_URL)

    # Some data:
    mtf50_ref = mycbct_ref.ctp528.mtf(percent=50) if use_reference and ref_exists else np.nan
    mtf50 = mycbct.ctp528.mtf(percent=50)
    mtf80_ref = mycbct_ref.ctp528.mtf(percent=80) if use_reference and ref_exists else np.nan
    mtf80 = mycbct.ctp528.mtf(percent=80)

    if use_reference and ref_exists:
        mtf_passing = True if abs(100*(mtf50-mtf50_ref)/mtf50_ref)<=mtf_tolerance else False
    else:
        mtf_passing = None

    # ####################### CTP404 - GEOMETRY HU LINEARITY ####################
    fig_404 = Figure(figsize=(10, 5), tight_layout={"w_pad":3, "pad": 2})
    ax404_1 = fig_404.add_subplot(1,2,1)
    ax404_2 = fig_404.add_subplot(1,2,2)

    def ctp404_plotROI(mycbct, fig, axis):
        # Plot lines and circles - taken from pylinac
        # plot HU linearity ROIs
        for roi in mycbct.ctp404.hu_rois.values():
            axis.add_patch(matplotlib.patches.Circle((roi.center.x, roi.center.y), edgecolor=roi.plot_color, radius=roi.radius, fill=False))
        for roi in mycbct.ctp404.bg_hu_rois.values():
            axis.add_patch(matplotlib.patches.Circle((roi.center.x, roi.center.y), edgecolor='blue', radius=roi.radius, fill=False))
        # plot thickness ROIs
        for roi in mycbct.ctp404.thickness_rois.values():
            axis.add_patch(matplotlib.patches.Rectangle((roi.bl_corner.x, roi.bl_corner.y), width=roi.width, height=roi.height,
                                                           angle=0, edgecolor="blue", alpha=1, facecolor="g", fill=False))
        # plot geometry lines
        for line in mycbct.ctp404.lines.values():
            axis.plot((line.point1.x, line.point2.x), (line.point1.y, line.point2.y), linewidth=1, color=line.pass_fail_color)

        # Plot tooltips for patches
        names = []
        hu_rois_centers_x = []
        hu_rois_centers_y = []
        hu_rois_radius = []

        for name, roi in mycbct.ctp404.hu_rois.items():
            names.append(name)
            hu_rois_centers_x.append(roi.center.x)
            hu_rois_centers_y.append(roi.center.y)
            hu_rois_radius.append((roi.radius)**2)

        hu_rois_ttip = axis.scatter(hu_rois_centers_x, hu_rois_centers_y, s = hu_rois_radius, alpha=0)
        labels = [names[i] for i in range(len(names))]
        tooltip = mpld3.plugins.PointLabelTooltip(hu_rois_ttip, labels=labels)
        mpld3.plugins.connect(fig, tooltip)
        # Add tooltips for 4 lines
        inc = 1
        for line in mycbct.ctp404.lines.values():
            hu_lines_ttip = axis.plot((line.point1.x, line.point2.x), (line.point1.y, line.point2.y), alpha=0, lw=7)
            tooltip2 = mpld3.plugins.LineLabelTooltip(hu_lines_ttip[0], label="Line "+str(inc))
            mpld3.plugins.connect(fig, tooltip2)
            inc += 1

    # Reference image
    if use_reference and ref_exists:
        ax404_1.imshow(mycbct_ref.ctp404.image.array, cmap=matplotlib.cm.gray, interpolation="none", aspect="equal", origin='upper')
        #mycbct_ref.ctp404.plot_rois(ax404_1)
        ctp404_plotROI(mycbct_ref, fig_404, ax404_1)  # alternative
        ax404_1.set_title('CTP404 reference image')
        ax404_1.autoscale(enable=False)
        ax404_1.set_xlim([0, mycbct_ref.ctp404.image.shape[1]])
        ax404_1.set_ylim([mycbct_ref.ctp404.image.shape[0], 0])
    else:
        ax404_1.text(0.5, 0.5 ,"Reference image not available", horizontalalignment='center', verticalalignment='center')
    # Current image
    ax404_2.imshow(mycbct.ctp404.image.array, cmap=matplotlib.cm.gray, interpolation="none", aspect="equal", origin='upper')
    ctp404_plotROI(mycbct, fig_404, ax404_2)  # alternative
    #mycbct.ctp404.plot_rois(ax404_2)
    ax404_2.set_xlim([0, mycbct.ctp404.image.shape[1]])
    ax404_2.set_ylim([mycbct.ctp404.image.shape[0], 0])
    ax404_2.set_title('CTP404 current image')
    ax404_2.autoscale(enable=False)

    # Draw HU linearity plot
    def plot_linearity(mycbct, fig, axis, plot_delta):
        '''Taken from pylinac'''
        nominal_x_values = [roi.nominal_val for roi in mycbct.ctp404.hu_rois.values()]
        actual_values = []
        diff_values = []
        if plot_delta:
            values = []
            names = []
            for name, roi in mycbct.ctp404.hu_rois.items():
                names.append(name)
                values.append(roi.value_diff)
                actual_values.append(roi.pixel_value)
                diff_values.append(roi.value_diff)
            nominal_measurements = [0]*len(values)
            ylabel = 'HU Delta'
        else:
            values = []
            names = []
            for name, roi in mycbct.ctp404.hu_rois.items():
                names.append(name)
                values.append(roi.pixel_value)
                actual_values.append(roi.pixel_value)
                diff_values.append(roi.value_diff)
            nominal_measurements = nominal_x_values
            ylabel = 'Measured Values'

        points = axis.plot(nominal_x_values, values, 'g+', markersize=15, mew=2)
        axis.plot(nominal_x_values, nominal_measurements)
        axis.plot(nominal_x_values, np.array(nominal_measurements) + mycbct.ctp404.hu_tolerance, 'r--')
        axis.plot(nominal_x_values, np.array(nominal_measurements) - mycbct.ctp404.hu_tolerance, 'r--')
        axis.margins(0.07)
        axis.grid(True, alpha=0.35)
        axis.set_xlabel("Nominal Values")
        axis.set_ylabel(ylabel)
        axis.set_title("HU linearity")
        labels = [names[i]+" -- Nom.={:.1f}, Act.={:.1f}, Diff.={:.1f}".format(nominal_x_values[i], actual_values[i], diff_values[i]) for i in range(len(names))]
        tooltip = mpld3.plugins.PointLabelTooltip(points[0], labels=labels, location="top right")
        mpld3.plugins.connect(fig, tooltip)

    fig_404_HU = Figure(figsize=(10, 4.5), tight_layout={"w_pad":1, "pad": 1})
    ax_HU_ref = fig_404_HU.add_subplot(1,2,1)
    ax_HU = fig_404_HU.add_subplot(1,2,2)
    # Reference HU linearity
    if use_reference and ref_exists:
        plot_linearity(mycbct_ref, fig_404_HU, ax_HU_ref, plot_delta=HU_delta)
    else:
        ax_HU_ref.text(0.5, 0.5 ,"Reference image not available", horizontalalignment='center', verticalalignment='center')
        ax_HU_ref.set_title("HU linearity")
    # Current HU linearity
    plot_linearity(mycbct, fig_404_HU, ax_HU, plot_delta=HU_delta)
    
    # Gather data from HU holes:
    if use_reference and ref_exists:
        HU_values_ref_dict = mycbct_ref.ctp404.hu_rois.values()
        HU_values_ref = [roi.pixel_value for roi in HU_values_ref_dict]
        HU_std_ref = [round(roi.std, 1) for roi in HU_values_ref_dict]
        HU_diff_ref = [roi.value_diff for roi in HU_values_ref_dict]
        lcv_ref = round(mycbct_ref.ctp404.lcv, 2)
        slice_thickness_ref = round(mycbct_ref.ctp404.meas_slice_thickness, 2)
        lines_ref = []  # Line length
        for l in mycbct_ref.ctp404.lines.values():
            lines_ref.append(round(l.length_mm, 2))
        lines_avg_ref = round(mycbct_ref.ctp404.avg_line_length, 2)
        phantom_roll_ref = round(mycbct_ref.ctp404.catphan_roll, 2)
        dicom_slice_thickness_ref = round(mycbct_ref.ctp404.slice_thickness, 2)
    else:
        HU_values_ref = [np.nan]*len(mycbct.ctp404.hu_rois.values())
        HU_std_ref = [np.nan]*len(mycbct.ctp404.hu_rois.values())
        HU_diff_ref = [np.nan]*len(mycbct.ctp404.hu_rois.values())
        lcv_ref = np.nan
        slice_thickness_ref = np.nan
        lines_ref = [np.nan]*len(mycbct.ctp404.lines.values())
        lines_avg_ref = np.nan
        phantom_roll_ref = np.nan
        dicom_slice_thickness_ref = np.nan

    HU_values_dict = mycbct.ctp404.hu_rois.values()
    HU_values = [roi.pixel_value for roi in HU_values_dict]
    HU_std = [round(roi.std, 1) for roi in HU_values_dict]
    HU_diff = [roi.value_diff for roi in HU_values_dict]
    
    HU_nominal = [roi.nominal_val for roi in HU_values_dict]
    HU_names = list(mycbct.ctp404.hu_rois.keys())
    lcv = mycbct.ctp404.lcv
    slice_thickness = round(mycbct.ctp404.meas_slice_thickness, 2)
    phantom_roll = round(mycbct.ctp404.catphan_roll, 2)
    dicom_slice_thickness = round(mycbct.ctp404.slice_thickness, 2)

    lines = []  # Line length
    for l in mycbct.ctp404.lines.values():
        lines.append(round(l.length_mm, 2))
    lines_avg = round(mycbct.ctp404.avg_line_length, 2)

    passed_HU = mycbct.ctp404.passed_hu
    passed_thickness = mycbct.ctp404.passed_thickness
    passed_geometry = mycbct.ctp404.passed_geometry
    
    # Calculate LCV according to Elekta
    if use_reference and ref_exists:
        poly0 = mycbct_ref.ctp404.hu_rois['Poly'].nominal_val
        ldpe0 = mycbct_ref.ctp404.hu_rois['LDPE'].nominal_val
        mean_ldpe_ref = np.nanmean(mycbct_ref.ctp404.hu_rois['LDPE'].circle_mask())
        mean_poly_ref = np.nanmean(mycbct_ref.ctp404.hu_rois['Poly'].circle_mask())
        contrast_ref = abs(mean_ldpe_ref - mean_poly_ref)
        noise_ref = (mycbct_ref.ctp404.hu_rois['LDPE'].std + mycbct_ref.ctp404.hu_rois['Poly'].std)/2
        lcv_ref_elekta = abs((poly0-ldpe0)/10)/(contrast_ref / noise_ref)
    else:
        lcv_ref_elekta = np.nan
    
    poly0 = mycbct.ctp404.hu_rois['Poly'].nominal_val
    ldpe0 = mycbct.ctp404.hu_rois['LDPE'].nominal_val
    mean_ldpe = np.nanmean(mycbct.ctp404.hu_rois['LDPE'].circle_mask())
    mean_poly = np.nanmean(mycbct.ctp404.hu_rois['Poly'].circle_mask())
    contrast = abs(mean_ldpe - mean_poly)
    noise = (mycbct.ctp404.hu_rois['LDPE'].std + mycbct.ctp404.hu_rois['Poly'].std)/2
    lcv_elekta = abs((poly0-ldpe0)/10)/(contrast / noise)

    if CONFIG['Catphan']['USE_LCV2TOL'] == "True":
        passed_lcv = True if lcv_elekta < lcv_tolerance else False
    else:
        passed_lcv = True if lcv < lcv_tolerance else False
    passed_404 = passed_HU and passed_thickness and passed_geometry and passed_lcv

    script_404 = mpld3.fig_to_html(fig_404, d3_url=D3_URL, mpld3_url=MPLD3_URL)
    script_404_HU = mpld3.fig_to_html(fig_404_HU, d3_url=D3_URL, mpld3_url=MPLD3_URL)

    # ############################## CTP486 - UNIFORMITY ####################
    fig_486 = Figure(figsize=(10, 5), tight_layout={"w_pad":3, "pad": 2})
    ax486_1 = fig_486.add_subplot(1,2,1)
    ax486_2 = fig_486.add_subplot(1,2,2)

    if use_reference and ref_exists:
        ax486_1.imshow(mycbct_ref.ctp486.image.array, cmap=matplotlib.cm.gray, interpolation="none", aspect="equal", origin='upper')
        mycbct_ref.ctp486.plot_rois(ax486_1)
        # Add text inside ROI for reference to uniformity index:
        for ind, roi in enumerate(mycbct_ref.ctp486.rois.values()):
            ax486_1.text(roi.center.x, roi.center.y, str(ind), horizontalalignment='center', verticalalignment='center')
    else:
        ax486_1.text(0.5, 0.5 ,"Reference image not available", horizontalalignment='center', verticalalignment='center')

    ax486_2.imshow(mycbct.ctp486.image.array, cmap=matplotlib.cm.gray, interpolation="none", aspect="equal", origin='upper')
    mycbct.ctp486.plot_rois(ax486_2)
    # Add text inside ROI for reference to uniformity index:
    for ind, roi in enumerate(mycbct.ctp486.rois.values()):
        ax486_2.text(roi.center.x, roi.center.y, str(ind), horizontalalignment='center', verticalalignment='center')
    ax486_1.set_title('CTP486 reference image')
    ax486_1.autoscale(enable=False)
    ax486_2.set_title('CTP486 current image')
    ax486_2.autoscale(enable=False)

    script_486 = mpld3.fig_to_html(fig_486, d3_url=D3_URL, mpld3_url=MPLD3_URL)

    # Draw orthogonal profiles:
    fig_486_profile = Figure(figsize=(10, 4), tight_layout={"w_pad":1, "pad": 1})
    ax486_profile_ref = fig_486_profile.add_subplot(1,2,1)
    ax486_profile = fig_486_profile.add_subplot(1,2,2)
    if use_reference and ref_exists:
        mycbct_ref.ctp486.plot_profiles(ax486_profile_ref)
    else:
        ax486_profile_ref.text(0.5, 0.5 ,"Reference image not available", horizontalalignment='center', verticalalignment='center')
    mycbct.ctp486.plot_profiles(ax486_profile)
    ax486_profile_ref.set_title('Reference uniformity profiles')
    ax486_profile.set_title('Current uniformity profiles')

    script_486_profile = mpld3.fig_to_html(fig_486_profile, d3_url=D3_URL, mpld3_url=MPLD3_URL)

    # Get mean pixel values and uniformity index:
    # take into account slope and intercept HU = slope * px + intercept
    intercept = int(mycbct.dicom_stack.metadata.RescaleIntercept)
    if use_reference and ref_exists:
        intercept_ref = int(mycbct_ref.dicom_stack.metadata.RescaleIntercept)
        hvalues_ref = [roi.pixel_value for roi in mycbct_ref.ctp486.rois.values()]
        uidx_ref = round(mycbct_ref.ctp486.uniformity_index, 2)
        uidx2_ref = round(100*( max(hvalues_ref)-min(hvalues_ref))/(max(hvalues_ref)-intercept_ref), 2)
    else:
        hvalues_ref = [np.nan]*len(mycbct.ctp486.rois.values())
        uidx_ref = np.nan
        uidx2_ref = np.nan
    hvalues = [roi.pixel_value for roi in mycbct.ctp486.rois.values()]
    passed_uniformity = mycbct.ctp486.overall_passed

    uidx = round(mycbct.ctp486.uniformity_index, 2)
    uidx2 = round(100*( max(hvalues)-min(hvalues))/(max(hvalues)-intercept), 2)
    if CONFIG['Catphan']['USE_UNIFORMITYIDX2'] == "True":
        passed_uniformity_index = True if abs(uidx2)<=uniformityidx_tolerance else False
    else:
        passed_uniformity_index = True if abs(uidx)<=uniformityidx_tolerance else False

    # ############################## CTP515 - LOW CONTRAST ####################
    if phantom != "Catphan 503":
        show_ctp515 = True
        fig_515 = Figure(figsize=(10, 5), tight_layout={"w_pad":3, "pad": 2})
        ax515_1 = fig_515.add_subplot(1,2,1)
        ax515_2 = fig_515.add_subplot(1,2,2)
        if use_reference and ref_exists:
            ax515_1.imshow(mycbct_ref.ctp515.image.array, cmap=matplotlib.cm.gray, interpolation="none", aspect="equal", origin='upper')
            mycbct_ref.ctp515.plot_rois(ax515_1)
        else:
            ax515_1.text(0.5, 0.5 ,"Reference image not available", horizontalalignment='center', verticalalignment='center')
    
        ax515_2.imshow(mycbct.ctp515.image.array, cmap=matplotlib.cm.gray, interpolation="none", aspect="equal", origin='upper')
        mycbct.ctp515.plot_rois(ax515_2)
        ax515_1.set_title('CTP515 reference image')
        ax515_1.autoscale(enable=False)
        ax515_2.set_title('CTP515 current image')
        ax515_2.autoscale(enable=False)

        script_515 = mpld3.fig_to_html(fig_515, d3_url=D3_URL, mpld3_url=MPLD3_URL)
    
        fig_515_contrast = Figure(figsize=(5, 5), tight_layout={"w_pad":1, "pad": 1})
        ax515_contrast = fig_515_contrast.add_subplot(1,1,1)
        
        sizes_515 = np.array(list(mycbct.ctp515.rois.keys()), dtype=int)
        contrasts_515 = [roi.contrast_constant for roi in mycbct.ctp515.rois.values()]
        ax515_contrast.plot(sizes_515, contrasts_515, marker='o', color="blue",
                            markersize=8, markerfacecolor="None", linestyle="-")
        
        if use_reference and ref_exists:
            sizes_515_ref = np.array(list(mycbct_ref.ctp515.rois.keys()), dtype=int)
            contrasts_515_ref= [roi.contrast_constant for roi in mycbct_ref.ctp515.rois.values()]
            ax515_contrast.plot(sizes_515_ref, contrasts_515_ref, marker='o', color="blue",
                                markersize=8, markerfacecolor="None", linestyle="--")
            ctp515_visible_ref = mycbct_ref.ctp515.rois_visible
        else:
            ctp515_visible_ref = np.nan
        ax515_contrast.margins(0.05)
        ax515_contrast.grid(True)
        ax515_contrast.set_xlabel('ROI size (mm)')
        ax515_contrast.set_ylabel("Contrast * Diameter")

        script_515_contrast = mpld3.fig_to_html(fig_515_contrast, d3_url=D3_URL, mpld3_url=MPLD3_URL)

        ctp515_passed = mycbct.ctp515.overall_passed
        #ctp515_passed = None
        ctp515_visible = mycbct.ctp515.rois_visible
    else:
        show_ctp515 = False
        script_515_contrast = None
        script_515 = None
        ctp515_visible_ref = np.nan
        ctp515_passed = None
        ctp515_visible = np.nan

    delete_files_in_subfolders([folder_path]) # Delete temporary images

    variables = {
                "script_ctp528": script_ctp528,
                "script_ctp528mtf": script_ctp528mtf,
                "mtf50_ref": mtf50_ref,
                "mtf50": mtf50,
                "mtf80_ref": mtf80_ref,
                "mtf80": mtf80,
                "mtf_passing": mtf_passing,
                "script_404": script_404,
                "script_404_HU": script_404_HU,
                "HU_values_ref": HU_values_ref,
                "HU_std_ref": HU_std_ref,
                "HU_values": HU_values,
                "HU_std": HU_std,
                "HU_nominal": HU_nominal,
                "HU_names": HU_names,
                "HU_diff_ref": HU_diff_ref,
                "HU_diff": HU_diff,
                "passed_HU": passed_HU,
                "passed_thickness": passed_thickness,
                "passed_geometry": passed_geometry,
                "passed_lcv": passed_lcv,
                "passed_404": passed_404,
                "lcv_ref": lcv_ref,
                "lcv": round(lcv, 2),
                "lcv_ref_elekta": round(lcv_ref_elekta, 2),
                "lcv_elekta": round(lcv_elekta, 2),
                "slice_thickness": slice_thickness,
                "slice_thickness_ref": slice_thickness_ref,
                "dicom_slice_thickness": dicom_slice_thickness,
                "dicom_slice_thickness_ref": dicom_slice_thickness_ref,
                "lines_ref": lines_ref,
                "lines": lines,
                "lines_avg": lines_avg,
                "lines_avg_ref": lines_avg_ref,
                "phantom_roll": phantom_roll,
                "phantom_roll_ref": phantom_roll_ref,
                "script_486": script_486,
                "script_486_profile": script_486_profile,
                "hvalues_ref": hvalues_ref,
                "hvalues": hvalues,
                "passed_uniformity": passed_uniformity,
                "passed_uniformity_index": passed_uniformity_index,
                "uidx": uidx,
                "uidx_ref": uidx_ref,
                "uidx2": uidx2,
                "uidx2_ref": uidx2_ref,
                "script_515": script_515,
                "script_515_contrast": script_515_contrast,
                "show_ctp515": show_ctp515,
                "ctp515_passed": ctp515_passed,
                "ctp515_visible": ctp515_visible,
                "ctp515_visible_ref": ctp515_visible_ref,
                "plweb_folder": PLWEB_FOLDER
                
                }
    return template("catphan_results", variables)


@app.route(PLWEB_FOLDER + '/catphan_calculate/<s>', method="POST")
def catphan_calculate(s):
    use_reference = request.forms.get('hidden_ref')
    use_reference = True if use_reference=="true" else False
    phantom = request.forms.get('hidden_phantom')
    machine = request.forms.get('hidden_machine')
    HU_delta = request.forms.get('hidden_HUdelta')
    HU_delta = True if HU_delta=="true" else False
    args = {"use_reference": use_reference, "phantom": phantom, "machine": machine, "HU_delta": HU_delta, "series": s}
    p = Pool(1)
    data = p.map(catphan_helperf, [args])
    p.close()
    p.join()
    return data


@app.route(PLWEB_FOLDER + '/dynalog', method="POST")
def dynalog():
    # First page
    DTA = float(CONFIG["Dynalog"]["TOLERANCE_DTA"])
    DD = float(CONFIG["Dynalog"]["TOLERANCE_DD"])
    resolution = float(CONFIG["Dynalog"]["RESOLUTION"])
    threshold = float(CONFIG["Dynalog"]["THRESHOLD"])
    labels = [k.strip() for k in CONFIG["Dynalog"]["REPOSITORIES_LABELS"].split(",")]

    variables = {
                 "orthanc_url": ORTHANC_URL,
                 "institution": INSTITUTION,
                 "plweb_folder": PLWEB_FOLDER,
                 "DTA": DTA,
                 "DD": DD,
                 "resolution": resolution,
                 "threshold": threshold,
                 "labels": ["All"]+labels
                 }
    return template("dynalog", variables)
 
@app.route(PLWEB_FOLDER + '/dynalogPatients/<s>', method="POST")
def dynalogPatients(s):
    # Function that sends patients for a parcticular date
    conn = sql.connect(DYNALOG_DATABASE)
    curs = conn.cursor()
    
    if s == "getall":
        curs.execute("SELECT DISTINCT PatientName, PatientLastName, PatientID FROM VarianDynalog "\
                     " ORDER BY PatientLastName")
    elif s == "getfiltered":
        filt = request.forms.get('filter')
        label = request.forms.get('label')
        if label == "All":
            curs.execute("SELECT DISTINCT PatientName, PatientLastName, PatientID FROM VarianDynalog "\
                         " WHERE PatientLastName LIKE '" + filt + "%' "\
                         " OR PatientID LIKE '%" + filt + "%' ORDER BY PatientLastName")
        else:
            curs.execute("SELECT DISTINCT PatientName, PatientLastName, PatientID FROM VarianDynalog "\
                         " WHERE (Repository = '"+label+"') AND (PatientLastName LIKE '" + filt + "%' "\
                         " OR PatientID LIKE '%" + filt + "%') ORDER BY PatientLastName")
        
    else:
        
        folder = request.forms.get('folder')
        if folder == "All":
            curs.execute("SELECT DISTINCT PatientName, PatientLastName, PatientID FROM VarianDynalog "\
                         "WHERE Date = '" + s + "' ORDER BY PatientLastName")
        else:
            curs.execute("SELECT DISTINCT PatientName, PatientLastName, PatientID FROM VarianDynalog "\
                         "WHERE Date = '" + s + "' AND Repository = '"+folder+"' ORDER BY PatientLastName")
    data = curs.fetchall()
    curs.close()
    conn.close()
    data_values = [f[1]+",,, "+f[0]+",,, "+f[2] for f in data]
    data_label = [f[1]+", "+f[0]+", "+f[2] for f in data]
    return json.dumps((data_label, data_values))


@app.route(PLWEB_FOLDER + '/dynalogRecords', method="POST")
def dynalogRecords():
    # Function for sending records for dynalog module
    patient = request.forms.get('patient')
    lastname, name, patientID = patient.split(",,, ")
    conn = sql.connect(DYNALOG_DATABASE)
    curs = conn.cursor()
    curs.execute("SELECT DISTINCT Date FROM VarianDynalog "\
                 "WHERE PatientID = '" + patientID + "'"\
                 " AND PatientName = '" + name + "' AND PatientLastName = '" + lastname + "'"\
                 " ORDER BY Date")
    data = curs.fetchall()
    curs.close()
    conn.close()
    data = [f[0] for f in data]
    return json.dumps((data))


@app.route(PLWEB_FOLDER + '/dynalogRecordData', method="POST")
def dynalogRecordData():
    patient = request.forms.get('patient')
    record = request.forms.get('record')
    
    lastname, name, patientID = patient.split(",,, ")
    conn = sql.connect(DYNALOG_DATABASE)
    curs = conn.cursor()

    curs.execute("SELECT BeamID, Gantry, Time, Snapshots, Beamholds, RMSmax, RMSmax2, "\
                 "DIFFmax, DIFFmax2, RMSAvg, GammaAvg, GammaIndex, FileName, ZipArchive, GammaTol, Repository "\
                 "FROM VarianDynalog WHERE PatientName = '"+name+"' AND PatientLastName = '"+lastname+"' "\
                 "AND PatientID = '"+patientID+"' AND Date = '" + record + "' ORDER BY PatientLastName, BeamID, Date, Time")
    data = curs.fetchall()
    curs.close()
    conn.close()
    data = np.asarray(data)

    for k in data:
        k[1] = round(float(k[1]), 1)
        k[5] = round(float(k[5])*10, 2)
        k[6] = round(float(k[6])*10, 2)
        k[7] = round(float(k[7])*10, 2)
        k[8] = round(float(k[8])*10, 2)
        k[9] = round(float(k[9])*10, 2)
        k[10] = round(float(k[10]), 2)
        k[11] = round(float(k[11]), 1)
    return json.dumps((data.tolist()))

@app.route(PLWEB_FOLDER + '/dynalogGetReportDate', method="POST")
def dynalogGetReportDate():
    date = request.forms.get('hidden_date')
    folder = request.forms.get('hidden_folder')
    search_by_folder = " AND Repository = '"+folder+"' " if folder!="All" else " "
    conn = sql.connect(DYNALOG_DATABASE)
    curs = conn.cursor()
    if date == "":
        curs.execute("SELECT MAX(ROWID) FROM VarianDynalog")
        last_row = str(curs.fetchone()[0])
        curs.execute("SELECT DateEntered FROM VarianDynalog WHERE ROWID = '"+last_row+"' ")
        date = curs.fetchone()[0]
        curs.execute("SELECT PatientID, Repository, BeamID, Gantry, Date, Time, Snapshots, Beamholds, RMSmax2, "\
                 "DIFFmax2, GammaAvg, GammaIndex "\
                 "FROM VarianDynalog WHERE DateEntered = '"+date+"'"+search_by_folder+"ORDER BY Repository, PatientID, Date, Time")
    else:
        curs.execute("SELECT PatientID, Repository, BeamID, Gantry, Date, Time, Snapshots, Beamholds, RMSmax2, "\
                     "DIFFmax2, GammaAvg, GammaIndex "\
                     "FROM VarianDynalog WHERE Date = '"+date+"'"+search_by_folder+"ORDER BY Repository, PatientID, Date, Time")
    data = curs.fetchall()
    curs.close()
    conn.close()

    variables = {
                "data": data,
                "date": date
                }
    return template("dynalog_report", variables)

@app.route(PLWEB_FOLDER + '/dynalogGetReportPatient', method="POST")
def dynalogGetReportPatient():
    patient = request.forms.get('hidden_patient')
    lastname, name, patientID = patient.split(",,, ")

    conn = sql.connect(DYNALOG_DATABASE)
    curs = conn.cursor()
    curs.execute("SELECT BeamID, Gantry, Date, Time, Snapshots, Beamholds, RMSmax, RMSmax2, "\
                 "DIFFmax, DIFFmax2, GammaAvg, GammaIndex, RMSAvg "\
                 "FROM VarianDynalog WHERE PatientID = '"+patientID+"' ORDER by Date")
    data1 = np.asarray(curs.fetchall())
    curs.close()
    conn.close()

    beamID = data1[:, 0]
    date = data1[:, 2]

    unique_beamid, counts_beamid = np.unique(beamID, return_counts=True)
    unique_date, inv_date, counts_date = np.unique(date, return_inverse=True, return_counts=True)

    kelly_colors = ['#222222', '#F3C300', '#875692', '#F38400']
    
    TOOLTIPS = [
        ("date", "@dates"),
        ("time", "@time"),
        ("gantry", "@gantry")
    ]

    x = []
    rms_max2 = []
    diff_max2 = []
    gammaind = []
    gammaavg = []
    rms_avg = []
    repetitions = []
    gantry = []
    time = []
    for p in range(0, len(unique_date), 1):
        x.append(p)
        temp = list(data1[data1[:,2]==unique_date[p], 7])  # keep one to count repetitions
        repetitions.append(len(temp))
        rms_max2 += [float(a) for a in temp]
        diff_max2 += [float(a) for a in list(data1[data1[:,2]==unique_date[p], 9])]
        gammaavg += [float(a) for a in list(data1[data1[:,2]==unique_date[p], 10])]
        gammaind += [float(a) for a in list(data1[data1[:,2]==unique_date[p], 11])]
        rms_avg += [float(a) for a in list(data1[data1[:,2]==unique_date[p], 12])]
        gantry += [float(a) for a in list(data1[data1[:,2]==unique_date[p], 1])]
        time += list(data1[data1[:,2]==unique_date[p], 3])

    x = list(np.repeat(np.arange(0, len(unique_date), 1), repetitions))
    dates = list(np.repeat(unique_date, repetitions))
    source = ColumnDataSource(data=dict(
        rms_max2=rms_max2,
        diff_max2=diff_max2,
        rms_avg=rms_avg,
        dates=dates,
        gantry=gantry,
        time=time,
        x=x
    ))
    
    fig1 = figure(plot_width=900, plot_height=450, tooltips=TOOLTIPS, toolbar_location="above")
    f1 = fig1.circle("x", "rms_max2", size = 10, color=kelly_colors[1], alpha=0.5, source=source)
    f2 = fig1.circle("x", "diff_max2", size = 10, color=kelly_colors[3], alpha=0.5,  source=source)
    f3 = fig1.circle("x", "rms_avg", size = 10, color=kelly_colors[2], alpha=0.5,  source=source)
    
    legend = Legend(items=[
            ("RMS MAX2"   , [f1]),
            ("DIFF MAX2" , [f2]),
            ("RMS AVG2" , [f3]),
        ], location="center", click_policy="hide")

    fig1.xaxis.axis_label = 'Fraction'
    fig1.yaxis.axis_label = '[cm]'
    fig1.add_layout(legend, 'right')
    
    TOOLTIPS2 = [
            ("date", "@dates"),
            ("time", "@time"),
            ("gamma index", "@gammaind")
        ]
    
    source2 = ColumnDataSource(data=dict(
        gammaind=gammaind,
        dates=dates,
        gantry=gantry,
        time=time,
        x=x
    ))
    
    fig2 = figure(plot_width=900, plot_height=200, tooltips=TOOLTIPS2, toolbar_location="above")
    f21 = fig2.circle("x", "gammaind", size = 10, color=kelly_colors[2], alpha=0.5, source=source2)
    legend2 = Legend(items=[
            ("Gamma index" , [f21])
        ], location="center", click_policy="hide")

    fig2.xaxis.axis_label = 'Fraction'
    fig2.yaxis.axis_label = '[]'
    fig2.add_layout(legend2, 'right')
    
    TOOLTIPS3 = [
            ("date", "@dates"),
            ("time", "@time"),
            ("gamma avg", "@gammaavg")
        ]
    
    source3 = ColumnDataSource(data=dict(
        gammaavg=gammaavg,
        dates=dates,
        gantry=gantry,
        time=time,
        x=x
    ))
    
    fig3 = figure(plot_width=900, plot_height=200, tooltips=TOOLTIPS3, toolbar_location="above")
    f31 = fig3.circle("x", "gammaavg", size = 10, color=kelly_colors[2], alpha=0.5, source=source3)
    legend3 = Legend(items=[
            ("Gamma avg.", [f31])
        ], location="center", click_policy="hide")

    fig3.xaxis.axis_label = 'Fraction'
    fig3.yaxis.axis_label = '[]'
    fig3.add_layout(legend3, 'right')
    
    script1, div1 = components(fig1)
    script2, div2 = components(fig2)
    script3, div3 = components(fig3)
    
    variables = {
                "bokeh_file_css": BOKEH_FILE_CSS,
                "bokeh_file_js": BOKEH_FILE_JS,
                "script1": script1,
                "div1": div1,
                "script2": script2,
                "div2": div2,
                "script3": script3,
                "div3": div3
                }
    return template("dynalog_report_patient", variables)

@app.route(PLWEB_FOLDER + '/dynalogGetReportUploads', method="POST")
def dynalogGetReportUploads():
    conn = sql.connect(DYNALOG_DATABASE)
    curs = conn.cursor()
    curs.execute("SELECT DISTINCT DateEntered FROM VarianDynalog")
    data = curs.fetchall()
    curs.close()
    conn.close()
    variables = {
                "data": data
                }
    return template("dynalog_report_uploads", variables)
    
    
@app.route(PLWEB_FOLDER + '/dynalog_analyze', method="POST")
def dynalog_analyze():
    ziparchive, filename = request.forms.get('filename_calc').split(",,,")
    mlc = request.forms.get('mlc')

    temp_folder = tempfile.mkdtemp(prefix="Temp_dynalog_", dir=TEMP_DYNALOG_FOLDER)
    try:
        with zipfile.ZipFile(os.path.join(DYNALOG_DATABASE_ARCHIVE, ziparchive), 'r') as z:
            z.extract("A" + filename + ".dlg", path=temp_folder)
            z.extract("B" + filename + ".dlg", path=temp_folder)
    except:
        return template("error_template", {"error_message": "Cannot extract dynalogs from zip archive.",
                                           "plweb_folder": PLWEB_FOLDER})

    exclude_beam_off = True if CONFIG["Dynalog"]["EXCLUDE_BEAM_OFF"]=="True" else False

    try:
        log = VarianDynalog.VarianDynalog(VarianDynalog.get_dataset_from_dlg(os.path.join(temp_folder, "A" + filename + ".dlg"), exclude_beam_off=exclude_beam_off))
    except:
        return template("error_template", {"error_message": "Cannot analyze dynalogs.",
                                           "plweb_folder": PLWEB_FOLDER})

    time = os.path.basename(filename).split("_")[0]
    record = datetime.datetime.strptime(str(time), '%Y%m%d%H%M%S')
    
    # Plot MLC positions:
    MLC_nr = log.MLC_number
    num_snapshots = log.number_of_snapshots
    snap = 0 # start with first snapshot
    dt = 0.05 # seconds

    # Actual positions of leaves
    positionsA = np.asarray(log.bankA_actual).reshape(int(MLC_nr/2), num_snapshots)
    positionsB = np.asarray(log.bankB_actual).reshape(int(MLC_nr/2), num_snapshots)

    # Planned positions of leaves
    positionsA_plan = np.asarray(log.bankA_expected).reshape(int(MLC_nr/2), num_snapshots)
    positionsB_plan = np.asarray(log.bankB_expected).reshape(int(MLC_nr/2), num_snapshots)

    diffA = positionsA - positionsA_plan
    diffB = positionsB - positionsB_plan
    carriageA = log.carriageA_actual
    carriageB = log.carriageB_actual
    
    speedA_actual = np.diff(positionsA, axis = 1)/dt
    speedB_actual = np.diff(positionsB, axis = 1)/dt

    # Suppose speed is zero at t=0
    speedA_actual = np.hstack((np.zeros((speedA_actual.shape[0], 1)), speedA_actual))
    speedB_actual = np.hstack((np.zeros((speedB_actual.shape[0], 1)), speedB_actual))

    beam_on = log.beam_on
    beam_hold = log.beam_hold

    rmsA_on = np.sqrt(np.mean(np.square(diffA[:, beam_on==1]), axis=1))
    rmsB_on = np.sqrt(np.mean(np.square(diffB[:, beam_on==1]), axis=1))
    rmsA_hold = np.sqrt(np.mean(np.square(diffA[:, (beam_on==1)&(beam_hold==0)]), axis=1))
    rmsB_hold = np.sqrt(np.mean(np.square(diffB[:, (beam_on==1)&(beam_hold==0)]), axis=1))

    diffA_max_on = np.max(np.abs(diffA[:, beam_on==1]))
    diffB_max_on = np.max(np.abs(diffB[:, beam_on==1]))
    diffA_max_hold = np.max(np.abs(diffA[:, (beam_on==1)&(beam_hold==0)]))
    diffB_max_hold = np.max(np.abs(diffB[:, (beam_on==1)&(beam_hold==0)]))

    jaw_x1 = np.asarray((log.x1))
    jaw_x2 = np.asarray((log.x2))
    jaw_y1 = np.asarray((log.y1))
    jaw_y2 = np.asarray((log.y2))

    if mlc == "Varian_120":
        MLC_width = MLC_DYNALOG["Varian_120"]
    elif mlc == "Varian_80":
        MLC_width = MLC_DYNALOG["Varian_80"]
    elif mlc == "Varian_120HD":
        MLC_width = MLC_DYNALOG["Varian_120HD"]
    else:
        return template("error_template", {"error_message": "Cannot recognize MLC type.",
                                           "plweb_folder": PLWEB_FOLDER})

    MLC_width = np.asarray(MLC_width).reshape(-1, 1)/10.0  # DIvide by 10 because it is in mm.

    if 2*(MLC_width.shape[0]-1) != MLC_nr:
        return template("error_template", {"error_message": "Inconsistent number of MLC leaves.",
                                           "plweb_folder": PLWEB_FOLDER})

    mlc_points = []
    mlc_points_plan = []
    x1 = []
    y1 = []
    x2 = []
    y2 = []
    x1_plan = []
    y1_plan = []
    x2_plan = []
    y2_plan = []
    jawX = []
    jawY = []
    p1x = []
    p1y = []
    p2x = []
    p2y = []
    p3x = []
    p3y = []
    p4x = []
    p4y = []

    for s in np.arange(0, num_snapshots, 1):

        mlc_points = MLCpositions_to_points(positionsA[:, s].reshape(-1, 1), positionsB[:, s].reshape(-1, 1), MLC_width)
        # Planned positions:
        mlc_points_plan = MLCpositions_to_points(positionsA_plan[:, s].reshape(-1, 1), positionsB_plan[:, s].reshape(-1, 1), MLC_width)

        x1.append(list(mlc_points[0][:, 0]))# These are points for both banks
        y1.append(list(mlc_points[0][:, 1]))
        x2.append(list(mlc_points[1][:, 0]))
        y2.append(list(mlc_points[1][:, 1]))

        x1_plan.append(list(mlc_points_plan[0][:, 0]))  # These are original points for banks
        y1_plan.append(list(mlc_points_plan[0][:, 1]))
        x2_plan.append(list(mlc_points_plan[1][:, 0]))
        y2_plan.append(list(mlc_points_plan[1][:, 1]))

        # Text coordinates:
        x1j = jaw_x1[s]
        x2j = jaw_x2[s]
        y1j = jaw_y1[s]
        y2j = jaw_y2[s]
        p1x.append([(x1j+x2j)/2])
        p1y.append([(y1j+y1j)/2])
        p2x.append([(x2j+x2j)/2])
        p2y.append([(y1j+y2j)/2])
        p3x.append([(x1j+x2j)/2])
        p3y.append([(y2j+y2j)/2])
        p4x.append([(x1j+x1j)/2])
        p4y.append([(y1j+y2j)/2])

        #  Jaws:
        jawX.append([x2j, x1j, x1j, x2j, x2j])
        jawY.append([y2j, y2j, y1j, y1j, y2j])
        
    CAX1x = [21, -21]
    CAX1y = [0, 0]
    CAX2x = [0, 0]
    CAX2y = [-21, 21]
    
    # Here we start drawing:
    fig = figure(x_range=[-21, 21], y_range=[-21, 21],
                 plot_width=500, plot_height=500, title="", match_aspect=True,
                 toolbar_location="right",
                 tools=["pan, wheel_zoom, box_zoom, reset, save"])

    fig.xgrid.grid_line_color = None
    fig.ygrid.grid_line_color = None

    if snap >= num_snapshots:
        snap = num_snapshots-1

    x1e = x1[snap]
    y1e = y1[snap]
    x2e = x2[snap]
    y2e = y2[snap]
    x1_plane = x1_plan[snap]
    y1_plane = y1_plan[snap]
    x2_plane = x2_plan[snap]
    y2_plane = y2_plan[snap]
    jawXe = jawX[snap]
    jawYe = jawY[snap]
    p1xe = p1x[snap]
    p1ye = p1y[snap]
    p2xe = p2x[snap]
    p2ye = p2y[snap]
    p3xe = p3x[snap]
    p3ye = p3y[snap]
    p4xe = p4x[snap]
    p4ye = p4y[snap]
    text_x1 = ["X1"]*num_snapshots
    text_x2 = ["X2"]*num_snapshots
    text_y1 = ["Y1"]*num_snapshots
    text_y2 = ["Y2"]*num_snapshots
    text_x1e = ["X1"]
    text_x2e = ["X2"]
    text_y1e = ["Y1"]
    text_y2e = ["Y2"]

    source_full = ColumnDataSource(data=dict(x1=x1, x2=x2, y1=y1, y2=y2,
                                        x1_plan=x1_plan, x2_plan=x2_plan,
                                        y1_plan=y1_plan, y2_plan=y2_plan
                                        ))

    source_current = ColumnDataSource(data=dict(x1e=x1e, x2e=x2e, y1e=y1e, y2e=y2e,
                                        x1_plane=x1_plane, x2_plane=x2_plane,
                                        y1_plane=y1_plane, y2_plane=y2_plane,
                                        ))

    source_jaw = ColumnDataSource(data=dict(jawX=jawX, jawY=jawY))
    source_current_jaw = ColumnDataSource(data=dict(jawXe=jawXe, jawYe=jawYe))


    source_tags_full = ColumnDataSource(data=dict(p1x=p1x, p1y=p1y, p2x=p2x,
                                                  p2y=p2y, p3x=p3x, p3y=p3y,
                                                  p4x=p4x, p4y=p4y,
                                                  text_x1=text_x1, text_x2=text_x2,
                                                  text_y1=text_y1, text_y2=text_y2))

    source_tags_current = ColumnDataSource(data=dict(p1xe=p1xe, p1ye=p1ye, p2xe=p2xe,
                                                  p2ye=p2ye, p3xe=p3xe, p3ye=p3ye,
                                                  p4xe=p4xe, p4ye=p4ye,
                                                  text_x1e=text_x1e, text_x2e=text_x2e,
                                                  text_y1e=text_y1e, text_y2e=text_y2e))

    fig.line("x1e", "y1e", line_color="blue", line_width=1, legend="Actual MLC", source=source_current)
    fig.line("x2e", "y2e", line_color="blue", line_width=1, source=source_current)

    # Plot planned MLC
    fig.line("x1_plane", "y1_plane", line_color="red", line_width=1, legend="Planned MLC", source=source_current)
    fig.line("x2_plane", "y2_plane", line_color="red", line_width=1, source=source_current)

    # Plot jaws (actual)
    fig.line("jawXe", "jawYe", source=source_current_jaw, line_color="green", line_width=2,
             legend="Actual Jaws")

    # Plot CAX
    fig.line(CAX1x, CAX1y, line_color="black", line_width=2)
    fig.line(CAX2x, CAX2y,  line_color="black", line_width=2)

    # Plot text (jaws):

    fig.text("p1xe", "p1ye",  text="text_y1e", source=source_tags_current,
             text_align='center', text_baseline='top',
             text_font_size=bokeh_value("12pt"))
    fig.text("p2xe", "p2ye", text="text_x2e", source=source_tags_current,
             text_align='left', text_baseline='middle',
             text_font_size=bokeh_value("12pt"))
    fig.text("p3xe", "p3ye", text="text_y2e", source=source_tags_current,
             text_align='center', text_baseline='bottom',
             text_font_size=bokeh_value("12pt"))
    fig.text("p4xe", "p4ye", text="text_x1e", source=source_tags_current,
             text_align='right', text_baseline='middle',
             text_font_size=bokeh_value("12pt"))

    fig.xaxis.axis_label_text_font_size = bokeh_value("12pt")
    fig.yaxis.axis_label_text_font_size = bokeh_value("12pt")
    fig.yaxis.axis_label_text_font_style = "normal"
    fig.xaxis.axis_label_text_font_style = "normal"
    fig.min_border = 0

    # Plot Bokeh plots of motion
    x = list(np.arange(0.5, int(MLC_nr/2)+0.5, 1))
    z1 = [list(i) for i in diffA.T]
    y1_new = z1[0]
    z2 = [list(i) for i in diffB.T]
    y2_new = z2[0]

    colorg = ["blue"]*int(MLC_nr/2)
    colorr = ["red"]*int(MLC_nr/2)

    A = [list(i) for i in speedA_actual.T]
    A1 = A[0]
    B = [list(i) for i in speedB_actual.T]
    B1 = B[0]

    left = np.arange(0, int(MLC_nr/2), 1)+0.5
    right = np.arange(1, int(MLC_nr/2)+1, 1)+0.5

    source_full_new = ColumnDataSource(data=dict(z1=z1, z2=z2,
                                                 A=A,  B=B))
    source_current_new = ColumnDataSource(data=dict(x=x, y1_new=y1_new, y2_new=y2_new,
                                          A1=A1, B1=B1, left=left,
                                          right=right,
                                          colorg=colorg, colorr=colorr, beam_on=[beam_on]*len(x)))

    y_max2 = np.max([np.abs(speedA_actual), np.abs(speedB_actual)])
    y_max = np.max([np.abs(diffA), np.abs(diffB)])

    fig_bokeh = figure(x_range=[0, int(MLC_nr/2)+1], plot_width=400,
                       y_range= [-y_max, y_max], title="X(actual) - X(expected) [cm]",
                       plot_height=250, toolbar_location="right",
                       tools = ["pan, wheel_zoom, box_zoom, reset, save"])

    fig_bokeh.quad(top="y1_new", bottom=0, left="left", right="right", source=source_current_new, fill_color="colorg",
                   line_color="blue", fill_alpha=0.5, line_alpha=0.5)

    fig_bokeh.quad(top="y2_new", bottom=0, left="left", right="right", source=source_current_new, fill_color="colorr",
                   line_color="red", fill_alpha=0.5, line_alpha=0.5)

    fig_bokeh.title.align = "center"

    # Second plot:
    fig_bokeh2 = figure(x_range=[0, int(MLC_nr/2)+1], plot_width=400,
                       y_range= [-y_max2, y_max2], title="Actual speed at isocenter [cm/s]",
                       plot_height=250, toolbar_location="right",
                      tools = ["pan, wheel_zoom, box_zoom, reset, save"])

    fig_bokeh2.quad(top="A1", bottom=0, left="left", right="right", source=source_current_new, fill_color="colorg",
                   line_color="blue", fill_alpha=0.5, line_alpha=0.5)

    fig_bokeh2.quad(top="B1", bottom=0, left="left", right="right", source=source_current_new, fill_color="colorr",
                   line_color="red", fill_alpha=0.5, line_alpha=0.5)

    fig_bokeh2.title.align = "center"

    slider = Slider(start=0, end=int(num_snapshots)-1, value=int(snap), step=1, title="Snapshot")

    callback = CustomJS(args=dict(source_current=source_current,
                                  source_full=source_full,
                                  source_jaw=source_jaw,
                                  source_current_jaw=source_current_jaw,
                                  source_tags_current=source_tags_current,
                                  source_tags_full=source_tags_full,
                                  source_current_new=source_current_new,
                                  source_full_new=source_full_new), code="""

                var data = source_current.data;
                var f = cb_obj.value;
                var data_full = source_full.data;
                var data_full_new = source_full_new.data;
                var data_current_new = source_current_new.data;
                var data_jaws_full = source_jaw.data;
                var data_jaws = source_current_jaw.data;
                var data_tags_full = source_tags_full.data;
                var data_tags_current = source_tags_current.data;

                x1 = data_full['x1'];
                x2 = data_full['x2'];
                y1 = data_full['y1'];
                y2 = data_full['y2'];
                x1_plan = data_full['x1_plan'];
                x2_plan = data_full['x2_plan'];
                y1_plan = data_full['y1_plan'];
                y2_plan = data_full['y2_plan'];
                jawX = data_jaws_full['jawX'];
                jawY = data_jaws_full['jawY'];
                p1x = data_tags_full['p1x'];
                p1y = data_tags_full['p1y'];
                p2x = data_tags_full['p2x'];
                p2y = data_tags_full['p2y'];
                p3x = data_tags_full['p3x'];
                p3y = data_tags_full['p3y'];
                p4x = data_tags_full['p4x'];
                p4y = data_tags_full['p4y'];
                text_x1 = data_tags_full['text_x1'];
                text_x2 = data_tags_full['text_x2'];
                text_y1 = data_tags_full['text_y1'];
                text_y2 = data_tags_full['text_y2'];

                for (i = 0; i < x1[0].length; i++) {
                    data['x1e'][i] = parseFloat(x1[parseInt(f)][i]);
                    data['y1e'][i] = parseFloat(y1[parseInt(f)][i]);
                    data['x2e'][i] = parseFloat(x2[parseInt(f)][i]);
                    data['y2e'][i] = parseFloat(y2[parseInt(f)][i]);
                    data['x1_plane'][i] = parseFloat(x1_plan[parseInt(f)][i]);
                    data['y1_plane'][i] = parseFloat(y1_plan[parseInt(f)][i]);
                    data['x2_plane'][i] = parseFloat(x2_plan[parseInt(f)][i]);
                    data['y2_plane'][i] = parseFloat(y2_plan[parseInt(f)][i]);
                }
                for (j = 0; j < jawX[0].length; j++){
                    data_jaws['jawXe'][j] = jawX[parseInt(f)][j];
                    data_jaws['jawYe'][j] = jawY[parseInt(f)][j];
                }
                
                data_tags_current['p1xe'] = p1x[parseInt(f)];
                data_tags_current['p1ye'] = p1y[parseInt(f)];
                data_tags_current['p2xe'] = p2x[parseInt(f)];
                data_tags_current['p2ye'] = p2y[parseInt(f)];
                data_tags_current['p3xe'] = p3x[parseInt(f)];
                data_tags_current['p3ye'] = p3y[parseInt(f)];
                data_tags_current['p4xe'] = p4x[parseInt(f)];
                data_tags_current['p4ye'] = p4y[parseInt(f)];

                data_tags_current['text_x1e'] = text_x1[parseInt(f)];
                data_tags_current['text_x2e'] = text_x2[parseInt(f)];
                data_tags_current['text_y1e'] = text_y1[parseInt(f)];
                data_tags_current['text_y2e'] = text_y2[parseInt(f)];

                var x = data_current_new['x'];
                beam_on = data_current_new['beam_on'][0];
    
                for (i = 0; i < x.length; i++) {
                    data_current_new['y1_new'][i] = data_full_new['z1'][f][i];
                    data_current_new['y2_new'][i] = data_full_new['z2'][f][i];
                    data_current_new['A1'][i] = data_full_new['A'][f][i];
                    data_current_new['B1'][i] = data_full_new['B'][f][i];
                    if (parseInt(beam_on[f]) == 1){
                        data_current_new['colorr'][i]='red';
                        data_current_new['colorg'][i]='blue';
                        }
                    else{
                        data_current_new['colorr'][i]='white';
                        data_current_new['colorg'][i]='white';
                    }
                }
                parent.beamOnOff(parseInt(f));
                source_current.change.emit();
                source_current_new.change.emit();

        """)
    slider.callback = callback

    size = "12pt"
    fig_bokeh.yaxis.axis_label_text_font_style = "normal"
    fig_bokeh.yaxis.axis_label_text_font_size = bokeh_value(size)
    fig_bokeh.title.text_font_size = bokeh_value(size)
    fig_bokeh.xgrid.grid_line_color = None
    fig_bokeh.ygrid.grid_line_color = None

    size = "12pt"
    fig_bokeh2.yaxis.axis_label_text_font_style = "normal"
    fig_bokeh2.yaxis.axis_label_text_font_size = bokeh_value(size)
    fig_bokeh2.title.text_font_size = bokeh_value(size)
    fig_bokeh2.xgrid.grid_line_color = None
    fig_bokeh2.ygrid.grid_line_color = None

    layout_bokeh = layout([
                        [widgetbox(slider, width=550)],
                        [fig, [fig_bokeh, fig_bokeh2]]
                        ]
                        )

    script1, div1 = components(layout_bokeh)

    # Plot fluences
    DTA = float(request.forms.get('gamma_DTA'))
    DD = float(request.forms.get('gamma_DD'))
    resolution = float(request.forms.get('gamma_res'))
    threshold = float(request.forms.get('gamma_thres'))
    gamma_tol_str = str(DD)+" / "+str(DTA)+" / "+str(threshold)+" / "+str(resolution)

    dose_ref = log.log.fluence.actual.calc_map(resolution=resolution)
    dose_eval = log.log.fluence.expected.calc_map(resolution=resolution)

    gamma_map = log.log.fluence.gamma.calc_map(doseTA=DD, distTA=DTA, threshold=threshold, resolution=resolution)

    size_x = 9
    size_y = 9
    
    fig1 = Figure(figsize=(size_x, size_y))
    ax1 = fig1.add_subplot(2, 2, 1)
    ax2 = fig1.add_subplot(2, 2, 2)
    ax3 = fig1.add_subplot(2, 2, 3)
    ax4 = fig1.add_subplot(2, 2, 4)

    cmap = matplotlib.cm.jet
    cmap_gamma = matplotlib.cm.inferno_r

    ax1.imshow(dose_ref.astype(np.float32, copy=False), cmap=cmap, interpolation='nearest',
               aspect="auto", vmin=0, origin="lower", vmax=np.max(dose_eval))
    ax1.autoscale(False)
    ax1.set_title("Actual Fluence")

    ax2.imshow(dose_eval.astype(np.float32, copy=False), cmap=cmap, interpolation='nearest',
               aspect="auto", vmin=0, origin="lower", vmax=np.max(dose_eval))
    ax2.autoscale(False)
    ax2.set_title("Expected Fluence")
    
    gam = ax3.imshow(gamma_map.astype(np.float32, copy=False), cmap=cmap_gamma, interpolation='nearest',
               aspect="auto", origin="lower", vmin=0, vmax=1)
    ax3.autoscale(False)
    ax3.set_title("Gamma map")
    cax0 = fig1.add_axes([ax3.get_position().x1-0.08, ax3.get_position().y0-0.02, 0.02, ax3.get_position().height])
    cb0 = fig1.colorbar(gam, ax=ax3, cax=cax0)
    cb0.outline.set_edgecolor('white')

    # Calculate threshold line to show it on gamma map:
    #level = np.max(dose_ref)*threshold
    #ax1.contour(np.flipud(dose_ref), levels=[level], colors = ["blue"])  # threshold
    #ax2.contour(np.flipud(dose_ref), levels=[level], colors = ["blue"])  # threshold
    #ax3.contour(np.flipud(dose_ref), levels=[level], colors = ["blue"])  # threshold
    #ax4.contour(np.flipud(dose_ref), levels=[level], colors = ["blue"])  # threshold

    dose_ref[dose_ref < np.max(dose_ref)*threshold] = np.nan
    dose_eval[dose_eval < np.max(dose_ref)*threshold] = np.nan

    fluence_difference = 100*(dose_ref-dose_eval)/dose_eval

    diff = ax4.imshow(fluence_difference.astype(np.float32, copy=False), cmap=cmap, interpolation="nearest",
                      aspect="auto", origin="lower", vmin=-5, vmax=5)
    ax4.autoscale(False)
    ax4.set_title("100 x (Actual-Expected)/Expected [%]")
    cax1 = fig1.add_axes([ax4.get_position().x1-0.01, ax4.get_position().y0-0.02, 0.02, ax4.get_position().height])
    fig1.colorbar(diff, ax=ax4, cax=cax1)
 
    fig1.tight_layout()
    script2 = mpld3.fig_to_html(fig1, d3_url=D3_URL, mpld3_url=MPLD3_URL)
    delete_figure([fig1])

    # Gamma histogram:
    gamma_avg = log.log.fluence.gamma.avg_gamma
    gamma_prcnt = log.log.fluence.gamma.pass_prcnt
    gamma_avg = round(gamma_avg, 2) if np.isfinite(gamma_avg) else "NA"
    gamma_prcnt = round(gamma_prcnt, 1) if np.isfinite(gamma_prcnt) else "NA"
    upper_bound = 1
    upper_outliers = np.sum(gamma_map.flatten()>upper_bound)

    fig2 = figure(x_range=[0, 1.1], y_range=[0.5, np.sum(gamma_map >= 0)], y_axis_type="log",
                 plot_width=340, plot_height=250, title="Gamma histogram",
                 toolbar_location="right",
                 tools=["pan, wheel_zoom, box_zoom, reset, save"])
    fig2.xgrid.grid_line_color = None
    fig2.ygrid.grid_line_color = None
    fig2.xaxis.axis_label = 'Gamma'
    fig2.yaxis.axis_label = 'Counts'
    hist2, edges2 = np.histogram(gamma_map.flatten(), density=False, bins=10, range=(0, 1))
    fig2.quad(top=hist2, bottom=0.001, left=edges2[:-1], right=edges2[1:], line_color='black')
    fig2.quad(top=upper_outliers, bottom=0.001, left=1, right=1.1, line_color='red', color='red')

    # Plot dose difference histogram:
    fluence_difference = fluence_difference[~np.isinf(fluence_difference)]
    fluence_difference = fluence_difference[~np.isnan(fluence_difference)]

    upper_bound2 = 10
    lower_bound2 = -10
    upper_outliers2 = np.sum(fluence_difference>upper_bound2)
    lower_outliers2 = np.sum(fluence_difference<lower_bound2)

    fig3 = figure(x_range=[-12, 12], y_range=[0.5, fluence_difference.size], y_axis_type="log",
                 plot_width=340, plot_height=250, title="Dose difference histogram, avg. = " + str(round(np.average(fluence_difference), 1)),
                 toolbar_location="right",
                 tools=["pan, wheel_zoom, box_zoom, reset, save"])
    fig3.xgrid.grid_line_color = None
    fig3.ygrid.grid_line_color = None
    fig3.xaxis.axis_label = 'Dose difference [%]'
    fig3.yaxis.axis_label = 'Counts'
    
    hist3, edges3 = np.histogram(fluence_difference, density=False, bins=20, range=(lower_bound2, upper_bound2))
    fig3.quad(top=hist3, bottom=0.001, left=edges3[:-1], right=edges3[1:], line_color='black')
    fig3.quad(top=upper_outliers2, bottom=0.001, left=10, right=11, line_color='red', color='red')
    fig3.quad(top=lower_outliers2, bottom=0.001, left=-11, right=-10, line_color='red', color='red')
    
    script3, div3 = components(row(fig2, fig3))

    # plot rms histograms
    fig4 = Figure(figsize=(10, 8))
    ax5 = fig4.add_subplot(2, 2, 1)
    ax55 = fig4.add_subplot(2, 2, 2)
    ax6 = fig4.add_subplot(2, 2, 3)
    ax66 = fig4.add_subplot(2, 2, 4)

    ax5.bar(np.arange(0.5, int(MLC_nr/2)+0.5, 1), rmsA_on, width=1, color="blue", edgecolor="None", alpha=0.5)
    ax5.bar(np.arange(0.5, int(MLC_nr/2)+0.5, 1), rmsB_on, width=1, color="None", edgecolor="red", alpha=1)
    ax55.bar(np.arange(0.5, int(MLC_nr/2)+0.5, 1), rmsA_hold, width=1, color="blue", edgecolor="None", alpha=0.5)
    ax55.bar(np.arange(0.5, int(MLC_nr/2)+0.5, 1), rmsB_hold, width=1, color="None", edgecolor="red", alpha=1)

    top = ax5.get_ylim()[1]
    max_patch = np.max([np.max(rmsA_on), np.max(rmsB_on)])
    ax5.add_patch(patches.Rectangle((0.44*MLC_nr, 0.95*top), 3, max_patch/25, alpha=0.5, edgecolor="none", facecolor="red"))
    ax5.annotate("A", (0.44*MLC_nr+4, 0.95*top), color='black', fontsize=10, ha='left', va='bottom')

    ax5.add_patch(patches.Rectangle((0.44*MLC_nr, 0.90*top), 3, max_patch/25, alpha=0.5, edgecolor="blue", facecolor="None"))
    ax5.annotate("B", (0.44*MLC_nr+4, 0.90*top), color='black', fontsize=10, ha='left', va='bottom')

    ax6.bar(np.arange(0.5, int(MLC_nr/2)+0.5, 1), np.max(np.abs(diffA[:, beam_on==1]), axis=1), width=1, color="blue",edgecolor="None", alpha=0.5)
    ax6.bar(np.arange(0.5, int(MLC_nr/2)+0.5, 1), np.max(np.abs(diffB[:, beam_on==1]), axis=1), width=1, color="None", edgecolor="red", alpha=1)
    ax66.bar(np.arange(0.5, int(MLC_nr/2)+0.5, 1), np.max(np.abs(diffA[:, (beam_on==1)&(beam_hold==0)]), axis=1), width=1, color="blue", edgecolor="None", alpha=0.5)
    ax66.bar(np.arange(0.5, int(MLC_nr/2)+0.5, 1), np.max(np.abs(diffB[:, (beam_on==1)&(beam_hold==0)]), axis=1), width=1, color="None", edgecolor="red", alpha=1)

    ax5.set_title("RMS - beam ON")
    ax55.set_title("RMS - beam ON and no holdoffs")
    ax5.set_ylabel('[cm]')
    ax55.set_ylim(ax5.get_ylim())

    ax66.set_title("MAX(ABS) - beam ON and no holdoffs")
    ax6.set_title("MAX(ABS(Act.-Exp.)) - beam ON")
    ax6.set_ylabel('[cm]')
    ax66.set_ylim(ax6.get_ylim())

    fig4.tight_layout()
    script_MLC_rms = mpld3.fig_to_html(fig4, d3_url=D3_URL, mpld3_url=MPLD3_URL)
    delete_figure([fig4])

    # Dose rate and gantry plot

    # Calculate gantry speed
    def f(a1, a2):
        # Calculate angle increment
        return 180 - abs(abs(a1 - a2) - 180)

    gantry = log.gantry
    muu = log.mu
    MU = list(muu/muu[-1])
    DR = list(np.diff(np.hstack((0, muu/muu[-1])))/dt)
    
    gantry_sum = 0
    gantry_sum_full = []
    for g in np.arange(0, gantry.shape[0]-1, 1):
        gantry_sum += f(gantry[g+1], gantry[g])
        gantry_sum_full.append(gantry_sum)

    # Do not pick every element:
    M = 2  #every M-th element
    MM = 3
    smooth_window = 7
    polyorder = 1
    
    gantry_sum_full_smooth = savgol_filter(gantry_sum_full[0:-1:M], window_length=smooth_window, polyorder=polyorder)
    gantry_speed = np.hstack((np.array([0]), np.diff(gantry_sum_full_smooth[0:-1:MM])/(M*MM*dt)))
    gantry_speed2 = np.hstack((np.array([0]), np.diff(gantry_sum_full)/dt))
    
    MU_smooth = savgol_filter(MU[0:-1:M], window_length=smooth_window, polyorder=polyorder)
    dose_rate_actual_full = np.hstack((np.array([0]), 60.0*np.diff(MU_smooth[0:-1:MM])/(M*MM*dt)))
    dose_rate_actual_full2 = np.hstack((np.array([0]), 60.0*np.diff(MU)/dt))
    
    fig5 = Figure(figsize=(10, 8))
    ax7 = fig5.add_subplot(2, 2, 3)
    ax8 = fig5.add_subplot(2, 2, 1)
    ax9 = fig5.add_subplot(2, 2, 4)
    ax10 = fig5.add_subplot(2, 2, 2)
    
    ax7.plot(np.arange(0, len(dose_rate_actual_full), 1)*dt*MM*M, dose_rate_actual_full, color="blue", drawstyle='steps')
    ax7.plot(np.arange(0, len(dose_rate_actual_full2), 1)*dt, dose_rate_actual_full2, color="blue", drawstyle='steps',  alpha=0.1)
    ax7.set_title("Actual dose rate")
    ax7.set_ylabel('[1/min] x Monitor Units')
    ax7.set_xlabel("Time [s]")
    ax7.set_ylim([0, np.max(dose_rate_actual_full2)*1.05])

    ax8.step(np.arange(0, len(beam_on), 1)*dt, beam_on, color="blue", where='post', alpha=0.8)
    ax8.plot(np.arange(0, len(MU), 1)*dt, MU, color="green")
    
    ax8.set_ylim([0, 1.5])
    top2 = ax8.get_ylim()[1]
    right2 = ax8.get_xlim()[1]
    ax8.add_patch(patches.Rectangle((right2*0.75, 0.90*top2), right2/25, 1/25, alpha=0.5, edgecolor="none", facecolor="blue"))
    ax8.annotate("Beam on", (right2*0.8, 0.90*top2), color='black', fontsize=10, ha='left', va='bottom')

    ax8.add_patch(patches.Rectangle((right2*0.75, 0.95*top2), right2/25, 1/25, alpha=0.5, edgecolor="none", facecolor="green"))
    ax8.annotate("MU", (right2*0.8, 0.95*top2), color='black', fontsize=10, ha='left', va='bottom')

    ax8.set_title("Beam on, MU vs time")
    ax8.set_xlabel("Time [s]")
    ax8.set_ylabel("ON = 1, OFF = 0")

    ax9.plot(np.arange(0, len(gantry), 1)*dt, gantry, color="blue", drawstyle='steps')
    ax9.set_title("Gantry (actual)")
    ax9.set_ylabel('[degree]')
    ax9.set_xlabel("Time [s]")

    ax10.plot(np.arange(0, len(gantry_speed), 1)*dt*M*MM, gantry_speed, color="blue", drawstyle='steps')
    ax10.plot(np.arange(0, len(gantry_speed2), 1)*dt, gantry_speed2, color="blue", drawstyle='steps', alpha=0.1)
    ax10.set_title("Gantry speed (actual), avg. = "+str(round(np.average(gantry_speed), 1)))
    ax10.set_ylabel('[degree/s]')
    ax10.set_xlabel("Time [s]")
    ax10.set_ylim([0, np.max(gantry_speed2)*1.05])

    fig5.tight_layout()
    script_dose_rate = mpld3.fig_to_html(fig5, d3_url=D3_URL, mpld3_url=MPLD3_URL)
    delete_figure([fig5])
    
    # Plot Carriage and motions
    fig6 = Figure(figsize=(10, 4))
    ax11 = fig6.add_subplot(1, 2, 1)
    ax12 = fig6.add_subplot(1, 2, 2)

    ax11.plot(np.arange(0, num_snapshots, 1), carriageA, color="red")
    ax11.set_title("Carriage A position (actual)")
    ax11.set_ylabel('[cm]')
    ax11.set_xlabel("Snapshots")

    ax12.plot(np.arange(0, num_snapshots, 1), carriageB, color="green")
    ax12.set_title("Carriage B position (actual)")
    ax12.set_ylabel('[cm]')
    ax12.set_xlabel("Snapshots")

    fig6.tight_layout()
    script_carriage = mpld3.fig_to_html(fig6, d3_url=D3_URL, mpld3_url=MPLD3_URL)
    delete_figure([fig6])

    std_threshold = 0.01
    std_A = np.std(positionsA, axis=1)
    std_B = np.std(positionsB, axis=1)
    
    rmsA_on[std_A <= std_threshold] = np.nan
    rmsB_on[std_B <= std_threshold] = np.nan
    rmsA_hold[std_A <= std_threshold] = np.nan
    rmsB_hold[std_B <= std_threshold] = np.nan

    variables = {
                "record": record,
                "patient_name": log.patient_name[2],
                "beam_id": log.beam_id,
                "num_snapshots": num_snapshots,
                "num_beamholds": log.log.num_beamholds,
                "tolerance": log.tolerance,
                "beam_on": list(log.beam_on),
                "beam_hold": list(log.beam_hold),
                "gantry": list(gantry),
                "time": log.time_line,
                "collimator": list(log.collimator),
                "x1": list(log.x1),
                "x2": list(log.x2),
                "y1": list(log.y1),
                "y2": list(log.y2),
                "MU": MU,
                "DR": DR,
                "gamma_avg": gamma_avg,
                "gamma_prcnt": gamma_prcnt,
                "gamma_tol_str": gamma_tol_str,
                "rmsA_max_on": round(np.nanmax(rmsA_on)*10, 2),
                "rmsB_max_on": round(np.nanmax(rmsB_on)*10, 2),
                "rmsA_max_hold": round(np.nanmax(rmsA_hold)*10, 2),
                "rmsB_max_hold": round(np.nanmax(rmsB_hold)*10, 2),
                "diffA_max_on": round(diffA_max_on*10, 2),
                "diffB_max_on": round(diffB_max_on*10, 2),
                "diffA_max_hold": round(diffA_max_hold*10, 2),
                "diffB_max_hold": round(diffB_max_hold*10, 2),
                "rmsA_on": np.round(10*np.nan_to_num(rmsA_on, copy=True), 2),
                "rmsB_on": np.round(10*np.nan_to_num(rmsB_on, copy=True), 2),
                "rmsA_hold": np.round(10*np.nan_to_num(rmsA_hold, copy=True), 2),
                "rmsB_hold": np.round(10*np.nan_to_num(rmsB_hold, copy=True), 2),
                "rmsA_on_avg": round(10*np.nanmean(rmsA_on), 2),
                "rmsB_on_avg": round(10*np.nanmean(rmsB_on), 2),
                "rmsA_hold_avg": round(10*np.nanmean(rmsA_hold), 2),
                "rmsB_hold_avg": round(10*np.nanmean(rmsB_hold), 2),
                "npnan": np.nan,
                "bokeh_file_css": BOKEH_FILE_CSS,
                "bokeh_file_js": BOKEH_FILE_JS,
                "bokeh_widgets_css": BOKEH_WIDGETS_CSS,
                "bokeh_widgets_js": BOKEH_WIDGETS_JS,
                "script1": script1,
                "div1": div1,
                "script2": script2,
                "script3": script3,
                "div3": div3,
                "script_MLC_rms": script_MLC_rms,
                "script_dose_rate": script_dose_rate,
                "script_carriage": script_carriage
            }
    delete_files_in_subfolders([temp_folder]) # Delete image
    gc.collect()
    return template("dynalog_analysis", variables)


@app.route(PLWEB_FOLDER + '/flatsym', method="POST")
def flatsym():
    """Read from database and return list of patients"""
    try:
        variables = Read_from_dcm_database()
    except ConnectionError:
        return template("error_template", {"error_message": "Orthanc is refusing connection.",
                                           "plweb_folder": PLWEB_FOLDER})
    return template("flatsym", variables)

@app.route(PLWEB_FOLDER + '/flatsym_calculate/<w>', method="POST")
def flatsym_calculate(w):
    calc_definition = request.forms.get('hidden_definition')
    center_definition = request.forms.get('hidden_center')
    center_x = request.forms.get('hidden_coox')
    center_y = request.forms.get('hidden_cooy')
    invert = True if request.forms.get('hidden_invert')=="true" else False

    temp_folder, file_path = RestToolbox.GetSingleDcm(ORTHANC_URL, w)
    try:
        flatsym = FlatSym(file_path)
    except Exception as e:
        return template("error_template", {"error_message": "The FlatSym module cannot calculate. "+str(e),
                                           "plweb_folder": PLWEB_FOLDER})

    # Define the center pixel where to get profiles:

    def find_field_centroid(img):
        '''taken from pylinac WL module'''
        min, max = np.percentile(img.array, [5, 99.9])
        # min, max = np.amin(img.array), np.max(img.array)

        threshold_img = img.as_binary((max - min)/2 + min)
        # clean single-pixel noise from outside field
        coords = ndimage.measurements.center_of_mass(threshold_img)
        return (int(coords[-1]), int(coords[0]))

    flatsym.crop(pixels=5)
    flatsym.check_inversion()
    if invert:
        flatsym.invert()
    flatsym.array = np.flipud(flatsym.array)
    vmax = flatsym.array.max()

    if center_definition == "Automatic":
        center_int = [int(flatsym.array.shape[1]/2), int(flatsym.array.shape[0]/2)]
        center = [0.5, 0.5]
    elif center_definition == "CAX":
        center_int = find_field_centroid(flatsym)  # Define as mechanical isocenter
        center = [int(center_int[0])/flatsym.array.shape[1], int(center_int[1])/flatsym.array.shape[0]]
    else:
        center_int = [int(center_x), int(center_y)]
        center = [int(center_x)/flatsym.array.shape[1], int(center_y)/flatsym.array.shape[0]]

    fig = Figure(figsize=(9, 9), tight_layout={"w_pad":1})
    ax = fig.add_subplot(1,1,1)
    ax.imshow(flatsym.array, cmap=matplotlib.cm.jet, interpolation="none", vmin=0.9*vmax, vmax=vmax,
              aspect="equal", origin='lower')
    ax.autoscale(tight=True)

    # Plot lines along which the profiles are calculated:
    ax.plot([0, flatsym.array.shape[1]], [center_int[1], center_int[1]], "b-", linewidth=2)
    ax.plot([center_int[0], center_int[0]], [0, flatsym.array.shape[0]] , c="darkgreen", linestyle="-", linewidth=2)
    ax.set_xlim([0, flatsym.array.shape[1]])
    ax.set_ylim([0, flatsym.array.shape[0]])

    # Get profiles
    crossplane = PylinacSingleProfile(flatsym.array[center_int[1], :])
    inplane = PylinacSingleProfile(flatsym.array[:, center_int[0]])

    # Do some filtering:
    crossplane.filter(kind='median', size=0.01)
    inplane.filter(kind='median', size=0.01)

    # Normalize profiles
    norm_val_crossplane = crossplane.values[center_int[0]]
    norm_val_inplane = inplane.values[center_int[1]]
    crossplane.normalize(norm_val=norm_val_crossplane)
    inplane.normalize(norm_val=norm_val_inplane)

    # Get index of CAX of both profiles(different than center) to be used for mirroring:
    fwhm_crossplane = crossplane.fwxm_center(interpolate=True)
    fwhm_inplane = inplane.fwxm_center(interpolate=True)

    # Plot profiles
    divider = make_axes_locatable(ax)

    ax_crossplane = divider.append_axes("bottom", size="40%", pad=0.25, sharex=ax)
    ax_crossplane.set_xlim([0, flatsym.array.shape[1]])
    ax_crossplane.set_xticks([])
    ax_crossplane.set_title("Crossplane")

    ax_inplane = divider.append_axes("right", size="40%", pad=0.25, sharey=ax)
    ax_inplane.set_ylim([0, flatsym.array.shape[0]])
    ax_inplane.set_yticks([])
    ax_inplane.set_title("Inplane")

    ax_crossplane.plot(crossplane._indices, crossplane, "b-")
    ax_crossplane.plot(2*fwhm_crossplane - crossplane._indices, crossplane, "b--")
    ax_inplane.plot(inplane, inplane._indices, c="darkgreen", linestyle="-")
    ax_inplane.plot(inplane, 2*fwhm_inplane - inplane._indices, c="darkgreen", linestyle="--")

    ax_inplane.grid(alpha=0.5)
    ax_crossplane.grid(alpha=0.5)
    mpld3.plugins.connect(fig, mpld3.plugins.MousePosition(fontsize=14, fmt=".2f"))

    script = mpld3.fig_to_html(fig, d3_url=D3_URL, mpld3_url=MPLD3_URL)

    if calc_definition == "Elekta":
        method = "elekta"
    else:
        method = "varian"

    flatsym.analyze(flatness_method=method, symmetry_method=method, vert_position=center[0], horiz_position=center[1])

    symmetry_hor = round(flatsym.symmetry['horizontal']['value'], 2)
    symmetry_vrt = round(flatsym.symmetry['vertical']['value'], 2)
    flatness_hor = round(flatsym.flatness['horizontal']['value'], 2)
    flatness_vrt = round(flatsym.flatness['vertical']['value'], 2)
    delete_files_in_subfolders([temp_folder]) # Delete image
    variables = {
                "symmetry_hor": symmetry_hor,
                "symmetry_vrt": symmetry_vrt,
                "flatness_hor": flatness_hor,
                "flatness_vrt": flatness_vrt,
                "script": script
                }
    return template("flatsym_results", variables)

@app.route(PLWEB_FOLDER + '/vvmat', method="POST")
def vvmat():
    """Read from database and return list of patients"""
    try:
        variables = Read_from_dcm_database()
    except ConnectionError:
        return template("error_template", {"error_message": "Orthanc is refusing connection.",
                                           "plweb_folder": PLWEB_FOLDER})
    return template("vvmat", variables)

@app.route(PLWEB_FOLDER + '/vvmat/<w1>/<w2>/<testtype>', method="POST")
def vvmat_calculate(w1, w2, testtype):
    tolerance = float(CONFIG['VMAT']['TOLERANCE'])
    if w1==w2:
        return template("error_template", {"error_message": "Selected images must not be equal. One image should be an open field,"\
                                           " the other DRGS or DRMLC.", "plweb_folder": PLWEB_FOLDER})
    try:
        temp_folder1, file_path1 = RestToolbox.GetSingleDcm(ORTHANC_URL, w1)
        temp_folder2, file_path2 = RestToolbox.GetSingleDcm(ORTHANC_URL, w2)
    except:
        return template("error_template", {"error_message": "Cannot read images.",
                                           "plweb_folder": PLWEB_FOLDER})

    try:
        if testtype == "DRGS":
            myvmat = DRGS(image_paths=(file_path1, file_path2))
        else:
            myvmat = DRMLC(image_paths=(file_path1, file_path2))
        myvmat.analyze(tolerance=tolerance)
    except Exception as e:
        return template("error_template", {"error_message": "Cannot analyze images. "+str(e),
                                           "plweb_folder": PLWEB_FOLDER})

    fig1 = Figure(figsize=(9.5, 5), tight_layout={"w_pad":3, "pad": 4})
    ax1 = fig1.add_subplot(1,2,1)
    ax2 = fig1.add_subplot(1,2,2)

    ax1.imshow(myvmat.open_image.array, cmap=matplotlib.cm.jet, interpolation="none", aspect="equal", origin='upper')
    ax1.set_title('Open')
    ax1.axis('off')
    myvmat._draw_segments(ax1)
    ax2.imshow(myvmat.dmlc_image, cmap=matplotlib.cm.jet, interpolation="none", aspect="equal", origin='upper')
    ax2.set_title('DMLC')
    ax2.axis('off')
    myvmat._draw_segments(ax2)

    script1 = mpld3.fig_to_html(fig1, d3_url=D3_URL, mpld3_url=MPLD3_URL)

    fig2 = Figure(figsize=(5, 4), tight_layout={"w_pad":1, "pad": 1})
    ax3 = fig2.add_subplot(1,1,1)
    dmlc_prof, open_prof = myvmat._median_profiles((myvmat.dmlc_image, myvmat.open_image))
    # Taken from pylinac:
    ax3.plot(dmlc_prof.values, label='DMLC')
    ax3.plot(open_prof.values, label='Open')
    ax3.autoscale(axis='x', tight=True)
    ax3.legend(loc=8, fontsize='large')
    ax3.grid()
    script2 = mpld3.fig_to_html(fig2, d3_url=D3_URL, mpld3_url=MPLD3_URL)
    
    # Collect data
    Rcorr = [roi.r_corr for roi in myvmat.segments]
    diff_corr = myvmat.r_devs
    diff_avg_abs = myvmat.avg_abs_r_deviation
    segment_passed = [roi.passed for roi in myvmat.segments]
    test_passed = myvmat.passed
    
    variables = {
                "script1": script1,
                "script2": script2,
                "Rcorr": Rcorr,
                "diff_corr": diff_corr,
                "diff_avg_abs": diff_avg_abs,
                "segment_passed": segment_passed,
                "test_passed": test_passed
                }
    delete_files_in_subfolders([temp_folder1, temp_folder2]) # Delete image
    return template("vmat_results", variables)


@app.route(PLWEB_FOLDER + '/fieldsize', method="POST")
def fieldsize():
    """Read from database and return list of patients"""
    try:
        variables = Read_from_dcm_database()
    except ConnectionError:
        return template("error_template", {"error_message": "Orthanc is refusing connection.",
                                           "plweb_folder": PLWEB_FOLDER})
    variables["LEAF_TYPE"] = LEAF_TYPE
    return template("fieldsize", variables)


@app.route(PLWEB_FOLDER + '/fieldsize/<w1>/<w2>', method="POST")
def fieldsize_calculate(w1, w2):
    mlc_type = request.forms.get('hidden_mlctype')
    iso_method = request.forms.get('hidden_setcenter')
    mlc_direction = request.forms.get('hidden_mlcdirection')
    mlc_points = request.forms.get('hidden_mlcpoints')
    jaw_points = request.forms.get('hidden_jawpoints')
    mmpd = float(request.forms.get('hidden_mmpd'))
    cax_x = request.forms.get('hidden_cax_x')
    cax_y = request.forms.get('hidden_cax_y')
    clipbox = float(request.forms.get('hidden_clipbox'))*10.0
    invert = True if request.forms.get('hidden_invert')=="true" else False

    try:
        temp_folder1, file_path1 = RestToolbox.GetSingleDcm(ORTHANC_URL, w1)
        temp_folder2, file_path2 = RestToolbox.GetSingleDcm(ORTHANC_URL, w2)
    except:
        return template("error_template", {"error_message": "Cannot read images.",
                                           "plweb_folder": PLWEB_FOLDER})
    
    # Load first image
    try:
        img1 = pylinac_image.DicomImage(file_path1)
        # Here we force pixels to background outside of box:
        if clipbox != 0:
            try:
                img1.check_inversion_by_histogram(percentiles=[4, 50, 96]) # Check inversion otherwise this might not work
                clip_around_image(img1, clipbox)
            except Exception as e:
                return template("error_template", {"error_message": "Unable to apply clipbox. "+str(e), "plweb_folder": PLWEB_FOLDER})
        else:
            img1.remove_edges(pixels=2)
        if invert:
            img1.invert()
        else:
            img1.check_inversion()
        img1.flipud()
    except:
        return template("error_template", {"error_message": "Cannot read image.",
                                           "plweb_folder": PLWEB_FOLDER})
    
    # FIRST IMAGE (to get isocenter):
    if iso_method == "Manual":
        center = (float(cax_x), float(cax_y))

    elif iso_method == "Plate":
        img1_copy = copy.copy(img1) # Copy because you will need the original later

        reg = MLC_fieldsize._get_canny_regions(img1)
        size = [r.area for r in reg]
        sort = np.argsort(size)[::-1]
        # Get the region with the right area:
        for s in range(0, len(reg), 1):
            if 0.9 < (reg[sort[s]].image.size/(img1.dpmm*img1.dpmm) / 31420) < 1.1:
                break
        max_area_index = sort[s]
        bb_box = reg[max_area_index].bbox  # (min_row, min_col, max_row, max_col)
        margin = 15 # pixels

        img1.array = img1.array[bb_box[0]+margin:bb_box[2]-margin, bb_box[1]+margin:bb_box[3]-margin]
        center = MLC_fieldsize._find_plate_center(img1)  # This is chosen as the mechanical center!!!

        filter_size = 0.05  # Don't go higher!
        sample_length = 15 # mm to both sides from the center!
        sample_box = 5  # Half the number of lines per averaged profile minus one(must be odd number)
        hor_margin = 50
        vrt_margin = 30

        # Vertical profiles (two regions):
        samples_vertical = np.rint(center[0]-sample_length*img1.dpmm + np.arange(1, 2*sample_length*img1.dpmm+1, 2*sample_box+1)).astype(int)
        up_end = np.rint(center[1]-vrt_margin*img1.dpmm).astype(int)
        down_start = np.rint(center[1] + vrt_margin*img1.dpmm).astype(int)
        width_vert_up, fwhm_center_vert_up, width_vert_down, fwhm_center_vert_down = MLC_fieldsize.plate_ud_width(img1, samples_vertical, filter_size, up_end, down_start, sample_box)

        # Horizontal profiles (two regions):
        samples_horizontal = np.rint(center[1]-sample_length*img1.dpmm + np.arange(1, 2*sample_length*img1.dpmm+1, 2*sample_box+1)).astype(int)
        left_end = np.rint(center[0]-hor_margin*img1.dpmm).astype(int)
        right_start = np.rint(center[0] + hor_margin*img1.dpmm).astype(int)
        width_hor_left, fwhm_center_hor_left, width_hor_right, fwhm_center_hor_right = MLC_fieldsize.plate_lr_width(img1, samples_horizontal, filter_size, left_end, right_start, sample_box)

        vrt_px = (np.average(width_vert_up)+np.average(width_vert_down))/2
        hor_px = (np.average(width_hor_left)+np.average(width_hor_right))/2
        center_fwhm_x = (np.average(fwhm_center_hor_left) + right_start + np.average(fwhm_center_hor_right))/2
        center_fwhm_y = (np.average(fwhm_center_vert_up) + down_start + np.average(fwhm_center_vert_down))/2

        # Redefine center to the original image:
        center_plate = [center_fwhm_x, center_fwhm_y]
        center = (bb_box[1]+margin+center_plate[0], bb_box[0]+margin+center_plate[1])

    elif iso_method == "BB":
        center, bb_box = MLC_fieldsize._find_field_centroid(img1)
        bb_coord, bw_bb_im = MLC_fieldsize._find_bb(img1, bb_box)  # Define as mechanical isocenter
        center = (bb_coord[0], bb_coord[1])

    elif iso_method == "CAX":
        center, bb_box = MLC_fieldsize._find_field_centroid(img1)  # Define as mechanical isocenter
    
    # Now calculate field size from second image
    # Calculate mlc and jaw positions
    try:
        img2 = pylinac_image.DicomImage(file_path2)
        if clipbox != 0:
            try:
                img2.check_inversion_by_histogram(percentiles=[4, 50, 96]) # Check inversion otherwise this might not work
                clip_around_image(img2, clipbox)
            except Exception as e:
                return template("error_template", {"error_message": "Unable to apply clipbox. "+str(e), "plweb_folder": PLWEB_FOLDER})
        else:
            img2.remove_edges(pixels=2)
        if invert:
            img2.invert()
        else:
            img2.check_inversion()
        img2.flipud()
    except:
        return template("error_template", {"error_message": "Cannot read image.",
                                           "plweb_folder": PLWEB_FOLDER})

    # Define pixel size. Use either that from the dcm file or calculate it via Elekta plate:
    if iso_method == "Plate":
        dpmm = (vrt_px/20.0 + hor_px/20.0)/2
    else:
        if mmpd != 0:
            dpmm = 1.0/mmpd
        else:
            dpmm = img2.dpmm

    center_rad, bb_box2 = MLC_fieldsize._find_field_centroid(img2)  # Rad center not used in calculations!
    marg_bb = 10  # This additional margin is included in the caluclation of bb_box2. Subtract it when needed!

    nr_leaf_sample_points = int(mlc_points)
    nr_jaw_sample_points = int(jaw_points)
    leaf_scaling = dpmm
    mlc_points = MLC_fieldsize.sample_points_mlc(nr_leaf_sample_points, leaf_type=mlc_type)
    # Sample mlc-s according o mlc_points, sample jaws equidistanly with center at rad center (derived from bb_box2)

    if mlc_direction == "X":
        # MLCS are horizontal
        center_pixel_mlc = center[0]
        center_pixel_jaws = center[1]
        mlc_pixels = MLC_fieldsize.points_to_pixels_mlc(leaf_scaling, mlc_points, bb_box2[0]+marg_bb, bb_box2[1]-marg_bb, center_pixel_jaws)
        jaw_pixels = MLC_fieldsize.sample_pixels_jaws(nr_jaw_sample_points, bb_box2[2]+marg_bb, bb_box2[3]-marg_bb)
    else:
        # MLCs are vertical
        center_pixel_mlc = center[1]
        center_pixel_jaws = center[0]
        mlc_pixels = MLC_fieldsize.points_to_pixels_mlc(leaf_scaling, mlc_points, bb_box2[2]+marg_bb, bb_box2[3]-marg_bb, center_pixel_jaws)
        jaw_pixels = MLC_fieldsize.sample_pixels_jaws(nr_jaw_sample_points, bb_box2[0]+marg_bb, bb_box2[1]-marg_bb)

    penL, penR = MLC_fieldsize.calculate_penumbra_pixels_mlc(img2, mlc_pixels, mlc_direction)
    penL_abs = np.abs(penL-center_pixel_mlc)
    penL_abs_avg = np.average(penL_abs, axis=1)
    penR_abs = np.abs(penR-center_pixel_mlc)
    penR_abs_avg = np.average(penR_abs, axis=1)
    widths_mlc = np.abs(penL-penR)
    widths_mlc_avg = np.average(widths_mlc, axis=1)


    penL_jaw, penR_jaw = MLC_fieldsize.calculate_penumbra_pixels_jaws(img2, jaw_pixels, mlc_direction)
    penL_jaw_abs = np.abs(penL_jaw-center_pixel_jaws)
    penR_jaw_abs = np.abs(penR_jaw-center_pixel_jaws)
    widths_jaw = np.abs(penL_jaw-penR_jaw)
    
    # Alternative definition of rad center (not as a mass center)
    #center_mlc = np.average((penL[1:-1,:]+penR[1:-1,:])/2)
    #center_jaw = np.average((penL_jaw[1:-1] + penR_jaw[1:-1])/2)
    #if mlc_direction == "X":
    #    center_fwhm_rad = [center_mlc, center_jaw]
    #elif mlc_direction == "Y":
    #    center_fwhm_rad = [center_jaw, center_mlc]

    # Skewness of the rectangle (a measure of collimator angle):
    # linear regression of mlc/jaw points (except the first and the last) y=mx+c
    first_leaf = np.rint(np.searchsorted((mlc_pixels-center_pixel_jaws).flatten(), 0)/mlc_pixels.shape[1]).astype(int)
    leaf_numbers = np.hstack((-np.arange(1, first_leaf+1, 1)[::-1], np.arange(1, mlc_pixels.shape[0]-first_leaf+1, 1)))

    temp_mlc = np.vstack([(mlc_pixels[1:-1,:].flatten()-center_pixel_mlc)/dpmm, np.ones(len(mlc_pixels[1:-1,:].flatten()))]).T
    m_mlcL, c_mlcL = np.linalg.lstsq(temp_mlc, penL_abs[1:-1,:].flatten()/dpmm, rcond=None)[0]
    m_mlcR, c_mlcR = np.linalg.lstsq(temp_mlc, penR_abs[1:-1,:].flatten()/dpmm, rcond=None)[0]
    temp_jaws = np.vstack([(jaw_pixels[1:-1]-center_pixel_jaws)/dpmm, np.ones(len(jaw_pixels[1:-1]))]).T
    m_jawL, c_jawL = np.linalg.lstsq(temp_jaws, penL_jaw_abs[1:-1]/dpmm, rcond=None)[0]
    m_jawR, c_jawR = np.linalg.lstsq(temp_jaws, penR_jaw_abs[1:-1]/dpmm, rcond=None)[0]
    
    # Not do some heavy plotting
    size = 7
    fig1 = Figure(figsize=(size, size), tight_layout={"w_pad":1, "pad": 1})
    ax1 = fig1.add_subplot(1,1,1)

    if iso_method == "BB":
        ax1.imshow(img1.array, cmap=matplotlib.cm.Greys, interpolation="none", origin="lower", extent=[0, img1.shape[1], 0, img1.shape[0]])
        ax1.plot(center[0], center[1],  'b+', markersize=24, markeredgewidth=3, zorder=2)
        border = np.average(np.percentile(bw_bb_im, [5, 99.9]))
        ax1.contour(bw_bb_im, levels=[border], colors = ["red"])  # BB
        ax1.set_ylim(0, img1.shape[0])
        ax1.set_xlim(0, img1.shape[1])
        ax1.autoscale(enable=False)

    if iso_method == "Plate":
        ax1.imshow(img1_copy.array, cmap=matplotlib.cm.prism_r, interpolation="none", origin="lower", extent=[0, img1_copy.shape[1], 0, img1_copy.shape[0]])
        ax1.plot(center[0], center[1],  'b+', markersize=24, markeredgewidth=3, zorder=2)
        ax1.plot([left_end+center[0]-center_plate[0]]*len(samples_horizontal), samples_horizontal+center[1]-center_plate[1],'wo', markersize=3, markeredgewidth=0, zorder=2 )
        ax1.plot([right_start+center[0]-center_plate[0]]*len(samples_horizontal), samples_horizontal+center[1]-center_plate[1],'wo', markersize=3, markeredgewidth=0, zorder=2 )
        ax1.plot(samples_vertical+center[0]-center_plate[0], [up_end+center[1]-center_plate[1]]*len(samples_vertical),'wo', markersize=3, markeredgewidth=0, zorder=2 )
        ax1.plot(samples_vertical+center[0]-center_plate[0], [down_start+center[1]-center_plate[1]]*len(samples_vertical), 'wo', markersize=3, markeredgewidth=0, zorder=2 )
        ax1.set_ylim(bb_box[0]+margin, bb_box[2]-margin)
        ax1.set_xlim(bb_box[1]+margin, bb_box[3]-margin)
        ax1.autoscale(enable=False)

    if iso_method == "Manual" or iso_method == "CAX":
        ax1.imshow(img1.array, cmap=matplotlib.cm.prism_r, interpolation="none", origin="lower", extent=[0, img1.shape[1], 0, img1.shape[0]])
        ax1.plot(center[0], center[1],  'b+', markersize=24, markeredgewidth=3, zorder=2)
        ax1.set_ylim(0, img1.shape[0])
        ax1.set_xlim(0, img1.shape[1])
        ax1.autoscale(enable=False)

    mpld3.plugins.connect(fig1, mpld3.plugins.MousePosition(fontsize=14, fmt=".1f"))
    script1 = mpld3.fig_to_html(fig1, d3_url=D3_URL, mpld3_url=MPLD3_URL)
    
    # Second plot
    fig2 = Figure(figsize=(size, size), tight_layout={"w_pad":1, "pad": 1})
    ax2 = fig2.add_subplot(1,1,1)
    ax2.imshow(img2.array, cmap=matplotlib.cm.Greys, interpolation="none", origin="lower", extent=[0, img2.shape[1], 0, img2.shape[0]])
    ax2.plot(center[0], center[1],  'b+', markersize=24, markeredgewidth=3)
    level = np.average(np.percentile(img2.array, [5, 99.9]))
    ax2.contour(img2.array, levels=[level], colors = ["magenta"], linewidths=1, alpha=0.7, zorder=1)
    ax2.plot(center_rad[0], center_rad[1],  'm+', markersize=24, markeredgewidth=3, zorder=2)
    ax2.plot([None],[None], "b+", ms=15, mew=3, label="Mechanical")
    ax2.plot([None],[None], "m+", ms=15, mew=3, label="Radiation")
    ax2.plot([0, img2.shape[1]], [center[1], center[1]], "b--", alpha=0.5)
    ax2.plot([center[0], center[0]], [0, img2.shape[0]], "b--", alpha=0.5)
    ax2.legend(framealpha=0, numpoints=1, ncol=2, loc='lower left', fontsize=8)

    m1s = 5
    ms2 = 6
    if mlc_direction == "X":
        m1 = ax2.plot(penL.flatten(), mlc_pixels.flatten(), 'ro', markersize=m1s, markeredgewidth=0, zorder=2)
        m2 = ax2.plot(penR.flatten(), mlc_pixels.flatten(), 'bo', markersize=m1s, markeredgewidth=0, zorder=2)
        j1 = ax2.plot(jaw_pixels, penL_jaw, 'go', markersize=ms2, markeredgewidth=0, zorder=2)
        j2 = ax2.plot(jaw_pixels, penR_jaw, 'yo', markersize=ms2, markeredgewidth=0, zorder=2)
        #ax2.plot(np.average((penL+penR)/2), np.average((penL_jaw+penR_jaw)/2), 'y+', markersize=24, markeredgewidth=3, zorder=2)
    else:
        m1 = ax2.plot(mlc_pixels.flatten(), penL.flatten(), 'ro', markersize=m1s, markeredgewidth=0, zorder=2)
        m2 = ax2.plot(mlc_pixels.flatten(), penR.flatten(), 'bo', markersize=m1s, markeredgewidth=0, zorder=2)
        j1 = ax2.plot(penL_jaw, jaw_pixels, 'go', markersize=ms2, markeredgewidth=0, zorder=2)
        j2 = ax2.plot(penR_jaw, jaw_pixels, 'yo', markersize=ms2, markeredgewidth=0, zorder=2)
        #ax2.plot(np.average((penL_jaw+penR_jaw)/2), np.average((penL+penR)/2), 'y+', markersize=24, markeredgewidth=3, zorder=2)

    labels_m1 = ["Distance from center = {:04.2f} mm, width = {:04.2f} mm".format(penL_abs.flatten()[k]/dpmm, widths_mlc.flatten()[k]/dpmm) for k in range(0, len(penL_abs.flatten()), 1)]
    labels_m2 = ["Distance from center = {:04.2f} mm, width = {:04.2f} mm".format(penR_abs.flatten()[k]/dpmm, widths_mlc.flatten()[k]/dpmm) for k in range(0, len(penR_abs.flatten()), 1)]
    labels_j1 = ["Distance from center = {:04.2f} mm, width = {:04.2f} mm".format(penL_jaw_abs[k]/dpmm, widths_jaw[k]/dpmm) for k in range(0, len(penL_jaw_abs), 1)]
    labels_j2 = ["Distance from center = {:04.2f} mm, width = {:04.2f} mm".format(penR_jaw_abs[k]/dpmm, widths_jaw[k]/dpmm) for k in range(0, len(penR_jaw_abs), 1)]
    ttip1 = mpld3.plugins.PointLabelTooltip(m1[0], labels_m1, location='top left')
    ttip2 = mpld3.plugins.PointLabelTooltip(m2[0], labels_m2, location='top left')
    ttip3 = mpld3.plugins.PointLabelTooltip(j1[0], labels_j1, location='top left')
    ttip4 = mpld3.plugins.PointLabelTooltip(j2[0], labels_j2, location='top left')

    margin_imshow = 35
    ax2.set_ylim(bb_box2[0]-margin_imshow, bb_box2[1]+margin_imshow)
    ax2.set_xlim(bb_box2[2]-margin_imshow, bb_box2[3]+margin_imshow)
    ax2.autoscale(enable=False)

    mpld3.plugins.connect(fig2, mpld3.plugins.MousePosition(fontsize=14, fmt=".1f"))

    mpld3.plugins.connect(fig2, ttip1)
    mpld3.plugins.connect(fig2, ttip2)
    mpld3.plugins.connect(fig2, ttip3)
    mpld3.plugins.connect(fig2, ttip4)

    script2 = mpld3.fig_to_html(fig2, d3_url=D3_URL, mpld3_url=MPLD3_URL)

    # Third plot
    fig3 = Figure(figsize=(8.5, 7), tight_layout={"w_pad":1, "pad": 1})
    ax3 = fig3.add_subplot(3,1,1)
    ax4 = fig3.add_subplot(3,1,2)
    ax5 = fig3.add_subplot(3,1,3)

    ax3.plot(np.arange(0, len(leaf_numbers), 1), penR_abs_avg/dpmm, "bo-", linewidth=0.8)
    ax3.set_xticks(np.arange(0, len(leaf_numbers), 1))
    ax3.set_xticklabels([])
    ax3.grid(linestyle='dotted', color="gray")
    ax3.set_title("Right leaf distance from center [mm]")
    ax3.margins(0.05)

    ax4.plot(np.arange(0, len(leaf_numbers), 1),-penL_abs_avg/dpmm, "ro-", linewidth=0.8)
    ax4.set_xticks(np.arange(0, len(leaf_numbers), 1))
    ax4.grid(linestyle='dotted', color="gray")
    ax4.set_xticklabels([])
    ax4.set_title("Left leaf distance from center [mm]")
    ax4.margins(0.05)

    ax5.plot(np.arange(0, len(leaf_numbers), 1),widths_mlc_avg/dpmm, "ko-", linewidth=0.8)
    ax5.set_xticks(np.arange(0, len(leaf_numbers), 1))
    ax5.set_xticklabels(leaf_numbers)
    ax5.grid(linestyle='dotted', color="gray")
    ax5.set_xlabel("Leaf index")
    ax5.set_title("Distance between leaves [mm]")
    ax5.margins(0.05)

    script3 = mpld3.fig_to_html(fig3, d3_url=D3_URL, mpld3_url=MPLD3_URL)

    # Fourth plot
    fig4 = Figure(figsize=(8.5, 7), tight_layout={"w_pad":1, "pad": 1})
    ax6 = fig4.add_subplot(3,1,1)
    ax7 = fig4.add_subplot(3,1,2)
    ax8 = fig4.add_subplot(3,1,3)

    ax6.plot(np.arange(0, len(penR_jaw_abs), 1), penR_jaw_abs/dpmm, "yo-", linewidth=0.8)
    ax6.set_xticks(np.arange(0, len(penR_jaw_abs), 1))
    ax6.set_xticklabels([])
    ax6.grid(linestyle='dotted', color="gray")
    ax6.set_title("Right jaw distance from center [mm]")
    ax6.margins(0.05)

    ax7.plot(np.arange(0, len(penL_jaw_abs), 1),-penL_jaw_abs/dpmm, "go-", linewidth=0.8)
    ax7.set_xticks(np.arange(0, len(penL_jaw_abs), 1))
    ax7.grid(linestyle='dotted', color="gray")
    ax7.set_xticklabels([])
    ax7.set_title("Left jaw distance from center [mm]")
    ax7.margins(0.05)

    ax8.plot(np.arange(0, len(widths_jaw), 1), widths_jaw/dpmm, "ko-", linewidth=0.8)
    ax8.set_xticks(np.arange(0, len(widths_jaw), 1))
    ax8.set_xticklabels(np.arange(1, len(widths_jaw)+1, 1))
    ax8.grid(linestyle='dotted', color="gray")
    ax8.set_xlabel("Jaw sample point")
    ax8.set_title("Distance between jaws [mm]")
    ax8.margins(0.05)

    script4 = mpld3.fig_to_html(fig4, d3_url=D3_URL, mpld3_url=MPLD3_URL)

    variables = {
                 "script1": script1,
                 "script2": script2,
                 "script3": script3,
                 "script4": script4,
                 "MLC_position_L": penL_abs_avg/dpmm,
                 "MLC_position_R": penR_abs_avg/dpmm,
                 "MLC_width": widths_mlc_avg/dpmm,
                 "jaw_position_L": penL_jaw_abs/dpmm,
                 "jaw_position_R": penR_jaw_abs/dpmm,
                 "jaw_width": widths_jaw/dpmm,
                 "leaf_numbers": leaf_numbers,
                 "angle_mlc_L": np.arctan(m_mlcL)*180/PI,
                 "angle_mlc_R": np.arctan(m_mlcR)*180/PI,
                 "angle_jaw_L": np.arctan(m_jawL)*180/PI,
                 "angle_jaw_R": np.arctan(m_jawR)*180/PI,
                 "MLC_size_L": np.average(penL_abs_avg[1:-1]/dpmm),
                 "MLC_size_R": np.average(penR_abs_avg[1:-1]/dpmm),
                 "MLC_size_full": np.average(widths_mlc_avg[1:-1]/dpmm),
                 "jaw_size_L": np.average(penL_jaw_abs[1:-1]/dpmm),
                 "jaw_size_R": np.average(penR_jaw_abs[1:-1]/dpmm),
                 "jaw_size_full": np.average(widths_jaw[1:-1]/dpmm),
                 "center_offset_x": (center_rad[0]-center[0])/dpmm,
                 "center_offset_y": (center_rad[1]-center[1])/dpmm,
                 "dpmm": 1/dpmm,
                 "center": center,
                 "center_rad": center_rad,
                 "qaserver_folder": PLWEB_FOLDER
                 }
    delete_files_in_subfolders([temp_folder1, temp_folder2]) # Delete image
    return template("fieldsize_results", variables)


@app.route(PLWEB_FOLDER + '/image_review', method="POST")
def image_review():
    """Read from database and return list of patients"""
    try:
        variables = Read_from_dcm_database()
    except ConnectionError:
        return template("error_template", {"error_message": "Orthanc is refusing connection.",
                                           "plweb_folder": PLWEB_FOLDER})
    return template("image_review", variables)

@app.route(PLWEB_FOLDER + '/image_review_calculate/<w>', method="POST")
def image_review_calculate(w):
    '''Function that returns the profiles of the image '''
    # w is the image
    converthu = True if request.forms.get('hidden_converthu')=="true" else False
    invert = True if request.forms.get('hidden_invert')=="true" else False
    temp_folder, file_path = RestToolbox.GetSingleDcm(ORTHANC_URL, w)
    try:
        img = pylinac_image.DicomImage(file_path)
        if invert:
            img.invert()
        if converthu:  # Convert back to pixel values if needed.
            img.array = (img.array - int(img.metadata.RescaleIntercept)) / int(img.metadata.RescaleSlope)
        img_array = np.flipud(img.array)
    except:
        return template("error_template", {"error_message": "Cannot read image.",
                                           "plweb_folder": PLWEB_FOLDER})
    size_x = img_array.shape[1]
    size_y = img_array.shape[0]
    img_min = np.min(img_array)
    img_max = np.max(img_array)

    x1 = np.arange(0, size_x, 1).tolist()
    y1 = img_array[int(size_y//2), :].tolist()
    y2 = np.arange(0, size_y, 1).tolist()
    x2 = img_array[:, int(size_x//2)].tolist()
    
    source = ColumnDataSource(data=dict(x1=x1, y1=y1))
    source2 = ColumnDataSource(data=dict(x2=x2, y2=y2))
    
    callback = CustomJS(args=dict(source=source, source2=source2), code="""
        var geometry = cb_data['geometry'];
        var x_data = parseInt(geometry.x); // current mouse x position in plot coordinates
        var y_data = parseInt(geometry.y); // current mouse y position in plot coordinates
        var data = source.data;
        var data2 = source2.data;
        var array = """+json.dumps(img_array.tolist())+""";
        data['y1'] = array[y_data];
        var column = [];
        for(var i=0; i < array.length; i++){
          column.push(array[i][x_data]);
        }
        data2['x2'] = column;
        source.change.emit();
        source2.change.emit();
    """)

    # Add callback for calculating average value inside Rectangular ROI
    x3 = np.arange(0, size_x, 1).tolist()
    y3 = np.arange(0, size_y, 1).tolist()
    source3 = ColumnDataSource(data=dict(x3=x3, y3=y3))
    source4 = ColumnDataSource(data=dict(x4=[], y4=[], width4=[], height4=[]))
    # Add table for mean and std
    source5 = ColumnDataSource(dict(
                                mean=[],
                                median=[],
                                std=[],
                                minn=[],
                                maxx=[]
                                ))
    hfmt = NumberFormatter(format="0.00")
    columns = [TableColumn(field="mean", title="mean", formatter=hfmt),
               TableColumn(field="median", title="median", formatter=hfmt),
               TableColumn(field="std", title="std", formatter=hfmt),
               TableColumn(field="minn", title="min", formatter=hfmt),
               TableColumn(field="maxx", title="max", formatter=hfmt)]

    callback2 = CustomJS(args=dict(source3=source3, source4=source4, source5=source5), code="""
        var geometry = cb_data['geometry'];
        var data3 = source3.data;
        var data4 = source4.data;
        var data5 = source5.data;

        // Get data
        var x0 = parseInt(geometry['x0']);
        var x1 = parseInt(geometry['x1']);
        var y0 = parseInt(geometry['y0']);
        var y1 = parseInt(geometry['y1']);

        // calculate Rect attributes
        var width = x1 - x0;
        var height = y1 - y0;
        var x = x0 + width/2;
        var y = y0 + height/2;

        // update data source with new Rect attributes
        data4['x4'] = [x];
        data4['y4'] = [y];
        data4['width4'] = [width];
        data4['height4'] = [height];

        // Get average value inside ROI
        var array = """+json.dumps(img_array.tolist())+""";

        length_x = array[0].length;
        length_y = array.length;

        if ((x0<=length_x && x0>=0) && (x1<=length_x && x1>=0) && (y0<=length_y && y0>=0) && (y1<=length_y && y1>=0)){
            avg_ROI = [];

            for (var i=y0; i< y1; i++){
                for (var j=x0; j<x1; j++){
                    avg_ROI.push(array[i][j]);
                }
            }
    
            if (avg_ROI == undefined || avg_ROI.length==0){
                data5["mean"] = [0];
                data5["median"] = [0];
                data5["std"] = [0];
                }
            else{
                data5["mean"] = [math.mean(avg_ROI)];
                data5["median"] = [math.median(avg_ROI)];
                data5["std"] = [math.std(avg_ROI, 'uncorrected')];
                data5["maxx"] = [math.max(avg_ROI)];
                data5["minn"] = [math.min(avg_ROI)];
                }
            source4.change.emit();
            source5.change.emit();
            }
    """)

    # Define matplotlib palette and make it possible to be used dynamically.
    colormap = matplotlib.cm.Greys #chose any matplotlib colormap here
    bokehpalette = [matplotlib.colors.rgb2hex(m) for m in colormap(np.arange(colormap.N)[::-1])]  # Reversed direction of colormap
    mapper = LinearColorMapper(palette=bokehpalette, low=np.min(img_array), high=np.max(img_array))

    callback3 = CustomJS(args=dict(mapper=mapper), code="""
           mapper.palette = """+json.dumps(bokehpalette)+""";
           mapper.low = cb_obj.value[0];
           mapper.high = cb_obj.value[1];
           //mapper.change.emit();
    """)

    range_slider = RangeSlider(start=np.min(img_array), end=np.max(img_array), value=(np.min(img_array),np.max(img_array)), step=10, title="Level")
    range_slider.callback=callback3

    plot_width = 500
    plot_height = int((plot_width-20)*size_y/size_x)
    
    fig = figure(x_range=[0, size_x], y_range=[0, size_y],
                 plot_width=plot_width, plot_height=plot_height, title="",
                 toolbar_location="right",
                 tools=["crosshair, wheel_zoom, pan, reset"])
    fig_r = figure(x_range=[img_min, img_max], y_range=fig.y_range,
                 plot_width=250, plot_height=plot_height, title="",
                 toolbar_location="right",
                 tools=[])
    fig_b = figure(x_range=fig.x_range, y_range=[img_min, img_max],
                 plot_width=plot_width, plot_height=200, title="",
                 toolbar_location="right",
                 tools=[])

    fig.image([img_array], x=0, y=0, dw=size_x, dh=size_y, color_mapper=mapper)

    fig_b.line(x='x1', y='y1', source=source)
    fig_r.line(x='x2', y='y2', source=source2)
    fig.rect(x='x4', y='y4', width='width4', height='height4', source=source4, fill_alpha=0.3, fill_color='#009933')

    fig.add_tools(HoverTool(tooltips=None, callback=callback))
    fig.add_tools(BoxSelectTool(callback=callback2))
    table = DataTable(source=source5, columns=columns, editable=False, height=50, width = 480)
    
    grid = gridplot([[table, range_slider],  [fig, fig_r], [fig_b, None]])
 
    script, div = components(grid)
    variables = {"script": script,
                 "div": div,
                 "bokeh_file_css": BOKEH_FILE_CSS,
                 "bokeh_file_js": BOKEH_FILE_JS,
                 "bokeh_widgets_js": BOKEH_WIDGETS_JS,
                 "bokeh_tables_js": BOKEH_TABLES_JS
                 }
    #gc.collect()

    delete_files_in_subfolders([temp_folder]) # Delete image
    return template("image_review_results", variables)


if __name__ == '__main__':
    bottle_run(app=app, server="paste", host=IP_ADDRESS, port=PORT, reloader=True, debug=False)

# Added this to mpld3 _display.py (line 138 class NumpyEncoder):
    #elif isinstance(obj, (numpy.ndarray,)):
    #        return obj.tolist()