import numpy as np
from pylinac import Dynalog
import os

def get_dataset_from_dlg(file, exclude_beam_off):

    if not os.path.isfile(file):
        raise ValueError("File "+file+" does not exist.")
    try:
        plg = Dynalog(file, exclude_beam_off=exclude_beam_off)
    except:
        raise ValueError("Cannot read dynalog file. Unknown problem.")

    return plg  # Read dlg file


class VarianDynalog(object):

    # input file path (must be .dlg or .DLG) of your dynalog
    def __init__(self, ds):

        self.log = ds

        if ds.header.plan_filename:
            if len(ds.header.plan_filename) == 2:
                self.plan_UID, self.beam_id = ds.header.plan_filename
            else:
                self.plan_UID = ds.header.plan_filename[0]
                self.beam_id = ds.header.plan_filename[0]
        else:
            self.plan_UID = "NA"
            self.beam_id = "NA"

        if ds.header.patient_name:
            self.patient_name = ds.header.patient_name
        else:
            self.patient_name = "NA"

        if ds.header.tolerance:
            self.tolerance = ds.header.tolerance
        else:
            self.tolerance = "NA"

        # Scale (important for zero of gantry/collimator angle)
        IEC = ds.header.clinac_scale
        if IEC == 0:
            self.scale = "Varian IEC"
        elif IEC == 1:
            self.scale = "IEC 60601-2-1"  # G 180  == 0

        self.number_of_leaves = int(ds.header.num_mlc_leaves)
        self.number_of_snapshots = int(ds.axis_data.num_snapshots)  # All snapshots!

        # Time line in seconds:
        self.time_line = np.arange(0, self.number_of_snapshots, 1)*0.05

        # Convert to Varian IEC
        gantry = ds.axis_data.gantry.actual
        collimator = ds.axis_data.collimator.actual
        if self.scale == "IEC 60601-2-1":
            for g in np.arange(0, self.number_of_snapshots, 1):
                if 180 - gantry[g] >= 0:
                    gantry[g] = 180 - gantry[g]
                else:
                    gantry[g] = 540 - gantry[g]

                if 180 - collimator[g] >= 0:
                    collimator[g] = 180 - collimator[g]
                else:
                    collimator[g] = 540 - collimator[g]
        self.gantry = gantry
        self.collimator = collimator

        mu = ds.axis_data.mu.actual
        self.mu = mu - mu[0]
        mu2 = ds.axis_data.mu.expected
        self.mu_expected = mu2 - mu2[0]

        self.beam_on = ds.axis_data.beam_on.actual
        self.beam_hold = ds.axis_data.beam_hold.actual
        self.num_beamholds = ds.num_beamholds

        self.x1 = -ds.axis_data.jaws.x1.actual
        self.x2 = ds.axis_data.jaws.x2.actual
        self.y1 = -ds.axis_data.jaws.y1.actual
        self.y2 = ds.axis_data.jaws.y2.actual

        # Read MLC positions:
        bankA_actual = []
        bankB_actual = []
        bankA_expected = []
        bankB_expected = []

        MLC = ds.axis_data.mlc.leaf_axes
        self.MLC_number = int(len(MLC))
        for k in np.arange(1, int(self.MLC_number/2+1), 1):
            bankA_actual.append(MLC[k].actual)
            bankB_actual.append(-MLC[self.MLC_number/2+k].actual)
            bankA_expected.append(MLC[k].expected)
            bankB_expected.append(-MLC[self.MLC_number/2+k].expected)

        self.bankA_actual = bankA_actual
        self.bankB_actual = bankB_actual
        self.bankA_expected = bankA_expected
        self.bankB_expected = bankB_expected

        self.carriageA_actual = ds.axis_data.carriage_A.actual
        self.carriageB_actual = ds.axis_data.carriage_B.actual

    def analyze_dynalog(self, DTA, DD, threshold, resolution):

        mlc_num = self.number_of_leaves
        num_snap = self.number_of_snapshots
        self.log.fluence.gamma.calc_map(doseTA=DD, distTA=DTA, threshold=threshold, resolution=resolution)
        gamma = [self.log.fluence.gamma.avg_gamma, self.log.fluence.gamma.pass_prcnt]
        gamma = [gamma[0] if np.isfinite(gamma[0]) else -1, gamma[1] if np.isfinite(gamma[1]) else -1]
        beam_on_temp = self.beam_on
        beam_hold_temp = self.beam_hold
        bankA_actual = np.array(self.bankA_actual).reshape(int(mlc_num/2), num_snap)
        bankB_actual = np.array(self.bankB_actual).reshape(int(mlc_num/2), num_snap)
        bankA_expected = np.array(self.bankA_expected).reshape(int(mlc_num/2), num_snap)
        bankB_expected = np.array(self.bankB_expected).reshape(int(mlc_num/2), num_snap)

        diffA = bankA_actual - bankA_expected
        diffB = bankB_actual - bankB_expected

        rmsA = np.sqrt(np.mean(np.square(diffA[:, beam_on_temp==1]), axis=1))
        rmsB = np.sqrt(np.mean(np.square(diffB[:, beam_on_temp==1]), axis=1))

        rmsA_hold = np.sqrt(np.mean(np.square(diffA[:, (beam_on_temp==1)&(beam_hold_temp==0)]), axis=1))
        rmsB_hold = np.sqrt(np.mean(np.square(diffB[:, (beam_on_temp==1)&(beam_hold_temp==0)]), axis=1))

        diff_max_on = np.max([np.max(np.abs(diffA[:, beam_on_temp==1])), np.max(np.abs(diffB[:, beam_on_temp==1]))])
        diff_max_hold = np.max([np.max(np.abs(diffA[:, (beam_on_temp==1)&(beam_hold_temp==0)])),
                                        np.max(np.abs(diffB[:, (beam_on_temp==1)&(beam_hold_temp==0)]))])

        return {
                "gamma": gamma,
                "rms_max_on": np.max([rmsA, rmsB]),
                "rms_max_hold": np.max([rmsA_hold, rmsB_hold]),
                "diff_max_on": diff_max_on,
                "diff_max_hold": diff_max_hold,
                "rms_avg": self.log.axis_data.mlc.get_RMS_avg(bank='both', only_moving_leaves=True)
                }