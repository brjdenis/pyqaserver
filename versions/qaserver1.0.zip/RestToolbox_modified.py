# The original code
#  was modified in order to further extend its usabilty.
# Changes include: modification of the authentication procedure,
# modification of functions that are used to get data from the
# orthanc server, addition of new functions.
# The original RestToolbox code is contained in the same directory for reference.
# Denis Brojan, Ljubljana, 2017
############################################################################
#############################################################################

# Orthanc - A Lightweight, RESTful DICOM Store
# Copyright (C) 2012-2016 Sebastien Jodogne, Medical Physics
# Department, University Hospital of Liege, Belgium
#
# This program is free software: you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.


import httplib2
import json
import sys
import base64
import tempfile
import numpy as np
import datetime
from shutil import copyfile
import os

TEMP_DCM_FOLDER = "temp_dcm_archive"

if (sys.version_info >= (3, 0)):
    from urllib.parse import urlencode
else:
    from urllib import urlencode


_credentials = None
_auth = ""

def _DecodeJson(s):
    try:
        if (sys.version_info >= (3, 0)):
            return json.loads(s.decode())
        else:
            return json.loads(s)
    except:
        return s

def get_datetime(instance):
    # Function to get date and time of an instance.
    # CAREFUL, datetime orders the instances for analysis
    date_var = ""
    time_var = ""
    try:
        date_var = instance["ContentDate"]
        time_var = instance["ContentTime"]
    except:
        try:
            date_var = instance["AcquisitionDate"]
            time_var = instance["AcquisitionTime"]
        except:
            try:
                date_var = instance["StudyDate"]
                time_var = instance["StudyTime"]
            except:
                date_var = "Unknown"  # Do not change, or else you will break the code!
                time_var = "Unknown"

    return date_var, time_var


def order_instance_datetime(instance_list):
    # This function gets instances with time stamp for further ordering
    instance_datetime = []
    instance_datetime_order = []
    epoch = datetime.datetime.utcfromtimestamp(0)
    instance_num = []
    for ii in instance_list:
    
        try:
            date_var, time_var = get_datetime(ii)  # Get raw from REST (Dicom)
            date_str = datetime.datetime.strptime(date_var, "%Y%m%d").strftime("%d/%m/%Y")  # To string
            try:
                time_str = datetime.datetime.strptime(time_var, "%H%M%S").strftime("%H:%M:%S")
            except:
                time_str = datetime.datetime.strptime(time_var, "%H%M%S.%f").strftime("%H:%M:%S.%f")
            inst_datetime_temp = date_str + " | " + time_str
            instance_datetime.append(inst_datetime_temp)
            try:
                instance_datetime_order.append(int((datetime.datetime.strptime(inst_datetime_temp,  "%d/%m/%Y | %H:%M:%S.%f") - epoch).total_seconds()*1000))
            except:
                instance_datetime_order.append(int((datetime.datetime.strptime(inst_datetime_temp,  "%d/%m/%Y | %H:%M:%S") - epoch).total_seconds()*1000))
        except:
            instance_datetime.append("Unknown")
            instance_datetime_order.append(int((epoch - epoch).total_seconds()*1000))

        try:
            manufact = ii["Manufacturer"]
        except:
            manufact = "Undefined"

        if manufact in ["Varian Medical Systems"]:
            show_instance_label = "RTImageLabel"
        else:
            show_instance_label = "InstanceNumber"

        try:
            pp = ii[show_instance_label]
            instance_num.append(pp)
        except:
            instance_num.append("Undefined")
    return instance_datetime, instance_datetime_order, instance_num


def SetCredentials(username, password):
    global _credentials, _auth
    _credentials = (username, password)
    _auth = base64.encodebytes( (_credentials[0] + ':' + _credentials[1] ).encode())

def _SetupCredentials(h):
    global _credentials, _auth
    if _credentials != None:
        h.add_credentials(_credentials[0], _credentials[1])

def DoGet(uri, data = {}, interpretAsJson = True):
    d = ''
    if len(data.keys()) > 0:
        d = '?' + urlencode(data)

    h = httplib2.Http()
    _SetupCredentials(h)

    headers = {'Accept': 'application/json',
               'Content-Type': 'application/json',
               'Authorization' : 'Basic ' + _auth.decode() }
    resp, content = h.request(uri + d, 'GET', headers=headers)
    if not (resp.status in [ 200 ]):
        raise Exception(resp.status)
    elif not interpretAsJson:
        return content.decode()
    else:
        return _DecodeJson(content)


def _DoPutOrPost(uri, method, data, contentType):
    h = httplib2.Http()
    _SetupCredentials(h)

    if isinstance(data, str):
        body = data
        if len(contentType) != 0:
            headers = { 'content-type' : contentType,
                        'Authorization' : 'Basic ' + _auth.decode() }
        else:
            headers = { 'content-type' : 'text/plain',
                        'Authorization' : 'Basic ' + _auth.decode()}
    else:
        body = json.dumps(data)
        headers = { 'content-type' : 'application/json',
                    'Authorization' : 'Basic ' + _auth.decode()}

    resp, content = h.request(
        uri, method,
        body = body,
        headers = headers)

    if not (resp.status in [ 200, 302 ]):
        raise Exception(resp.status)
    else:
        return _DecodeJson(content)


def DoDelete(uri):
    h = httplib2.Http()
    _SetupCredentials(h)
    headers = { 'Authorization' : 'Basic ' + _auth.decode() }

    resp, content = h.request(uri, 'DELETE', headers=headers)

    if not (resp.status in [ 200 ]):
        raise Exception(resp.status)
    else:
        return _DecodeJson(content)


def DoPut(uri, data = {}, contentType = ''):
    return _DoPutOrPost(uri, 'PUT', data, contentType)


def DoPost(uri, data = {}, contentType = ''):
    return _DoPutOrPost(uri, 'POST', data, contentType)


def GetPatientIds(uri, interpretAsJson = True):

    h = httplib2.Http()
    _SetupCredentials(h)
    headers = {'Accept': 'application/json',
               'Content-Type': 'application/json',
               'Authorization' : 'Basic ' + _auth.decode()}

    resp, content = h.request(uri + "/patients", 'GET', headers=headers)

    if not (resp.status in [ 200 ]):
        raise Exception(resp.status)
    elif not interpretAsJson:
        return content.decode()
    else:
        return _DecodeJson(content)

def GetPatientData(uri, patient_id, interpretAsJson = True):

    patient_properties = []

    for p in patient_id:
        h = httplib2.Http()
        _SetupCredentials(h)
        headers = {'Accept': 'application/json',
                   'Content-Type': 'application/json',
                   'Authorization' : 'Basic ' + _auth.decode(),
                   'Connection': 'Close'}

        resp, content = h.request(uri + "/patients/"+p, 'GET', headers=headers)

        if not (resp.status in [ 200 ]):
            raise Exception(resp.status)
        elif not interpretAsJson:
            patient_properties.append(content.decode())
        else:
            patient_properties.append(_DecodeJson(content))
    return patient_properties


def GetStudies(uri, studies, interpretAsJson = True):
    study_data = []

    for p in studies:
        h = httplib2.Http()
        _SetupCredentials(h)
        headers = {'Accept': 'application/json',
                   'Content-Type': 'application/json',
                   'Authorization' : 'Basic ' + _auth.decode(),
                   'Connection': 'Close'}

        resp, content = h.request(uri + "/studies/"+p, 'GET', headers=headers)

        if not (resp.status in [ 200 ]):
            raise Exception(resp.status)
        elif not interpretAsJson:
            study_data.append(content.decode())
        else:
            study_data.append(_DecodeJson(content))
    return study_data

def GetSeries(uri, series, interpretAsJson = True):
    series_data = []

    for p in series:
        h = httplib2.Http()
        _SetupCredentials(h)
        headers = {'Accept': 'application/json',
                   'Content-Type': 'application/json',
                   'Authorization' : 'Basic ' + _auth.decode(),
                   'Connection': 'Close'}

        resp, content = h.request(uri + "/series/"+p, 'GET', headers=headers)

        if not (resp.status in [ 200 ]):
            raise Exception(resp.status)
        elif not interpretAsJson:
            series_data.append(content.decode())
        else:
            series_data.append(_DecodeJson(content))
    return series_data

def GetInstances(uri, instances, interpretAsJson = True):
    instance_data = []

    for p in instances:
        h = httplib2.Http()
        _SetupCredentials(h)
        headers = {'Accept': 'application/json',
                   'Content-Type': 'application/json',
                   'Authorization' : 'Basic ' + _auth.decode(),
                   'Connection': 'Close'}

        resp, content = h.request(uri + "/instances/"+p+"/simplified-tags", 'GET', headers=headers)

        if not (resp.status in [ 200 ]):
            raise Exception(resp.status)
        elif not interpretAsJson:
            instance_data.append(content.decode())
        else:
            instance_data.append(_DecodeJson(content))
    return instance_data


def GetSeries2Subfolders(uri, series, interpretAsJson = True):
    # Get filepaths, ordered in sequence of datetime! Ordering is important for analysis (Winston Lutz etc.)

    file_paths = []
    for s in series:
        h = httplib2.Http()
        _SetupCredentials(h)
        headers = {'Accept': 'application/json',
                   'Content-Type': 'application/json',
                   'Authorization' : 'Basic ' + _auth.decode(),
                   'Connection': 'close'}
        resp, content = h.request(uri + "/series/"+s, 'GET', headers=headers)
        
        if not (resp.status in [ 200 ]):
            raise Exception(resp.status)
        elif not interpretAsJson:
            data = content.decode()
        else:
            data = _DecodeJson(content)
    
        instances = data["Instances"]
    
        inst_temp = GetInstances(uri, instances)
    
        instance_datetime, instance_datetime_order, instance_num = order_instance_datetime(inst_temp)
    
        order = np.argsort(instance_datetime_order)
    
        instances = list(np.asarray(instances)[order])
    
        # Now save each file twice in a subfolder
        for i in instances:
            temp_folder = tempfile.mkdtemp(prefix=i+"_", dir=TEMP_DCM_FOLDER)
            temp_file1 = tempfile.NamedTemporaryFile(delete=False, prefix=i+"_", suffix=".DCM", dir=temp_folder)
            temp_file2 = tempfile.NamedTemporaryFile(delete=False, prefix=i+"_second_", suffix=".DCM", dir=temp_folder)
            file = DoGet(uri + "/instances/" + i + "/file")
    
            with open(temp_file1.name, 'wb') as dst:
                dst.write(file)
            copyfile(temp_file1.name, temp_file2.name)
            temp_file1.close()
            temp_file2.close()
            file_paths.append(temp_folder)

    return file_paths

def GetSeries2Folder(uri, series, interpretAsJson = True):
    # Get filepaths, ordered in sequence of datetime! But this time save in one folder
    # and use numeric image names!
    # series is a list of series, for only one series  = ["..."]

    file_paths_final = []
    temp_folder = tempfile.mkdtemp(prefix=series[0]+"_", dir=TEMP_DCM_FOLDER)
    counter = 0
    for s in series:
        h = httplib2.Http()
        _SetupCredentials(h)
        headers = {'Accept': 'application/json',
                   'Content-Type': 'application/json',
                   'Authorization' : 'Basic ' + _auth.decode(),
                   'Connection': 'Close'}
        resp, content = h.request(uri + "/series/"+s, 'GET', headers=headers)
        if not (resp.status in [ 200 ]):
            raise Exception(resp.status)
        elif not interpretAsJson:
            data = content.decode()
        else:
            data = _DecodeJson(content)
    
        instances = data["Instances"]
        inst_temp = GetInstances(uri, instances)
        instance_datetime, instance_datetime_order, instance_num = order_instance_datetime(inst_temp)
        order = np.argsort(instance_datetime_order)
        instances = list(np.asarray(instances)[order])
        file_paths = []
        # Now save each file
        for i in range(0, len(instances), 1):
            temp_file = os.path.join(temp_folder, "img-"+str(counter+1)+".dcm")
            file = DoGet(uri + "/instances/" + instances[i] + "/file")
            with open(temp_file, 'wb') as dst:
                dst.write(file)
            dst.close()
            file_paths.append(temp_file)
            counter += 1
        
        file_paths_final += file_paths

    return temp_folder, file_paths_final

def GetSeries2Folder2(uri, series, interpretAsJson = True):
    h = httplib2.Http()
    _SetupCredentials(h)
    headers = {'Accept': 'application/json',
               'Content-Type': 'application/json',
               'Authorization' : 'Basic ' + _auth.decode(),
               'Connection': 'Close'}

    resp, content = h.request(uri + "/series/" + series, 'GET', headers=headers)
    if not (resp.status in [ 200 ]):
        raise Exception(resp.status)
    elif not interpretAsJson:
        data = content.decode()
    else:
        data = _DecodeJson(content)
    instances = data["Instances"]

    temp_folder = tempfile.mkdtemp(prefix=series+"_", dir=TEMP_DCM_FOLDER)

    for i in instances:
        temp_file = tempfile.NamedTemporaryFile(delete=False, prefix=i+"_", suffix=".DCM", dir=temp_folder)
        file = DoGet(uri + "/instances/" + i + "/file")
        with open(temp_file.name, 'wb') as dst:
            dst.write(file)
        dst.close()
        temp_file.close()
    return temp_folder

def GetSingleDcm(uri, instance, interpretAsJson = True):
    '''Get one single dicom file'''
    '''Used, for example, for the starshot module'''
    temp_folder = tempfile.mkdtemp(prefix=instance+"_", dir=TEMP_DCM_FOLDER)
    temp_file = tempfile.NamedTemporaryFile(delete=False, prefix="Dicom_", suffix=".DCM", dir=temp_folder)
    file = DoGet(uri + "/instances/" + instance + "/file")
    with open(temp_file.name, 'wb') as dst:
        dst.write(file)
    dst.close()
    temp_file.close()
    return temp_folder, temp_file.name

def DoGet_image(uri, data = {}, interpretAsJson = True):
    d = ''
    if len(data.keys()) > 0:
        d = '?' + urlencode(data)

    h = httplib2.Http()
    _SetupCredentials(h)

    headers = {'Accept': 'image/png',
               'Content-Type': 'image/png',
               'Authorization' : 'Basic ' + _auth.decode() }
    resp, content = h.request(uri + d, 'GET', headers=headers)
    if not (resp.status in [ 200 ]):
        raise Exception(resp.status)
    elif not interpretAsJson:
        return content.decode()
    else:
        return _DecodeJson(content)
