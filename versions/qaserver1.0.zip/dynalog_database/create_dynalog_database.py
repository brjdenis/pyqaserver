# -*- coding: utf-8 -*-
"""
Create sql Varian Dynalog database
"""

import sqlite3 as sql

# The name of the user database should be "dynalog_database.db"

conn = sql.connect("dynalog_database.db")
c = conn.cursor()

c.execute("""CREATE TABLE VarianDynalog (
                            FileName TEXT UNIQUE,
                            ZipArchive TEXT,
                            PatientID TEXT,
                            PatientName TEXT,
                            PatientLastName TEXT,
                            Date TEXT,
                            Time TEXT,
                            BeamID TEXT,
                            Gantry REAL,
                            Snapshots INTEGER,
                            Beamholds INTEGER,
                            RMSmax REAL,
                            RMSmax2 REAL,
                            DIFFmax REAL,
                            DIFFmax2 REAL,
                            RMSAvg REAL,
                            GammaAvg REAL,
                            GammaIndex REAL,
                            GammaTol TEXT,
                            DateEntered TEXT,
                            Repository TEXT,
                            ext1 TEXT,
                            ext2 TEXT,
                            ext3 TEXT,
                            ext4 TEXT,
                            ext5 TEXT
                            )
          """)

conn.commit()
conn.close()
